# js简单文件下载



简单的文件下载一般是后台提供一个接口，接口请求头保存一个字段，我们从这个字段里面获取文件的信息，另外后端并不一定是返回的url，所以我们需要对返回的流式数据转换为url以提供给a标签下载。

```js
 async downloadFile=> {
      const res = await download();
      // 获取请求头信息
      const headers = res?.response.headers;
      let filename;
      try {
        // 截取文件名
        filename = decodeURIComponent(
          headers.get('content-disposition').split(';')[1]
        ).split('=')[1];
      } catch (error) {
        console.log('error',error)
      }
      if (!res?.data) {
        return;
      }
      // 将文件流转为url进行下载
      const url = URL.createObjectURL(res?.data);
      // 创建一个临时a标签进行下载操作
      const a = document.createElement('a');
      a.href = url;
      // 这里就标志着下载的名称
      a.download = filename + '.xlsx';
     // 添加进文档并手动出发点击 
      document.body.appendChild(a);
      a.click();
     // 移除标签 
      a.parentNode.removeChild(a);
    }
```

