# flex 实现左侧对齐

flex可以很方便的实现很多布局，但有时有我们需要这种布局。

最后一行左侧对齐，整体居中

会出现一下现象![image-20221104135725021](/Users/zhangheng/Library/Application Support/typora-user-images/image-20221104135725021.png)

最后一行也居中了。

总结两个简单方法

一、 补充元素，简单实用

在弹性子元素后面补充元素，最多有多少列就补充多少个，并且设置和弹性元素一样的宽度(边距啥的都计算上)，无需设置高度。

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>flex 实现左侧对齐</title>
  <style>
    .container {
      background-color: #ccc;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items:flex-start;
      align-content: flex-start;
    }
    .item {
      margin: 10px;
      box-sizing: border-box;
      width: 100px;
      height: 50px;
      background-color: antiquewhite;
      text-align: center;
      line-height: 50px;
    }
    .container > li {
      list-style: none;
      width: 120px;
    }
  </style>
</head>
<body>
    <div class="container">
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
    </div>

</body>
</html>
```

二、grid布局 这个就更加简单了，当然有些老浏览器可能不兼容。。。

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>flex 实现左侧对齐</title>
  <style>
    .container {
      background-color: #ccc;
      display: grid;
      flex-wrap: wrap;
      justify-content: center;
      align-items:flex-start;
      align-content: flex-start;
      grid-template-columns: repeat(auto-fill, 100px);
      grid-gap: 10px;
    }
    .item {
      box-sizing: border-box;
      width: 100px;
      height: 50px;
      background-color: antiquewhite;
      text-align: center;
      line-height: 50px;
    }
  </style>
</head>
<body>
    <div class="container">
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
      <div class="item">1</div>
    </div>
</body>
</html>
```

