## 单行换行
首先书写以下代码块
```javascript
<!DOCTYPE html>
<html lang="zh-CN">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>文字换行</title>
  <style>
    .container-v1 {
      width: 300px;
      border: 1px solid #ccc;
    }

    p {
     
    }
  </style>
</head>

<body>
  <h2>单行换行</h2>
  <div class="container-v1">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiisitaquequodpraesentiumexplicaboincidunt?
      Dolores beatae nam at sed dolorum ratione dolorem nisi velit cum.Lorem ipsum dolor sit amet, consectetur
      adipisicing elit. Blanditiisitaquequodpraesentiumexplicaboincidunt? Dolores beatae nam at sed dolorum ratione
      dolorem nisi velit cum.Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Blanditiisitaquequodpraesentiumexplicaboincidunt? Dolores beatae nam at sed dolorum ratione dolorem nisi velit
      cum.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiisitaquequodpraesentiumexplicaboincidunt?
      Dolores beatae nam at sed dolorum ratione dolorem nisi velit cum.</p>
  </div>


</body>

</html>
```
效果如下：
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647397525666-f641b78e-3439-4329-bb34-b259a32ee5e6.png#clientId=uba827390-7af8-4&from=paste&height=586&id=u26be6836&margin=%5Bobject%20Object%5D&name=image.png&originHeight=1172&originWidth=892&originalType=binary&ratio=1&size=494468&status=done&style=none&taskId=u73a020c9-f6c7-4b02-a313-9e156fc92b6&width=446)
可以看到文字换行了，但是有些较长的单词没有换行，
如果你要求这些过长的单词也换行可以使用这个属性：word-wrap(该属性在css3修改为了[overflow-wrap](https://developer.mozilla.org/zh-CN/docs/Web/CSS/overflow-wrap)，当然目前还是能使用前面的那个属性名)。
我们来为p标签设置属性：
```css
p{
  overflow-wrap: break-word;
}
```
效果：
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647397868154-c096d7bc-9158-4975-a087-87aa0e9cdf4d.png#clientId=uba827390-7af8-4&from=paste&height=562&id=ud22951d5&margin=%5Bobject%20Object%5D&name=image.png&originHeight=1124&originWidth=676&originalType=binary&ratio=1&size=432221&status=done&style=none&taskId=u49528529-a877-4f4a-a3e6-3bc84282aa1&width=338)
另外还有一个换行属性：[word-break](https://developer.mozilla.org/zh-CN/docs/Web/CSS/word-break)，这些在不同文字间有不同的换行效果。

回到正题，我们要求单行省略，那就不需要换行。
所以这里设置不换行：
这里需要一个属性[white-space](https://developer.mozilla.org/zh-CN/docs/Web/CSS/white-space)
```css
p{
   white-space: nowrap;
}
```
效果：
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647399588522-f2f46bf3-9d8d-43d2-9a70-526711e79f4e.png#clientId=uba827390-7af8-4&from=paste&height=131&id=u00c5265f&margin=%5Bobject%20Object%5D&name=image.png&originHeight=262&originWidth=2876&originalType=binary&ratio=1&size=162334&status=done&style=none&taskId=ubf667df7-32d5-4229-be3b-c5d96a7ee7d&width=1438)
可以看到没有换行，接下来设置溢出文本省略：
```css
p{
   white-space: nowrap;
   overflow:hidden;
}
```
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647399672434-8fe614b2-22c5-4e1f-ad3e-e5e29bcda10d.png#clientId=uba827390-7af8-4&from=paste&height=140&id=uba7ed705&margin=%5Bobject%20Object%5D&name=image.png&originHeight=280&originWidth=810&originalType=binary&ratio=1&size=60110&status=done&style=none&taskId=ue12e3f6e-2068-4597-af9f-c3d847db8a4&width=405)
添加省略号样式：
通过[text-overflow](https://developer.mozilla.org/zh-CN/docs/Web/CSS/text-overflow)设置。
```css
p{
   white-space: nowrap;
   overflow:hidden;
   text-overflow:ellipsis;
}
```
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647399711379-538e5bac-2155-4620-83b0-36af647612de.png#clientId=uba827390-7af8-4&from=paste&height=140&id=uae441280&margin=%5Bobject%20Object%5D&name=image.png&originHeight=280&originWidth=764&originalType=binary&ratio=1&size=69839&status=done&style=none&taskId=u77c58f6d-28eb-4d31-aa61-9e22064f94f&width=382)

## 多行省略
多行省略就和单行有点不一样，首先在样式上，设置不换行的属性`white-space`就不用了,需要额外的三个属性：

- **display: -webkit-box** 将对象作为弹性伸缩盒子模型显示。
- **-webkit-box-orient** 设置或检索伸缩盒对象的子元素的排列方式。
- **text-overflow: ellipsis** 用省略号“…”隐藏超出范围的文本。
```css
overflow : hidden;
text-overflow: ellipsis;
display: -webkit-box;
-webkit-line-clamp: 2;/*设置换行的行数*/
-webkit-box-orient: vertical;
```
![image.png](https://cdn.nlark.com/yuque/0/2022/png/12946800/1647400541027-31999de2-2fdb-49fb-bb9b-3defb1f198f3.png#clientId=uba827390-7af8-4&from=paste&height=165&id=u6735244a&margin=%5Bobject%20Object%5D&name=image.png&originHeight=330&originWidth=762&originalType=binary&ratio=1&size=85718&status=done&style=none&taskId=u0a01320b-a137-4b8b-af9d-fa26de8a3d0&width=381)
目前多行的省略部分样式有兼容性问题，所以遇到兼容性问题还是需要另寻找方案了。
比如使用伪元素来设置个省略号。

