# flex容器内容溢出后无法滚动到顶部

如下所示：

```html
 <div className="child-box">
    <div className="item">0</div>
    <div className="item">1</div>
    <div className="item">2</div>
    <div className="item">3</div>
    <div className="item">4</div>
    <div className="item">5</div>
 </div>
```

```css
.box {
  width: 200px;
  height: 200px;
  background-color: #61dafb;
  display: flex;
  flex-direction: column;
  overflow: auto;
}
.item {
  width: 100px;
  height: 100px;
  background-color: antiquewhite;
  margin: auto;
  align-items: center;
  line-height: 100px;
}
```

![image-20220803155442528](/Users/zhangheng/Library/Application Support/typora-user-images/image-20220803155442528.png)

可以看到滚动是正常的

但是当我们给外部容器加上justify-xxx等属性后，比如我们将样式改造成如下：

```css
.box {
  width: 200px;
  height: 200px;
  background-color: #61dafb;
  display: flex;
  flex-direction: column;
+ justify-content: center;
  overflow: auto;
}

.item {
  width: 100px;
  height: 100px;
  background-color: antiquewhite;
  margin: auto;
  align-items: center;
  line-height: 100px;
}
```

此时我们在尝试滚动到顶部：

![image-20220803155918226](/Users/zhangheng/Library/Application Support/typora-user-images/image-20220803155918226.png)

可以看到滚动不到顶部，有部分被遮盖着。

这个问题可以参照这篇博客的解释：https://www.cnblogs.com/ZengYunChun/p/9721982.html

具体解决方案就是对于滚动容器我们就不要使用`justify-xx`或者`align-xx`属性进行设置布局，对于弹性子元素可以设置`margin：auto`来进行居中的操作。