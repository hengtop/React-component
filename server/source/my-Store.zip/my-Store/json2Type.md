## json2Type

## 背景

开发过程中难免会遇到一些接口没有接口类型文档的时候，此时前端要编写接口响应类型就只能根据响应数据进行编写。所以为了提高工作效率，就需要一个可以直接将json数据转为ts类型的插件，这样我们面对野生的接口，拿到json数据后就能快速生成响应类型了。

灵感来源：苹果商店里有一款类似的json2type，但不适用于js。

## 使用方式

将扩展文件.vsix 导入到vscode里

![image-20230322095545225](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230322095545225.png)

vscode任意打开一个index.ts 文件

cmmmand+shift+P 打开命令输入框 输入json2Type

弹出对话框，将json数据输入，回车即可在当前文件里生成ts类型数据了

![image-20230322100102741](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230322100102741.png)

## 注意

该工具生成的类型并不支持交叉类型和联合类型，json数据里有重复字段的类型是无法生成的。后续还在考虑如何解决～～