## 探究 z-index

水一篇文章，探究下z-index的特性

z-index是用来设置定位元素以及后代元素或者flex元素的Z轴

z-index的取值有两种：

- auto 盒子在当前层叠上下文层级为0，也不会创建一个层叠上下文
- 整数，盒子会创建一个层叠上下文，且该盒子中的子元素不会和盒子外的元素比较层级

可以理解为层叠上下文中，作为 层叠上下文的 盒子 层级始终是最低的，永远放置在最底层，内部的元素设置的层级即使为负数也是作为层叠上下文的盒子在最底层。

### 正常流

z-index对于正常流来讲是没有效果的

```css
    .wrapper {
      width: 200px;
      height: 200px;
      background-color: blue;
      z-index: 999;
    }
    .box {
      width: 100px;
      height: 100px;
      background-color: red;
      z-index: -1;
    }
```

```html
   <div class="wrapper">
     <div class="box"></div>
   </div>
```

展示效果：
<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240506151351537.png" alt="image-20240506151351537" style="zoom:50%;" />

### 定位

给父元素和子元素都加上绝对定位

```css
    .wrapper {
      position: absolute;
      width: 200px;
      height: 200px;
      background-color: blue;
      z-index: auto;
    }
    .box {
      position: absolute;
      width: 100px;
      height: 100px;
      background-color: red;
      z-index: -1;
    }
```

```html
   <div class="wrapper">
     <div class="box"></div>
   </div>
```

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240506160942197.png" alt="image-20240506160942197" style="zoom:50%;" /><img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240506161006244.png" alt="image-20240506161006244" style="zoom:50%;" />

上图为了做对比给蓝色加上了0.5的透明 可以看到红色在蓝色下面，因为父元素并未生成层叠上下文 此时的红色元素是相对于根层叠上下文html来比较层级的所以说红色层级-1 ，蓝色层级auto即为0 都在同一个层叠上下文里 所以比较index的大小，红色就在蓝色下面了。

**给蓝色加上层级**

```css
.wrapper {
  position: absolute;
  width: 200px;
  height: 200px;
  background-color: blue;
  z-index: 0;
}
.box {
  position: absolute;
  width: 100px;
  height: 100px;
  background-color: red;
  z-index: -1;
}
```

```html
   <div class="wrapper">
     <div class="box"></div>
   </div>
```

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240506162117596.png" alt="image-20240506162117596" style="zoom: 50%;" />

可以看到，红色还在蓝色上面，命名从层级上来看是红色的更小。这里是因为蓝色也加上了数字类型的层级，所以形成了层叠上下文，其内部的子元素就只能在层叠上下文上方，所以不管蓝色设置再高的层级也会处于底层。

再来个稍复杂的

```css
    .wrapper {
      top: 150px;
      position: absolute;
      width: 200px;
      height: 200px;
      background-color: blue;
    }

    .box {
      position: absolute;
      width: 100px;
      height: 100px;
      background-color: red;
      z-index: -1;
    }
    .wrapper2 {
      width: 300px;
      height: 300px;
      background-color: yellow;
    }
```

设置透明颜色

```css
    .wrapper {
      top: 150px;
      position: absolute;
      width: 200px;
      height: 200px;
      background-color: rgba(0,0,255, .5);
    }

    .box {
      position: absolute;
      width: 100px;
      height: 100px;
      background-color: red;
      z-index: -1;
    }
    .wrapper2 {
      width: 300px;
      height: 300px;
      background-color: rgba(255,255,0, 0.8);
    }
```

```html
   <div class="wrapper">
     <div class="box"></div>
   </div>
   <div class="wrapper2"></div>
```

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240506171009447.png" alt="image-20240506171009447" style="zoom:50%;" /><img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240507091605716.png" alt="image-20240507091605716" style="zoom:50%;" />

给蓝色和黄色设置下rgba透明色，这里可以看到红色跑到黄色盒子下方了

这里的层级关系：

蓝色：定位。层级默认为0
  红色： 定位+z-index 形成层叠上下文
黄色：块级元素 层级默认为0

所以：蓝色，红色，黄色的层级统一在根层叠上下文上进行比较

红色为负数在最底层，蓝色和黄色按照定位优先级，蓝色脱离文档流所以排最前面，黄色则第二
最终层级为从下到上：红，黄，蓝

### flex

```css
       .wrapper {
      position: absolute;
      top: 150px;
      width: 200px;
      height: 200px;
      background-color: rgba(0,0,255, 1);
    }

    .box {
      position: absolute;
      top: -50px;
      left: 50px;
      width: 100px;
      height: 100px;
      background-color: red;
      z-index: -1;
    }

    .wrapper2 {
      margin-left: 100px;
      width: 300px;
      height: 300px;
      background-color: rgba(255,255,0, 1);
    }

    .wrapper3 {
      margin-top: -100px;
      margin-left: 100px;
      display: flex;
      width: 300px;
      height: 300px;
      background-color: rgba(0,255,0, 1);
    }

    .flex1 {
      margin-top: 50px;
      width: 200px;
      height: 200px;
      background-color: cadetblue;
      z-index: 0;
    }
```

```html
   <div class="wrapper">
     <div class="box"></div>
   </div>
   <div class="wrapper2"></div>
   <div class="wrapper3">
    <div class="flex1"></div>
   </div>
```

相较于上一个例子，新增了一个flex盒子,调整了下边框和定位便于观察层级
<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240507100113968.png" alt="image-20240507100113968" style="zoom:50%;" />

此时层级为：
蓝色：绝对定位 层级默认为0
  红色：绝对定位 z-index：-1 形成层叠上下文
黄色：块级定位 层级默认为 0
绿色：设置flex 层级默认为 0
  cadetblue色：flex子元素 z-index:0 形成层叠上下文

表现的层级：红色，黄色，绿色，蓝色，cadetblue色

所以先按照层级排列 ：红色， （蓝色，黄色，绿色）cadetblue色
（蓝色，黄色，绿色）按照代码编写顺序和以及定位元素和非定位元素之间的优先级进行比较

由于 蓝色 绝对定位 所以会在 黄色，绿色 上， 剩下 黄色，绿色，按照后来者居上的顺序
则为（黄色，绿色），最后还剩cadetblue色，因为形成了层叠上下文，所以优先级和定位元素蓝色相同，按照先来后到顺序排在蓝色上方
最终表现为：红色，黄色，绿色，蓝色，cadetblue色

**另外再来看一个例子**

定位元素和flex之间比较层级

```css
    .wrapper {
      position: absolute;
      top: 0;
      width: 200px;
      height: 200px;
      background-color: blue;
    }

    .wrapper3 {
      display: flex;
      width: 300px;
      height: 300px;
      background-color: green;
    }
    .flex1 {
      margin-top: 50px;
      width: 250px;
      height: 250px;
      background-color: red;
      z-index: 0;
    }
```

```html
 <div class="wrapper"></div>
   <div class="wrapper3">
    <div class="flex1"></div>
   </div>
```

表现效果：

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240507104203508.png" alt="image-20240507104203508" style="zoom:50%;" />

层级关系：

蓝色： 绝对定位 层级默认为0
绿色：flex父元素 层级默认为0
红色：flex子元素+z-index:0 形成层叠上下文

所以按照优先级关系 蓝色=红色 > 绿色
按照层级关系最终得出：绿色，蓝色，红色

接下来我们将wrapper3移到最顶部

```css
    .wrapper {
      position: absolute;
      top: 0;
      width: 200px;
      height: 200px;
      background-color: blue;
    }

    .wrapper3 {
      display: flex;
      width: 300px;
      height: 300px;
      background-color: green;
    }
    .flex1 {
      margin-top: 50px;
      width: 250px;
      height: 250px;
      background-color: red;
      z-index: 0;
    }
```

```html
    <div class="wrapper3">
      <div class="flex1"></div>
     </div>
   <div class="wrapper">
   </div>
```

展示效果：

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20240507105405734.png" alt="image-20240507105405734" style="zoom:50%;" />

所以按照优先级关系 蓝色=红色 > 绿色
按照层级关系最终得出：绿色，红色，蓝色  

最后说下不同状态盒子的优先级

![image-20240507105919885](/Users/zhangheng/Library/Application Support/typora-user-images/image-20240507105919885.png)

参考

-  [z-index特性](https://juejin.cn/post/7099712000917258254?searchId=20240506153635367F5AD508D106E819D4#heading-0)

- [层叠上下文](https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_positioned_layout/Understanding_z-index/Stacking_context)

  