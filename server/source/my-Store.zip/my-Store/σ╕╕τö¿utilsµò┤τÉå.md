### 常用utils整理

#### 轮训函数

```ts
/**
 * 轮询函数，直到满足特定条件或达到最大尝试次数。
 *
 * @param {Function} apiCall - 用于执行API请求的异步函数。
 * @param {Function} checkResult - 检查API响应是否满足停止轮询条件的函数。应该接受响应并返回true/false。
 * @param {Object} options - 配置选项包括轮询间隔和最大尝试次数。
 * @returns {Promise} - 当满足条件时解析，或在达到最大尝试次数时拒绝。
 */
async function poll(
  fn: () => Promise<any>,
  checkResult: (e: any) => boolean | undefined,
  options: { interval?: number; maxAttempts?: number } = {},
) {
  const defaultOptions = {
    interval: 1000, // 默认轮询间隔为1秒
    maxAttempts: 10, // 默认最大尝试次数为10次
  };

  const { interval, maxAttempts } = { ...defaultOptions, ...options };
  let attempts = 0;

  while (attempts < maxAttempts) {
    let timeoutId = null; // 用于存储当前的setTimeout ID
    if (timeoutId !== null) {
      clearTimeout(timeoutId); // 清除定时器
    }
    try {
      const response = await fn();
      if (checkResult(response)) {
        return response; // 返回满足条件的结果
      }
    } catch (error) {
      return Promise.reject(error);
    }

    attempts++;
    if (attempts >= maxAttempts) {
      throw new Error(`Reached maximum number of attempts (${maxAttempts}).`);
    }
    await new Promise((resolve) => {
      timeoutId = setTimeout(resolve, interval);
    }); // 等待下一次轮询
  }
}
```

#### 动态高亮

```ts
/**
 * 将原始字符串中的指定子字符串高亮显示
 * @param originalStr 原始字符串
 * @param highlightStr 需要高亮的子字符串
 * @param highlightColor 高亮颜色（默认红色）
 * @returns 包裹在 <span> 中的安全 HTML 字符串，高亮部分用 <span> 包裹
 */
function highlightString(
  originalStr: string,
  highlightStr: string,
  highlightColor: string = "red"
): string {
  // 转义 HTML 特殊字符
  const escapeHTML = (str: string): string => {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  };

  // 处理空值或无效输入
  if (typeof originalStr !== "string") return "<span></span>";
  const escapedOriginal = escapeHTML(originalStr);
  const escapedHighlight = escapeHTML(highlightStr);

  // 无需高亮的情况
  if (!escapedHighlight || !escapedOriginal.includes(escapedHighlight)) {
    return `<span>${escapedOriginal}</span>`;
  }

  // 安全分割和替换（避免正则表达式注入风险）
  const parts = escapedOriginal.split(escapedHighlight);
  const highlighted = parts.join(
    `<span style="color: ${highlightColor};">${escapedHighlight}</span>`
  );

  return `<span>${highlighted}</span>`;
}
```

#### 安全parse

```ts
/**
 * 安全解析 JSON 字符串，解析失败时返回原值
 * @param jsonString 需要解析的 JSON 字符串
 * @returns 解析后的对象，或原值
 */
function safeParseJSON<T>(jsonString: string): T | string {
  try {
    return JSON.parse(jsonString) as T;
  } catch (error) {
    // 捕获 JSON.parse 的异常，返回原值
    return jsonString;
  }
}
```

### 常见问题整理

#### package.json 版本规则

**通配符匹配**：
若版本号遵循 `x.y.z-dev.n` 格式，可通过 `*` 或 `x` 匹配最新开发版：

```json
{
  "devDependencies": {
    "your-package": "^0.0.x-dev"  // 匹配所有 `0.0.x` 分支下的最新 dev 版本
  }
}
```

**波浪号（~）和插入符号（^）**：

Node.js 的 semver 实现还引入了速记范围：波浪号（~）和插入符号（^）。关于这些工作原理的一般解释是：

- 在单个 semver 版本字符串前面加上 `~` 字符定义可接受的版本范围，其中包括从指定版本到下一个次要版本的所有补丁版本，但不包括下一个次要版本。比如 “~1.2.3” 可以大致扩展为 “>=1.2.3 <1.3.0”
- 在单个 semver 版本字符串前面加上 `^` 字符定义可接受的版本范围，其中包括从指定版本到下一个主要版本的所有次要和补丁版本，但不包括下一个主要版本。比如 “^1.2.3” 可以大致扩展为 “>=1.2.3 <2.0.0”。
