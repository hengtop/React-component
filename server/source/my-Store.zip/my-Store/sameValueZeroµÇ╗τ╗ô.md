# js中的相等性判断

最近在使用loadsh库中遇到了一个函数`_.uniq(array)`，同时看到了文档里写的该函数使用的等值判断是使用的[sameValueZero](https://262.ecma-international.org/6.0/#sec-samevaluezero)。于是就想详细的了解下这个规范。

这个规范存在于ECMAScript 2015的语言规范中，虽然js并没有内置这种方法，但这个规范也是被很多的内置函数实现。

基于上述背景，这里详细介绍下js中的相等性判断。

## 运算符

对于判断下相等，js提供了两种方式进行比较相等

=== 严格相等

== 宽松相等

- 对于宽松相等，在比较两个操作数时，双等号（`==`）将执行类型转换，并且会按照 IEEE 754 标准对 `NaN`、`-0` 和 `+0` 进行特殊处理（故 `NaN != NaN`，且 `-0 == +0`）。
- 对于严格相等，做的比较与双等号相同（包括对 `NaN`、`-0` 和 `+0` 的特殊处理）但不进行类型转换；如果类型不同，则返回 `false`；

## Object.is

`Object.is()` 既不进行类型转换，也不对 `NaN`、`-0` 和 `+0` 进行特殊处理（这使它和 `===` 在除了那些特殊数字值之外的情况具有相同的表现）。

该方法用于确定两个值是否为同一值，遵循以下规范则返回true：

- 都是 [`undefined`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/undefined)
- 都是 [`null`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Operators/null)
- 都是 `true` 或者都是 `false`
- 都是长度相同、字符相同、顺序相同的字符串
- 都是相同的对象（意味着两个值都引用了内存中的同一对象）
- 都是 [BigInt](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/BigInt) 且具有相同的数值
- 都是 [symbol](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Symbol) 且引用相同的 symbol 值
- 都是数字且
  - 都是 `+0`
  - 都是 `-0`
  - 都是 [`NaN`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/NaN)
  - 都有相同的值，非零且都不是 [`NaN`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/NaN)



## 相等性算法

而在js相等性算法中，上述的三种方式就是相等性算法中的其三：

- [IsLooselyEqual](https://tc39.es/ecma262/#sec-islooselyequal)：`==`
- [IsStrictlyEqual](https://tc39.es/ecma262/#sec-isstrictlyequal)：`===`
- [SameValue](https://tc39.es/ecma262/#sec-samevalue)：`Object.is()`
- [SameValueZero](https://tc39.es/ecma262/#sec-samevaluezero)：被许多内置运算使用



这里我们就主要讲解下 SameValueZero 

SameValueZero有以下规定：

抽象操作 SameValueZero 接受参数 x (ECMAScript 语言值)和 y (ECMAScript 语言值)并返回布尔值。它确定两个参数是否是相同的值(忽略 + 0F 和 -0F 之间的差异)。它在调用时执行以下步骤:

1. 如果x和y的类型不相等，返回false
2. 如果x是number类型，则有以下几种情况
   1. 如果x和y都是NaN，则返回 true
   2. 如果x是+0，y是-0，返回true，反之也成立
   3. 如果x就是y，则返回true
   4. 否则返回false
3. 如果x不是number，则有以下几种情况：
   1. 如果x类型为null，返回true
   2. 如果x类型为undefined，返回true
   3. 如果x类型为string， x 和 y 具有相同的长度，同时在字符串相同位置的代码单元也是相同的，则返回 true，否则返回 false。
   4. 如果x类型为boolean， x 和 y 都为 true 或者都为 false，则返回 true，否则返回 false。
4. 如果x就是y，则返回true

零值相等在js中并未公开实现，但我们可以通过代码来进行实现：

```js
function sameValueZero(x, y) {
  if (typeof x === "number" && typeof y === "number") {
    // x 和 y 相等（可能是 -0 和 0）或它们都是 NaN
    return x === y || (x !== x && y !== y);
  }
  return x === y;
}
```

零值相等SameValueZero 与严格相等的区别在于其将 `NaN` 视作是相等的，与同值相等SameValue 的区别在于其将 `-0` 和 `0` 视作相等的。这使得它在搜索期间通常具有最实用的行为，特别是在与 `NaN` 一起使用时。它被用于 [`Array.prototype.includes()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/includes)、[`TypedArray.prototype.includes()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/TypedArray/includes) 及 [`Map`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Map) 和 [`Set`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Set) 方法用来比较键的相等性。

对于内置的三种比较方式，有以下区别：

严格相等和宽松相等，区别在于是否进行类型转换,对于`NaN`、`-0` 和 `+0` 进行的处理是一致的。而Object.is则有区别了，对于NaN会判断为两个NaN为相等的，对于+0和-0也判断为不相等。

## 使用时机

关于上述的几种相等性比较方法，我认为尽量不要使用宽松比较==，除非你写错了，因为宽松比较导致的类型转换会带来很多意想不到的问题和心智负担（需要在脑海里走一遍强转） 。如果不考虑对零值的正负号进行区别比较或者特殊处理反直觉的NaN时，使用严格相等===是很不错的选择。如果需要考虑对零值的正负号判断，和需要对两个NaN做相等判断时，Object.is()则是最优选。

