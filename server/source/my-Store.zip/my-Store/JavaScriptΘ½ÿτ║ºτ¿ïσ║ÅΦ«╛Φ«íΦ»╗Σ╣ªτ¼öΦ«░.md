# JavaScript高级程序设计读书笔记

## BOM

BOM的核心对象是window 对象，表示浏览器的实例。window对象在浏览器中有两重身份，一层是指的ECMAScript中的Global对象，另一个就是浏览器窗口的JavaScript接口。网页中所有的变量，对象，函数都以window作为其Global对象，都可以访问其上下文定义的全局方法。

### Global作用域

window 对象被复用为 ECMAScript 的 Global 对象，所以通过 var 声明的所有全局变量和函 数都会变成 window 对象的属性和方法。

```js
var age = 29;
var sayAge = () => alert(this.age);
alert(window.age); // 29
sayAge(); // 29
window.sayAge();   // 29
```

### 窗口关系

top 对象始终指向最上层(最外层)窗口，即浏览器窗口本身。而 parent 对象则始终指向当前窗口的父窗口。如果当前窗口是最上层窗口，则 parent 等于 top(都等于 window)。最上层的 window 如果不是通过 window.open()打开的，那么其 name 属性就不会包含值，本章后面会讨论。

还有一个 self 对象，它是终极 window 属性，始终会指向 window。实际上，self 和 window 就 是同一个对象。之所以还要暴露 self，就是为了和 top、parent 保持一致。

这些属性都是 window 对象的属性，因此访问 window.parent、window.top 和 window.self 都可以。这意味着可以把访问多个窗口的 window 对象串联起来，比如 window.parent.parent

### 窗口位置和像素比

window对象的位置可以通过其 screenLeft 和 screenTop 属性来表示窗口相对于屏幕左侧和顶部的位置，这两个属性返回的都是css像素。可以使用 moveTo()和 moveBy()方法移动窗口（注意非window.open打开的窗口不能使用moveTo,moveBy方法来控制）

window.moveTo接收一个绝对位置坐标
window.moveBy是接收一个相对位置坐标

```js
// 把窗口移动到左上角 
window.moveTo(0,0);
// 把窗口向下移动 100 像素 
window.moveBy(0, 100);
```

上述这两个方法具体效果以浏览器而定。
**像素比**

CSS 像素是 Web 开发中使用的统一像素单位。这个单位的背后其实是一个角度:0.0213°。如果屏 幕距离人眼是一臂长，则以这个角度计算的 CSS 像素大小约为 1/96 英寸。这样定义像素大小是为了在 不同设备上统一标准。比如，低分辨率平板设备上 12 像素(CSS 像素)的文字应该与高清 4K 屏幕下 12 像素(CSS 像素)的文字具有相同大小。这就带来了一个问题，不同像素密度的屏幕下就会有不同的 缩放系数，以便把物理像素(屏幕实际的分辨率)转换为 CSS 像素(浏览器报告的虚拟分辨率)。

举个例子，手机屏幕的物理分辨率可能是 1920×1080，但因为其像素可能非常小，所以浏览器就需 要将其分辨率降为较低的逻辑分辨率，比如 640×320。这个物理像素与 CSS 像素之间的转换比率由 window.devicePixelRatio 属性提供。对于分辨率从 1920×1080 转换为 640×320 的设备，window. devicePixelRatio 的值就是 3。这样一来，12 像素(CSS 像素)的文字实际上就会用 36 像素的物理 像素来显示。

window.devicePixelRatio 实际上与每英寸像素数(DPI，dots per inch)是对应的。DPI 表示单 位像素密度，而 window.devicePixelRatio 表示物理像素与逻辑像素之间的缩放系数。

### 窗口大小

所有现代浏览器都支持 4 个属性: innerWidth、innerHeight、outerWidth 和 outerHeight。outerWidth 和 outerHeight 返回浏 览器窗口自身的大小。innerWidth 和 innerHeight 返回浏览器窗口中页面视口的大小

确定视口大小是比较容易的：

```js
let pageWidth = window.innerWidth,
    pageHeight = window.innerHeight;
 if (typeof pageWidth != "number") {
   if (document.compatMode == "CSS1Compat"){
    pageWidth = document.documentElement.clientWidth;
    pageHeight = document.documentElement.clientHeight;
  } else {
    pageWidth = document.body.clientWidth;
    pageHeight = document.body.clientHeight;
  }
}
```

在移动设备上，window.innerWidth 和 window.innerHeight 返回视口的大小，也就是屏幕上 页面可视区域的大小。Mobile Internet Explorer 支持这些属性，但在 document.documentElement. clientWidth 和 document.documentElement.clientHeight 中提供了相同的信息。在放大或缩小 页面时，这些值也会相应变化。

在其他移动浏览器中，document.documentElement.clientWidth 和 document.documentElement. clientHeight 返回的布局视口的大小，即渲染页面的实际大小。布局视口是相对于可见视口的概念， 可见视口只能显示整个页面的一小部分。Mobile Internet Explorer 把布局视口的信息保存在 document.body.clientWidth 和 document.body.clientHeight 中。在放大或缩小页面时，这些 值也会相应变化。

document.body就是返回body标签的宽高信息

另外对于window.open 打开的窗口我们还可以通过 resizeTo()和 resizeBy()方法调整窗口大小

```js
// 缩放到100×100 
window.resizeTo(100, 100);
// 缩放到200×150 
window.resizeBy(100, 50);
// 缩放到300×300 
window.resizeTo(300, 300);
```

注意：与移动窗口的方法一样，缩放窗口的方法可能会被浏览器禁用，而且在某些浏览器中默认是禁用的。 同样，缩放窗口的方法只能应用到最上层的 window 对象。

### 视口位置

度量文档相对于视口滚动距离的属性有两对，返回相等的值:window.pageXOffset/window. scrollX 和 window.pageYOffset/window.scrollY。

pageXOffset/pageYOffset只读属性是scrollX/scrollY的别名，如果有跨浏览器兼容就可以使用pageXOffset/pageYOffset来代替scrollX/scrollY

可以使用 scroll()、scrollTo()和 scrollBy()方法滚动页面

```js
// 相对于当前视口向下滚动 100 像素
window.scrollBy(0, 100);
// 相对于当前视口向右滚动 40 像素 
window.scrollBy(40, 0);
// 滚动到页面左上角 
window.scrollTo(0, 0);
// 滚动到距离屏幕左边及顶边各 100 像素的位置 
window.scrollTo(100, 100);
```

另外这些方法也可以接收一个ScrollToOptions，用于设置滚动方式及距离

```js
// 正常滚动 window.scrollTo({
  left: 100,
  top: 100,
  behavior: 'auto'
});
 // 平滑滚动
window.scrollTo({ 
      left: 100,
      top: 100,
      behavior: 'smooth'
});
```

### 导航与打开新窗口

window.open()方法可以用于导航到指定 URL，也可以用于打开新浏览器窗口。

open方法接收四个参数，分别是：要加载的 URL、目标窗口、特性字符串和表示新窗口在浏览器历史记录中是否替代当前加载页面的布尔值

```js
// 与点击<a href="http://www.wrox.com" target="topFrame"/>相同 
window.open("http://www.wrox.com/", "topFrame");
```

第二个参数也可以是一个特殊的窗口名，比如\_self、 \_parent、\_top 或_blank。

**弹出窗口**

window.open()的第二个参数不是已有窗口，则会打开一个新窗口或标签页。

第三个参数， 即特性字符串，用于指定新窗口的配置（工具栏、地址栏、状态栏等）。不传递第三个参数就是默认值，默认携带浏览器的特效，如果打开的不是新窗口就会忽略第三个参数。

特性字符串是一个逗号分隔的设置字符串，以下是一些选项：

| 设置       | 值          | 说明                                                         |
| ---------- | ----------- | ------------------------------------------------------------ |
| fullscreen | "yes"或"no" | 表示新窗口是否最大化。仅限 IE 支持                           |
| height     | 数值        | 新窗口的高度，这个值不能小于100                              |
| left       | 数值        | 新窗口的x轴坐标，这个值不能是负值                            |
| location   | "yes"或"no" | 表示是否显示地址栏。不同浏览器的默认值也不一样。在设置为"no"时，地址栏 可能隐藏或禁用(取决于浏览器) |
| Menubar    | "yes"或"no" | 表示是否显示菜单栏。默认为"no"                               |
| resizable  | "yes"或"no" | 表示是否可以拖动改变新窗口大小。默认为"no"                   |
| scrollbars | "yes"或"no" | 表示是否可以在内容过长时滚动。默认为"no"                     |
| status     | "yes"或"no" | 表示是否显示状态栏。不同浏览器的默认值也不一样               |
| toolbar    | "yes"或"no" | 表示是否显示工具栏。默认为"no"                               |
| top        | 数值        | 新窗口的 y 轴坐标。这个值不能是负值                          |
| width      | 数值        | 新窗口的宽度。这个值不能小于 100                             |

```js
// 例子 注意特性字符串里不要含有空格 
window.open("http://www.wrox.com/",
                "wroxWindow",
"height=400,width=400,top=10,left=10,resizable=yes");

```

window.open返回一个对新建窗口的引用。这个对象与普通 window 对象没有区别，只是为控制新窗口提供了方便。例如，某些浏览器默认不允许缩放或移动主窗口，但可能允许缩放或移动通过 window.open()创建的窗口。跟使用任何 window 对象一样，可以使用这个对象操纵新打开的窗口。

例如：

```js
 let wroxWin = window.open("http://www.wrox.com/",
                  "wroxWindow",
"height=400,width=400,top=10,left=10,resizable=yes");
// 缩放 
wroxWin.resizeTo(500, 500);
// 移动 
wroxWin.moveTo(100, 100);
// 还可以使用 close()方法像这样关闭新打开的窗口,关闭窗口以后，窗口的引用还在
wroxWin.close();
// 检查窗口关闭状态
wroxWin.closed //true/false 
```

新创建窗口的 window 对象有一个属性 opener，指向打开它的窗口。这个属性只在弹出窗口的最 上层 window 对象(top)有定义，是指向调用 window.open()打开它的窗口或窗格的指针。

```js
wroxWin.alert(wroxWin.opener===window)
```

新建的窗口有指向打开它的窗口的指针，但窗口就需要自行记录自己打开的窗口。

如何检测弹窗被屏蔽了？

```js
let wroxWin = window.open("http://www.wrox.com", "_blank");
// 检测下window.open方法是否返回null
if (wroxWin == null){
  alert("The popup was blocked!");
}

```

除了判断返回值，还需使用try-catch检测，这样就能准确的判断弹窗是否被屏蔽了

### 定时器

js代码在浏览器中是单线程执行，但是允许使用定时器去指定在某个时间之后或者每隔一段时间就执行相应的代码

setTimeout() 用于在一定时间后执行某些代码，而setInterval()用于指定每隔一段时间执行某些代码。

```js
setTimeout(() => alert("Hello world!"), 1000);
```

JavaScript 是单线程的，所以每次只能执行一段代码。为了调度不同代码的执行，JavaScript 维护了一个任务队列。其中的任务会按照添加到队列的先后顺序执行。setTimeout()的第二个参数只是告诉 JavaScript 引擎在指定的毫秒数过后把任务添加到这个队列。如果队列是空的，则会立即执行该代码。如果队列不是空的，则代码必须等待前面的任务执行完才能执行。

调用 setTimeout()时，会返回一个表示该超时排期的数值 ID。这个超时 ID 是被排期执行代码的 唯一标识符，可用于取消该任务。要取消等待中的排期任务，可以调用 clearTimeout()方法并传入超 时 ID，如下面的例子所示:

```js
// 设置超时任务
let timeoutId = setTimeout(() => alert("Hello world!"), 1000);
// 取消超时任务 
clearTimeout(timeoutId);
```

只要是在指定时间到达之前调用 clearTimeout()，就可以取消超时任务。在任务执行后再调用 clearTimeout()没有效果。

setInterval 和setTimeout方法类似，只不过指定的任务会每隔一段时间就执行一次，setInterval的第二个参数，间隔时间指的是向任务队列添加新任务之前等待的时间。

相较于setTimeout，setInterval更需要注重取消定时器，毕竟不取消定时器，这个定时任务就会一直执行到页面卸载。

另外我们还可以使用setTimeout来代替setInterval：

```js
let num = 0;
let max = 10;
let incrementNumber = function() {
num++;
 // 如果还没有达到最大值，再设置一个超时任务
 if (num < max) {
    setTimeout(incrementNumber, 500);
  } else {
    alert("Done");
  }
}
setTimeout(incrementNumber, 500);
```

setIntervale()在实践中很少会在 生产环境下使用，因为一个任务结束和下一个任务开始之间的时间间隔是无法保证的，有些循环定时任务可能会因此而被跳过。而用setTimeout来代替setInterval就不会出现这个问题。一般来说，最好不要使用 setInterval()。

### 系统对话框

使用 alert()、confirm()和 prompt()方法，可以让浏览器调用系统对话框向用户显示消息。

### location

location提供了当前窗口中加载文档的信息，以及通常的导航功能。

location既是window的属性也是document的属性。window.location 和 document.location 指向同一个对象

location的对象属性如下：

| 属性              | 值(例子)                                                  | 说明                                                         |
| ----------------- | --------------------------------------------------------- | ------------------------------------------------------------ |
| location.hash     | "#contents"                                               | URL 散列值(井号后跟零或多个字符)，如果没有则 为空字符串      |
| location.host     | "www.wrox.com:80"                                         | 服务器名及端口号                                             |
| location.hostname | "www.wrox.com"                                            | 服务器名                                                     |
| location.href     | "http://www.wrox.com:80/WileyCDA/ ?q=javascript#contents" | 当前加载页面的完整 URL。location 的 toString() 方法返回这个值 |
| location.pathname | "/WileyCDA/"                                              | URL 中的路径和(或)文件名                                     |
| location.port     | "80"                                                      | 请求的端口。如果 URL 中没有端口，则返回空字符串              |
| location.protocol | "http:"                                                   | 页面使用的协议。通常是"http:"或"https:"                      |
| location.search   | "?q=javascript"                                           | URL 的查询字符串。这个字符串以问号开头                       |
| location.username | "foouser"                                                 | 域名前指定的用户名                                           |
| location.password | "barpassword"                                             | 域名前指定的密码                                             |
| location.origin   | "http://www.wrox.com"                                     | URL 的源地址。只读                                           |

#### 查询字符串

location多数的信息都是从这个字符串里去获得，以下是一个方法来解析查询字符串获取每一个参数值：

```js
let getQueryStringArgs = function() {
// 取得没有开头问号的查询字符串
let qs = (location.search.length > 0 ? location.search.substring(1) : ""),
// 保存数据的对象 args = {};
// 把每个参数添加到 args 对象
for (let item of qs.split("&").map(kv => kv.split("="))) {
        let name = decodeURIComponent(item[0]),
          value = decodeURIComponent(item[1]);
        if (name.length) {
          args[name] = value;
        } 
}
   return args;
}
```

####    URLSearchParams

URLSearchParams 提供了一组标准 API 方法，通过它们可以检查和修改查询字符串。给 URLSearchParams 构造函数传入一个查询字符串，就可以创建一个实例。这个实例上暴露了 get()、 set()和 delete()等方法，可以对查询字符串执行相应操作。下面来看一个例子:

```js
  const str ='http://www.baidu.com?name=zhangsan&age=18&biz=9908584&name=999'

  function querySearch(str) {
    // 首先获取查询字符串中的？部分
    const searchIndex = Array.prototype.findIndex.call(str,item => item === '?');
    const searchStr = str.slice(searchIndex+1);

    let searchParams = new URLSearchParams(searchStr);
    console.log(searchParams.size);
    console.log(searchParams.get('name'));
    console.log(searchParams.get('age'));
    console.log(searchParams.get('biz'));
    console.log(searchParams.getAll('name'));
  }
```

#### 修改操作地址

可以用过location来修改操作地址。使用location中的assign方法并传入一个URL。

```js
location.assign('http://www.baidu.com')
```

上述代码执行后会立即导航到新的地址并且在浏览器的历史记录里新增一条记录。另外修改location.href 和window.location也是和assign一样的效果

```js
// 和location.assign('http://www.baidu.com') 调用的效果一致
window.location = "http://www.baidu.com";
location.href = "http://www.baidu.com";
```

另外修改以下这些属性也会导致修改当前的URL

```js
// 假设当前URL为http://www.wrox.com/WileyCDA/
// 把URL修改为http://www.wrox.com/WileyCDA/#section1
location.hash = "#section1";
// 把URL修改为http://www.wrox.com/WileyCDA/?q=javascript 
location.search = "?q=javascript";
// 把URL修改为http://www.somewhere.com/WileyCDA/ 
location.hostname = "www.somewhere.com";
// 把URL修改为http://www.somewhere.com/mydir/ 
location.pathname = "mydir";
// 把URL修改为http://www.somewhere.com:8080/WileyCDA/ 
location.port = 8080;
```

上述属性修改除了hash外其他的属性被修改了都会触发页面重新加载。

**注意** 修改hash的值会在浏览器历史中增加一条新记录。在早期的IE中，点击“后退” 和“前进”按钮不会更新 hash 属性，只有点击包含散列的 URL 才会更新 hash 的值。

如果不想修改url后增加浏览器的历史记录，我们可以使用replace方法来修改url。这个方法的参数也是接收一个URL参数，但是重新加载后不会增加历史记录。用户不能通过返回按钮返回到上一个页面。

```js
 setTimeout(() => {
    location.replace('http://www.baidu.com')
  },3000);
```

最后一个修改url的方法是reload方法，这个方法能重新加载当前显示的页面:

可以传递一个参数true，表示强制加载不走缓存这块儿true这个参数并不是标准 [详情](https://developer.mozilla.org/zh-CN/docs/Web/API/Location/reload#location.reload_%E6%B2%A1%E6%9C%89%E5%8F%82%E6%95%B0)。

```js
// 重新加载，可能是从缓存加载 
location.reload(); 
// 重新加载，从服务器加载()
location.reload(true); 
```

另外注意在reload后的代码不确定是否能够执行，所以尽量将reload这个方法放置在最后一行。

### navigator

navigator主要用于识别客户端浏览器的标准，确定浏览器的类型。对于不同的浏览器navigator也有对应浏览器支持的属性。

### screen

screen对象中保存的纯粹是客户端能力信息，以下是一些screen上的属性：

![image-20230526155746275](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230526155746275.png)

### history

history对象表示当前窗口首次使用以来用户的导航历史记录，history是window的属性，所以每个history都有自己的history的对象。当然出于安全考虑，找个对象不会暴露用户访问过的URL，但可以操作网页的前进和后退。

#### go

Go方法可以再用户历史记录中沿着任意方向导航，可以前进可以后退，接收一个证书作为参数，表示前进或者后退多少步，负值表示后退。

```js
// 后退一页 
history.go(-1);
// 前进一页 
history.go(1);
// 前进两页 
history.go(2);
```

另外go也有两个简写的办法，back和forward

```js
// 后退一页  等价 history.go(-1);
history.back();
// 前进一页 等价 history.go(1);
history.forward();
```

history还有一个length属性，表示历史记录中有多个条目，如果length等于1，就表示这个页面是用户窗口的第一个页面

#### 历史的状态管理

HTML5 为 history 对象增加了方便的状态管理特性。hashchange会在页面 URL 的散列变化时被触发，开发者可以在此时执行某些操作。

状态管理 API 则可以让开发者改变浏览器 URL 而不会加载新页面。为此，可以使用 history.pushState()方 法。这个方法接收 3 个参数:一个 state 对象、一个新状态的标题和一个(可选的)相对 URL。

```js
let stateObject = {foo:"bar"};
history.pushState(stateObject, "My title", "baz.html");
```

pushState()方法执行后，状态信息就会被推到历史记录中，浏览器地址栏也会改变以反映新的相 对 URL。第二个参数并未被所有浏览器实现，所以可传递一个空字符串也可以传递一个短标题。第一个参数应该包含正确初始化页面状态所必需的信息。另外第一个参数对于数据的大小是有限制的，一般在500kb～1mb。

pushState调用后会创建一个历史记录，所以会导致浏览器左上角返回按钮激活（这里并不一定激活，得看场景）如果不想保存本次记录，可以使用replaceState并传入与pushState()同样的前两个参数来更新状态。更新状态不会创建新历史记录，只会覆盖当前状态

```js
history.replaceState({newFoo: "newBar"}, "New title", 'new-url');
```

点击浏览器左上角后退按钮会触发popstate，popstate事件对象里有一个state属性其 中包含通过 pushState()第一个参数传入的 state 对象:

```js
window.addEventListener("popstate", (event) => { let state = event.state;
if (state) { // 第一个页面加载时状态是null
   console.log(state)
  }
});
```

注意：

1. 传给 pushState()和 replaceState()的 state 对象应该只包含可以被序列化的信息。因此， DOM 元素之类并不适合放到状态对象里保存。
2. 使用HTML5状态管理时，要确保通过pushState()创建的每个“假”URL背后 都对应着服务器上一个真实的物理 URL。否则，单击“刷新”按钮会导致 404 错误。所有 单页应用程序(SPA，Single Page Application)框架都必须通过服务器或客户端的某些配 置解决这个问题(一般来讲，使用React-router或者vue-router可以在服务器设置所有地址都重定向到index.html,将url交给前端处理)。

## 客户端检测

### 能力检测

检测浏览器是否支持某种特性，一般使用如下方式：

```js
if (object.propertyInQuestion) { // 使用  
  object.propertyInQuestion
}
```

再比如，IE5以前没有getElementById这个方法，可以使用如下方式：

```js
function getElement(id) {
      if (document.getElementById) {
        return document.getElementById(id);
      } else if (document.all) {
        return document.all[id];
      } else {
        throw new Error("No way to retrieve element!");
      }
  }
```

这里也要注意两种方法都要检测 document.getElementById不存在也不代表document.all也存在。

### 安全能力检测

检测一个对象里是否含有某个方法，以下是一个检测是否有sort方法的错误示范：

```js
// 不要这样做!错误的能力检测，只能检测到能力是否存在
function isSortable(object) {
      return !!object.sort;
 }
```

要检测一个方法，最好使用类型来判断：

```js
// 好一些，检测 sort 是不是函数 
function isSortable(object) {
  return typeof object.sort === 'function';
}
```

但是有时光使用typeof还不够，某些宿主对象并不能保证typeof测试返回合理的值，不过如今IE已不复存在也无需考虑了。

### 检测特性

检测浏览器是否支持某一特性：

```js
// 检测浏览器是否支持 Netscape 式的插件
let hasNSPlugins = !!(navigator.plugins && navigator.plugins.length);
// 检测浏览器是否具有 DOM Level 1 能力
let hasDOM1 = !!(document.getElementById && document.createElement &&
             document.getElementsByTagName);
```

注意：能力检测一般用于决定下一步该如何做，是否可做，而不能作为辨识浏览器的表示。

### 用户代理检测

用户代理检测通过浏览器的用户代理字符串确定使用的是什么浏览器。用户代理字符串包含在每个 HTTP 请求的头部，在 JavaScript 中可以通过 navigator.userAgent 访问。注意这种方式获取的用户代理是不可靠的。因为用户可能会造假来欺骗服务器。

实现了window.navigator 对象的浏览器(即所有现代浏览器)都会提供 userAgent 这个只读属性。因此， 简单地给这个属性设置其他值不会有效:

```js
console.log(window.navigator.userAgent);
window.navigator.userAgent = 'footbar'
console.log(window.navigator.userAgent);
```

当然，通过简单的办法可以绕过这个限制。比如，有些浏览器提供伪私有的\__defineGetter\__方法， 利用它可以篡改用户代理字符串:

```js
window.navigator.__defineGetter__('userAgent', () => 'foobar');
console.log(window.navigator.userAgent);
```

所以如果怀疑用户篡改了用户代理，那最好还是使用能力检测吧。

### 分析浏览器

通过解析浏览器返回的用户代理字符串，可以极其准确地推断出下列相关的环境信息:

- 浏览器 
-  浏览器版本
- 浏览器渲染引擎
- 设备类型(桌面/移动)
- 设备生产商
- 设备型号
- 操作系统
- 操作系统版本

当然，目前操作系统和硬件都是在不断更新，所以浏览器检测也需要与时俱进。以下推荐一些经常维护的第三方代理解析程序：可在github上搜搜

1. Bowser
2. UAParser.js--推荐这个
3. Platform.js
4. CURRENT-DEVICE
5. Google Closure
6. Mootools

### 浏览器元数据

navigator 对象暴露出一些 API，可以提供浏览器和操作系统的状态信息。

#### Geolocation API

navigator.geolocation 属性暴露了 Geolocation API，可以让浏览器脚本感知当前设备的地理位 置。这个 API 只在安全执行环境(通过 HTTPS 获取的脚本)中可用。

这个 API 可以查询宿主系统并尽可能精确地返回设备的位置信息。根据宿主系统的硬件和配置，返回结果的精度可能不一样。手机 GPS 的坐标系统可能具有极高的精度，而 IP 地址的精度就要差很多。

根据 Geolocation API 规范:地理位置信息的主要来源是 GPS 和 IP 地址、射频识别(RFID)、Wi-Fi 及蓝牙 Mac 地址、GSM/CDMA 蜂窝 ID 以及用户输入等信息。

另外对于没有GPS的浏览器所在系统，浏览器会通过网络来获取大致定位（根据附近wifi，基站，网络数据库）

```js
var options = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0
};

function success(pos) {
  var crd = pos.coords;

  console.log('Your current position is:');
  console.log('Latitude : ' + crd.latitude);
  console.log('Longitude: ' + crd.longitude);
  console.log('More or less ' + crd.accuracy + ' meters.');
};

function error(err) {
  console.log(err)
  console.warn('ERROR(' + err.code + '): ' + err.message);
};

navigator.geolocation.getCurrentPosition(success, error, options);
```

#### Connection State 和 NetworkInformation API

浏览器会跟踪网络连接状态并以两种方式暴露这些信息.

在设备链接到网络时，浏览器会记录这个事实并在window对象上触发online事件，相反，断开网络时秒会触发offline，可以直接通过navigator. onLine 属性来确定浏览器的联网状态。这个属性返回一个布尔值，表示浏览器是否联网。

```js
const connectionStateChange = () => console.log(navigator.onLine);
window.addEventListener('online', connectionStateChange); window.addEventListener('offline', connectionStateChange);
```

当然上述的判断只是保证用户连接上了局域网，不能保证用户真正的接入到了局域网。

navigator中的 NetworkInformation API，可以通过 navigator.connection 属性使用。 这个 API 提供了一些只读属性，并为连接属性变化事件处理程序定义了一个事件对象。

以下是一些属性的含义：注意根据不同设备这个对象返回的属性有所不同
![image-20230530135308865](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230530135308865.png)

| downlink      | 表示当前设备的带宽(以 Mbit/s 为单位)，舍入到最接近的 25kbit/s。这个值可能会根据历史网络吞吐量计算，也可能根据连接技术的能力来计算 |
| ------------- | ------------------------------------------------------------ |
| effectiveType | 字符串枚举值，表示连接速度和质量。这些值对应不同的蜂窝数据网络连接技术，但也用于分类无线网络。这个值有以下 4 种可能 slow-2g,2g,3g,4g<br /> slow-2g 往返时间 > 2000ms下行带宽 < 50kbit/s <br />2g 2000ms > 往返时间 ≥ 1400ms,70kbit/s > 下行带宽 ≥ 50kbit/s <br />3g 1400ms > 往返时间 ≥ 270ms,700kbit/s > 下行带宽 ≥ 70kbit/s<br /> 4g 270ms > 往返时间 ≥ 0ms,下行带宽 ≥ 700kbit/s |
| rtt           | 表示当前网络实际的往返时间，舍入为最接近的 25 毫秒。这个值可能根据历史网络吞吐量计算，也可能根据连接技术的能力来计算 |
| type          | 表示网络连接技术，可能有以下几种值：<br />bluetooth 蓝牙<br />cellular 蜂窝<br />ethernet 以太网<br />none ，相当于 navigator.onLine === false<br />mixed 多种混合<br />other 其他<br />unknown 不确定<br />wifi Wi-Fi<br />wimax wiMax |
| saveData      | 布尔值，表示用户设备是否启用了“节流”(reduced data)模式       |
| onchange      | 事件处理程序，会在任何连接状态变化时激发一个 change 事件<br />  可以通过 navigator.connection.addEventListener('change',changeHandler)或 navigator.connection. onchange = changeHandler 等方式使用。 |
|               |                                                              |

 #### Battery Status AP

返回设备电池相关信息的API

#### 其他硬件信息

**处理器核心数**

返回浏览器支持的逻辑处理器核心数量，包含表示核心数的一个整数值(如果核心数无法确定，这个值就是 1)。关键在于，这个值表示浏览器可以并行执行的 最大工作线程数量，不一定是实际的 CPU 核心数。

```js
navigator.hardwareConcurrency
```

**设备的内存地址**

navigator.deviceMemory 属性返回设备大致的系统内存大小，包含单位为 GB 的浮点数(舍入为最接近的 2 的幂:512MB 返回 0.5，4GB 返回 4)。

```js
navigator.deviceMemory
```

**最大触点数**

返回触摸屏支持的最大关联触点数

```js
navigator.maxTouchPointsh
```

#### 总结

1. 浏览器也提供了一些软件和硬件相关的信息。这些信息通过 screen 和 navigator 对象暴露出来。 利用这些 API，可以获取关于操作系统、浏览器、硬件、设备位置、电池状态等方面的准确信息。

## DOM 

### Node类型

Node类型接口是所有DOM节点都必须实现的，所有的节点类型都继承Node类型，所以所有的类型都共享相同的方法和属性

#### 节点关系

每个节点都有一个childNodes属性，其包含一个NodeList实例。NodeList是一个类数组对象。NodeList是实时的活动对象，我们从中拿到的永远是最新的。

每个节点都有一个parentNode，指向DOM树中的父元素，childNodes中的每一个节点的parentNode都指向同一个父节点

childNodes列表中的每一个节点都是同一列表中的其他节点的兄弟节点。使用 previousSibling 和 nextSibling 可以在这个列表的节点间导航。这个列表中第一个节点的 previousSibling 属性是 null，最后一个节点的 nextSibling 属性也是 null。如果childNodes中只有一个节点，则其previousSibling和nextSibling都是null

父节点也有特殊的属性，firstChild 和 lastChild 分别指向 childNodes 中的第一个和最后一个子节点。

下图为Node的关系图

![image-20230817161023975](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230817161023975.png)

#### 操纵节点

appendChild(newNode) 用于在childNodes列表末尾添加节点 方法返回新添加的节点。另外如果把已经存在在文档中的节点传递给appendChild 则该节点会被转移到新位置。

insertBefore(newNode, referenceNode) 可以将节点放置到指定节点前。方法接收两个参数:要插入的节点和参照节点。调用这个方法后，要插入的节点会变成参照节点的 前一个同胞节点，并被返回。如果参照节点是 null，则 insertBefore()与 appendChild()效果相同。

replaceChild(newNode, replaceNode)  替换节点  方法传递两个参数 要插入的节点和要替换的节点。

removeChild() 方法接收一个参数，要移除的节点

cloneNode() 表示复制节点 参数为布尔值，true表示深复制，false为浅复制，浅复制返回调用该方法的节点。注意：cloneNode只会复制html属性，不会复制js属性，比如事件处理，所以推荐在复制前先删除事件处理程序。

### Document类型

表示文档节点的类型

对html标签的引用 document.documentElement或者document.firstChild

对body标签的引用 document.body

对<!doctype>的引用 document.doctype

文档标签文本 document.title 可读可写的属性

#### 定位元素

document.getElementById() 根据id来查找节点

document.getElementsByTagName 根据标签名查找对应节点

document.getElementsByName 根据标签name属性查找对应节点

document.images 包含文档中所有<img>元素

document.links 包含文档中所有带 href 属性的<a>元素

### Element 类型

最常用的类型了

#### html元素

一般有以下属性

id title classname 等

#### 属性获取

getAttribute()、setAttribute()和 removeAttribute()。

#### 创建元素

document.createElement()方法创建新元素 方法接受需要创建的元素标签名。
如：document.createElement('div')

### Text类型

文本类型吧，不包含html代码

### Comment类型

注释类型

不支持子元素

```html
<!-- xx -->
```

### CDATASection 类型

不支持子元素。表示 XML 中特有的 CDATA 区块。CDATASection 类型继承 Text 类型，因 此拥有包括 splitText()在内的所有字符串操作方法。CDATA 区块只在 XML 文档中有效

### DocumentType 类型

不支持子节点 该节点包含文档类型信息

### **DocumentFragment**类型

不能直接把文档片段添加到文档。相反，文档片段的作用是充当其他要被添加到文档的节点的仓库。

可以使用 document.createDocumentFragment()方法像下面这样创建文档片段:

```js
let fragment = document.createDocumentFragment();
```

这个类型的作用可以用在优化上，假如我们需要给ul添加三个li，如果使用传统的分三次添加li，那么浏览器就需要刷新3次。为了避免多次渲染我们可以先将li添加到文档片段里，在一次性加到ul中

```js
    let fragment = document.createDocumentFragment();
    let ul = document.getElementById("myList");
 for (let i = 0; i < 3; ++i) { 
   let li = document.createElement("li");
li.appendChild(document.createTextNode(`Item ${i + 1}`));
fragment.appendChild(li);
 }
    ul.appendChild(fragment);
```

### Attr类型

可以使用以下方式来创建和获取元素的属性：

```js
  const element = document.getElementsByTagName('div')[0];
  console.log(element);
  let attr = document.createAttribute("align");
  attr.value = "left";
  element.setAttributeNode(attr);
  alert(element.attributes["align"].value); 
  alert(element.getAttributeNode("align").value); 
  alert(element.getAttribute("align")); // 推荐这种方式获取属性 
```

### 动态脚本

可以通过如下方式添加一个动态脚本：

```js
let script = document.createElement("script");
    script.src = "foo.js";
    document.body.appendChild(script);
```

也可以插入一些代码：

```js
    let script = document.createElement("script");
    var code = "function sayHi(){alert('hi');}; sayHi()";
    script.type = "text/javascript";
    //script.src = "foo.js";
    
script.appendChild(document.createTextNode(code)) // createTextNode 这个方法还可以用来转义html字符
    document.body.appendChild(script);
```

注意，通过 innerHTML 属性创建的<script>元素永远不会执行。浏览器会尽责地创建<script> 元素，以及其中的脚本文本，但解析器会给这个<script>元素打上永不执行的标签。只要是使用 innerHTML 创建的<script>元素，以后也没有办法强制其执行。

### 动态样式

```js
    let link = document.createElement("link");
    link.rel = "stylesheet";
    link.type = "text/css";
    link.href = "styles.css";
    let head = document.getElementsByTagName("head")[0];
    head.appendChild(link);
```

插入一些样式代码：

```js

let style = document.createElement("style");
style.type = "text/css"; style.appendChild(document.createTextNode("body{background-color:red}")); let head = document.getElementsByTagName("head")[0]; head.appendChild(style);
```

### MutationObserver 接口

可以在dom被修改的时候异步执行回调。MutationObserver 可以观察整个文档、DOM 树的一部分，或某个元素。此外还可以观察元素属性、可以观察整个文档、DOM 树的一部分，或某个元素。此外还可以观察元素属性、子节点、文本，或者前三者任意组合的变化。

#### 使用方式

过调用 MutationObserver 构造函数并传入一个回调函数来创建: 

```js
let observer = new MutationObserver(() => console.log('DOM was mutated!'));
```

#### observe 方法

该方法是将我们创建的observer关联到dom上，所以这个方法有两个必要参数，第一个是要观察变化的dom的节点，第二个是一个MutationObserverInit对象，用于配置观察那些方面的变化。

#### 回调与 MutationRecord

当观察到所配置的选项发生变化时就会执行创建observer时所传入的回调函数。回调函数会接受一个MutationRecord实例数组，里边包含了观察dom发生了什么变化以及影响范围。

#### disconnect() 方法

停止此后变化事件的回调，也会抛弃已经加入任务队列要异步执行的回调。会停止观察所有目标

## DOM扩展

### selectors API

#### querySelector() 方法

接收css选择符参数，返回匹配该模式的第一个后代元素

```js
// 取得<body>元素
let body = document.querySelector("body");
// 取得 ID 为"myDiv"的元素
let myDiv = document.querySelector("#myDiv");
```

#### querySelectorAll()

跟 querySelector()一样，也接收一个用于查询的参数，但它会返回 所有匹配的节点，而不止一个。这个方法返回的是一个 NodeList 的静态实例

#### matches() 方法

接受一个css选择符参数，如果元素匹配则返回true，否则false

### html5

#### css类扩展

#### getElementsByClassName()
```js
// 取得所有类名中包含"username"和"current"元素
// 这两个类名的顺序无关紧要
let allCurrentUsernames = document.getElementsByClassName("username current");
// 取得 ID 为"myDiv"的元素子树中所有包含"selected"类的元素
let selected = document.getElementById("myDiv").getElementsByClassName("selected");
```

#### classList 属性

```js
// 删除"disabled"类 div.classList.remove("disabled");
// 添加"current"类 div.classList.add("current");
```

#### 自定义数据属性

```js
<div id="myDiv" data-appId="12345" data-myname="Nicholas"></div>
```

可以通过元素的 dataset 属性来访问

```js
let div = document.getElementById("myDiv");
// 取得自定义数据属性的值
let appId = div.dataset.appId; let myName = div.dataset.myname;
```

#### 插入标记

innerHTML属性，注意防止xss

innerText 插入文本节点

#### scrollIntoView()

滚动相关

#### children属性

只会包含Element类型的子节点，而childNodes不一定

## DOM2/3

### 样式

存取元素样式：

```js
// 修改大小
myDiv.style.width = "100px"; myDiv.style.height = "200px";
```

多个css样式修改：

```js
myDiv.style.cssText = "width: 25px; height: 100px; background-color: green";// 注意：给 cssText 赋值会重写整个 style 属性的值
console.log(myDiv.style.cssText);
```

计算样式：

getComputedStyle()

#### 元素尺寸

- 偏移尺寸
  - offsetHeight 元素在垂直方向上占用的像素尺寸
  -  offsetLeft，元素左边框外侧距离包含元素左边框内侧的像素数。
  - offsetTop，元素上边框外侧距离包含元素上边框内侧的像素数。
  - offsetWidth，元素在水平方向上占用的像素尺寸，包括它的宽度、垂直滚动条宽度(如果可见)和左、右边框的宽度。

![image-20230818104501632](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818104501632.png)

- 客户端尺寸
  - clientWidth 是内容区宽度加左、右内边距宽度。
  - clientHeight 是内容区高度加上、下内边距高度。

![image-20230818104714284](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818104714284.png)

- 滚动尺寸
  -  scrollHeight，没有滚动条出现时，元素内容的总高度。
  - scrollLeft，内容区左侧隐藏的像素数，设置这个属性可以改变元素的滚动位置。 
  - scrollTop，内容区顶部隐藏的像素数，设置这个属性可以改变元素的滚动位置。 
  - scrollWidth，没有滚动条出现时，元素内容的总宽度。

![image-20230818105333278](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818105333278.png)

- 确定元素尺寸

  浏览器在每个元素上都暴露了 getBoundingClientRect()方法，返回一个 DOMRect 对象，包含 6 个属性:left、top、right、bottom、height 和 width。

![image-20230818105448020](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818105448020.png)

## 事件

### 事件冒泡

从文档中最深的节点开始触发最后向上传播到不怎么具体的节点上

![image-20230818110507457](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818110507457.png)

### 事件捕获

事件捕获是最不具体的节点先收到事件，最具体的节点最后收到

![image-20230818110631087](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818110631087.png)

### DOM事件流

规定事件分为三个阶段 事件捕获，到达目标，事件冒泡

![image-20230818110829842](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230818110829842.png)

### 事件处理程序

div.onclick 该方式只能设置一个处理事件程序

使用addEventListener()和 removeEventListener()。可以同时设置多个事件处理程序。

## 动画和canvas图形

### **requestAnimationFrame** 

在浏览器重绘前调用。该方法接受一个参数，回调函数。

**requestAnimationFrame**只会调用一次传入的函数，所以我们需要在每次更新屏幕前手动调用

传给 requestAnimationFrame()的函数实际上可以接收一个参数，此参数是一个 DOMHighRes- TimeStamp 的实例(比如 performance.now()返回的值)，表示下次重绘的时间。这一点非常重要: requestAnimationFrame()实际上把重绘任务安排在了未来一个已知的时间点上，而且通过这个参数 告诉了开发者。基于这个参数，就可以更好地决定如何调优动画了。

**cancelAnimationFrame** 和setTimeout类似的取消调用的函数。

```js

let requestID = window.requestAnimationFrame(() => {
  console.log('Repaint!');
     window.cancelAnimationFrame(requestID);
```

### 基本画布功能

canvas

## JS API

### 原子操作基础

Atomics对象

### 跨上下文消息

跨文档消息，也称为XDM（cross-document messaging）

核心方法是postMessage()。该方法可以安全的进行跨源通信。一般用于 主窗口和iframe进行通信或者不同标签之间的通信

使用方式

发送信息

```js
otherWindow.postMessage(message, targetOrigin, [transfer]);
```

- otherWindow 其他窗口的一个引用比如 iframe 的 contentWindow 属性、执行[window.open](https://developer.mozilla.org/zh-CN/docs/Web/API/Window/open)返回的窗口对象、或者是命名过或数值索引的[window.frames](https://developer.mozilla.org/en-US/docs/Web/API/Window/frames)
- message 要发送的数据，会被序列化
- targetOrigin 指定要发送的窗口源 其值可以是字符串"*"（表示无限制）或者一个 URI。在发送消息的时候，如果目标窗口的协议、主机地址或端口这三者的任意一项不匹配 targetOrigin 提供的值，那么消息就不会被发送；只有三者完全匹配，消息才会被发送。
- `transfer` 可选 ，是一串和 message 同时传递的 `Transferable` 对象。这些对象的所有权将被转移给消息的接收方，而发送一方将不再保有所有权。

有一点注意，message 最初实现始终是一个字符串。后来， 第一个参数改为允许任何结构的数据传入，不过并非所有浏览器都实现了这个改变。为此，最好就是只 通过 postMessage()发送字符串。如果需要传递结构化数据，那么最好先对该数据调用 JSON.stringify()，通过 postMessage()传过去之后，再在 onmessage 事件处理程序中调用 JSON.parse()。

接收信息

```js
    window.addEventListener('message', (event) => {
      // 确保来源是预期的对象
      if (event.origin == "http://example.com") {
        console.log(event);
      }
    })
```

### Encoding API

主要有四个全局类

TextEncoder、TextEncoderStream、TextDecoder 和 TextDecoderStream。

#### 文本编码

Encoding API 提供了两种方式将字符串转为定型数组二进制（批量编码和流编码），其编码是用的格式为utf-8

1. 批量编码 TextEncoder

   js引擎会同步编码整个字符串，对于长字符串可能会消耗大量时间

   ```js
         const textEncoder = new TextEncoder();
         const decodedText1 = '我是谁';
         const decodedText2 = 'foo';
         const encodedText1 = textEncoder.encode(decodedText1);
         const encodedText2 = textEncoder.encode(decodedText2);
         console.log(encodedText1);
         console.log(encodedText2);
   // f 的 UTF-8 编码是 0x66(即十进制 102)
   // o 的 UTF-8 编码是 0x6F(即二进制 111)
   ```

   ![image-20230821150514318](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230821150514318.png)

一些其他字符，中文，emoji 可能会占用个索引.

TextEncoder实例还有一个encodeInto方法，该方法接受一个字符串和一个Uint8Array，返回一个字典，字典包含read和written属性，表示成功从源读区了多少字符串和向目标数组写入了多少字符串，如果数组空间不够就会终止

```js
      const textEncoder = new TextEncoder();
      const decodedText1 = 'bar';
      const decodedText2 = 'foo';
      const barRes = textEncoder.encodeInto(decodedText1, new Uint8Array(3))
      const fooRes = textEncoder.encodeInto(decodedText1, new Uint8Array(2))
      console.log(barRes);
      console.log(fooRes);
      // {read: 3, written: 3}
      // {read: 2, written: 2}
```

和encode相比，encode要求分配一个新的 Unit8Array，而encodeInto则可以让我们手动设置接受数组的大小，所以在需要性能优化的地方 encodeInto这个差别可能就会起作用。

注意：文本编码会始终使用UTF-8格式，而且必须写入Unit8Array实例。使用其他类 型数组会导致 encodeInto()抛出错误。

2. 流编码

TextEncoderStream ，其实就是 TransformStream形式的TextEncoder

```js
 async function* chars() {
      const decodeText = 'foo';
      for (let char of decodeText) {
        yield await new Promise((resolve) => setTimeout(resolve, 1000, char));
      }
    }

    function start() {
      // 将异步迭代器转换为可读流
      return new ReadableStream({
        async pull(controller) {
          for await (const iterator of chars()) {
            controller.enqueue(iterator);
          }
          controller.close();
        },
      });
    }


    const decodedTextStream = start();
    
    // 将要编码的内容写进去
    const encodedTextStream = decodedTextStream.pipeThrough(new TextEncoderStream());
    const w = encodedTextStream.getReader();

    (async function () {
      while (true) {
        const { done, value } = await readableStreamDefaultReader.read();
        if (done) {
          break;
        } else {
          console.log(value);
        }
      }
    })()
```

打印结果就是每隔一秒输出一个编码结果

![image-20230821153813469](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230821153813469.png)

#### 文本解码

和编码类似，也是有两种方式，批量解码和流解码

与 TextEncoder 不同，TextDecoder 可以兼容很多字符编码。

1.批量解码

```js
    // 默认utf-8 当然可以传入其他格式，这也是和textEncoder不一样的一点
    const textDecoder = new TextDecoder();
    const encodeText = Uint8Array.of(102,111,111)
    const decodeText = textDecoder.decode(encodeText);
    console.log(decodeText); // foo
```

表情包解码

```js
  const textDecoder = new TextDecoder();
// ☺的UTF-8编码是0xF0 0x9F 0x98 0x8A(即十进制240、159、152、138)
const encodedText = Uint8Array.of(240, 159, 152, 138);
const decodedText = textDecoder.decode(encodedText);
console.log(decodedText); // ☺
```

2. 流解码

和流编码类似

```js
    async function* chars() {
      // 注意每一个块必须是一个定型数组

      const enodeText = [102,111,111].map(item => Uint8Array.of(item));
      for (let char of enodeText) {
        yield await new Promise((resolve) => setTimeout(resolve, 1000, char));
      }
    }

    function start() {
      // 将异步迭代器转换为可读流
      return new ReadableStream({
        async pull(controller) {
          for await (const iterator of chars()) {
            controller.enqueue(iterator);
          }
          controller.close();
        },
      });
    }


    const encodedTextStream = start();

    // 将要解码的内容写进去
    const decodedTextStream = encodedTextStream.pipeThrough(new TextDecoderStream());
    const readableStreamDefaultReader = decodedTextStream.getReader();

    (async function () {
      while (true) {
        const { done, value } = await readableStreamDefaultReader.read();
        if (done) {
          break;
        } else {
          console.log(value);
        }
      }
    })()

// foo 每个字符 间隔1s打印出来
```

      /** 注解
       * 定型数组（Typed Arrays）是一种 JavaScript 对象，用于表示一段特定类型的连续内存区域。
       * 与普通的 JavaScript 数组不同，定型数组允许你在内存中存储和操作原始数据，如整数、浮点数等，
       * 而不是 JavaScript 对象。
       */

另外文本解码器流能够识别可能分散在不同块上的代理对。解码器流会保持块片段直到取得完整的字 符。比如在下面的例子中，流解码器在解码流并输出字符之前会等待传入 4 个块:

```js
    async function* chars() {
      // 注意每一个块必须是一个定型数组
      /**
       * 定型数组（Typed Arrays）是一种 JavaScript 对象，用于表示一段特定类型的连续内存区域。
       * 与普通的 JavaScript 数组不同，定型数组允许你在内存中存储和操作原始数据，如整数、浮点数等，
       * 而不是 JavaScript 对象。
       */
      const enodeText = [240, 159, 152, 138].map(item => Uint8Array.of(item));
      for (let char of enodeText) {
        yield await new Promise((resolve) => setTimeout(resolve, 1000, char));
      }
    }

    function start() {
      // 将异步迭代器转换为可读流
      return new ReadableStream({
        async pull(controller) {
          for await (const iterator of chars()) {
            controller.enqueue(iterator);
          }
          controller.close();
        },
      });
    }


    const encodedTextStream = start();

    // 将要解码的内容写进去
    const decodedTextStream = encodedTextStream.pipeThrough(new TextDecoderStream());
    const readableStreamDefaultReader = decodedTextStream.getReader();

    (async function () {
      while (true) {
        const { done, value } = await readableStreamDefaultReader.read();
        if (done) {
          break;
        } else {
          console.log(value);
        }
      }
    })()
// 等待4s后打印出一个😊
```

当然文本解码器也可以和fetch使用，响应体可以作为 ReadableStream 来处理

```js
const response = await fetch(url);
const stream = response.body.pipeThrough(new TextDecoderStream()); const decodedStream = stream.getReader()
    for await (let decodedChunk of decodedStream) {
      console.log(decodedChunk);
}
```

### File API 和Blob API

#### File类型

File API 仍然以表单中的文件输入字段为基础，增加了直接访问文件信息的能力。HTML5 在 DOM 上为文件输入元素添加了 files 集合。当用户在文件字段中选择一个或多个文件时，这个 files 集合中会包含一组 File 对象，表示被选中的文件。每个 File 对象都有一些只读属性。

- name 本地系统中的文件名
- size 以字节计算的文件大小
- type 包含文件MIME类型的字符串
- lasteModifiedDate 表示最后修改时间的字符串（目前貌似只有chrome实现了。测试了safari打印undefined）

```js
    let filesList = document.getElementById("files-list");
    filesList.addEventListener("change", (event) => {
      let files = event.target.files,
          i = 0,
          len = files.length;
      while (i < len) {
        const f = files[i];
        console.log(`${f.name} (${f.type}, ${f.size} bytes) ${f.lastModifiedDate}`);
        i++;
} });
```

##### FileReader

FileReader 类型是一种异步文件读取机制，可以类比XMLHttpRequest。FileReader提供了以下几种方式读区数据

- readAsText(file, encoding)文件中读取纯文本内容并保存在 result 属性中。第二个 参数表示编码，是可选的。
- readAsDataURL(file):读取文件并将内容的数据 URI 保存在 result 属性。
- readAsBinaryString(file):读取文件并将每个字符的二进制数据保存在 result 属性中。 
- readAsArrayBuffer(file):读取文件并将文件内容以 ArrayBuffer 形式保存在 result 属性。

上述的方式都是异步执行，所以每个FileReader会发布几个事件。其中比较有用的是progress，error，load 表示还有更多数据，发生了错误和读取完成。

```js
    let filesList = document.getElementById("files-list");
    filesList.addEventListener("change", (event) => {

      let info = "",
        output = document.getElementById("output"),
        progress = document.getElementById("progress"), files = event.target.files,
        type = "default",
        reader = new FileReader();
      if (/image/.test(files[0].type)) {
        reader.readAsDataURL(files[0]);
        type = "image";
      } else {
        reader.readAsText(files[0]);
        type = "text";
      }
      reader.onerror = function () {
        output.innerHTML = "Could not read file, error code is " +
          reader.error.code;
      };
      reader.onprogress = function (event) {
        if (event.lengthComputable) {
         progress.innerHTML = `${event.loaded}/${event.total}`;
        }
      };
      reader.onload = function () {
        let html = "";
        console.log(type);
        switch (type) {
          case "image":
            html = `<img src="${reader.result}">`;
            break;
          case "text":
            html = reader.result;
            break;
        }
        // 直接插入大量数据会导致页面卡死
        output.innerHTML = html;
      };
    });
```

读去导入大文件使用上述代码会导致浏览器卡顿,注释掉上述的output.innerHTML = html; 即可优化卡顿

或者使用分片渲染

```js
   let filesList = document.getElementById("files-list");
    filesList.addEventListener("change", (event) => {

      let info = "",
        output = document.getElementById("output"),
        progress = document.getElementById("progress"), files = event.target.files,
        type = "default",
        reader = new FileReader();
        console.log(files[0]);
        // 如果是图片格式就转为图片链接
      if (/image/.test(files[0].type)) {
        reader.readAsDataURL(files[0]);
        type = "image";
      } else {
        // 否则就转为文本
        reader.readAsText(files[0]);
        type = "text";
      }

      // 读取失败的函数
      reader.onerror = function () {
        output.innerHTML = "Could not read file, error code is " +
          reader.error.code;
      };
      // 读取成功的函数
      reader.onprogress = function (event) {
        if (event.lengthComputable) {
          progress.innerHTML = `${event.loaded}/${event.total}`;
        }
      };
      reader.onload = async function () {
        let html = "";
        console.log(type);
        switch (type) {
          case "image":
            html = `<img src="${reader.result}">`;
            break;
          case "text":
            html = reader.result;
            break;
        }
        // 分片读取下
        //output.innerHTML = html;
        // 分片加载
        updateBatch(html, 0, 50, output).then(res => {
          console.log(res);
        })
      };
    });
    // 分片加载
    function updateBatch(data, startIndex, batchSize, div) {
      return new Promise((resolve, reject) => {
        function insert(startIndex) {
          for (let i = startIndex; i < Math.min(startIndex + batchSize, data.length); i++) {
            const item = data[i];
            console.log(item);
            div.appendChild(document.createTextNode(item));
          }
          if (startIndex + batchSize < data.length) {
            requestAnimationFrame(() => {
              insert(startIndex + batchSize);
            });
          } else {
            resolve(true);
          }
        }
        insert(0)
      })
    }
```

##### FileReaderSync

FileReader 的同步版本，拥有相同的方法。只有在整个文件都加载到内存之后才会继续执行。FileReaderSync 只在工作线程中可用， 因为如果读取整个文件耗时太长则会影响全局。

所以对于这个方法我们就结合postMessage()向工作线程发送了一个 File 对象。以下代码会让工作线程同步将文件 读取到内存中，然后将文件的数据 URL 发回来.

```js

// worker.js
self.omessage = (messageEvent) => {
const syncReader = new FileReaderSync(); console.log(syncReader); // FileReaderSync {}
// 读取文件时阻塞工作线程
const result = syncReader.readAsDataUrl(messageEvent.data);
// PDF 文件的示例响应
console.log(result); // data:application/pdf;base64,JVBERi0xLjQK...
// 把URL发回去
      self.postMessage(result);
    };
```

#### Blob

有时我们需要读取文件的一部分，而不是全部文件。所以File对象提供了slice的方法

slice方法有两个参数，起始字节和要读取的字节数方法返回一个Blob的实例。

blob表示二进制大对象，是js对不可修改的二进制数据的封装类型。包含字符串的数组、ArrayBuffers、ArrayBufferViews，甚至其他 Blob 都可以用来创建 blob。Blob 构造函数可以接收一个 options 参数，并在其中指定 MIME 类型（用来标识数据的类型，以便浏览器知道如何正确处理这些数据。MIME（Multipurpose Internet Mail Extensions）类型在网络传输中广泛用于标识不同类型的数据。）:

```js
    console.log(new Blob(['foo']));
    // Blob {size: 3, type: ""}
    console.log(new Blob(['{"a": "b"}'], { type: 'application/json' })); // {size: 10, type: "application/json"}
    console.log(new Blob(['<p>Foo</p>', '<p>Bar</p>'], { type: 'text/html' })); // {size: 20, type: "text/html"}
```

Blob对象中有个type属性和size属性，其中还有个slice方法用于切分数据，另外也可以使用FileReader从Blob中读取数据

```js
    let filesList = document.getElementById("files-list");
    filesList.addEventListener("change", (event) => {
      let info = "", output = document.getElementById("output"),
        progress = document.getElementById("progress"),
        files = event.target.files,
        reader = new FileReader(),
        // File对象继承Blob所以也有slice方法
        blob = files[0].slice(0, 32);
      if (blob) {
        reader.readAsText(blob);
        reader.onerror = function () {
          output.innerHTML = "Could not read file, error code is " +
            reader.error.code;
        };
        reader.onload = function () {
          output.innerHTML = reader.result;
        };
      }
      else {
        console.log("Your browser doesn't support slice().");
      }
    });
```

#### 对象URL和Blob

对象URL也称之为BlobURL，指的是引用存储在File或者Blob中数据的URL。

可以使用window.URL.createObjectURL()，传入File或者Blob对象。这个函数的值是一个指向内存中地址的字符串。因为这个字符串是URL，所以可以在DOM中直接使用。

下面就是如何从文件中获取图片并展示在网页中的

```js
  window.addEventListener('change', (event) => {
    const blob  = new Blob(event.target.files);

    const url = window.URL.createObjectURL(blob);
    const image = document.getElementById('img');
    image.setAttribute('src', url);
  })
```

把对象的URL直接放到img标签上，就不需要把数据先读到js中了。<img>标签可以直 接从相应的内存位置把数据读取到页面上。

使用完数据之后，最好释放与之关联的内存。只要对象 URL 在使用中，就不能释放内存。想表明不再使用某个对象 URL，则可以把它传给 window.URL.revokeObjectURL()。页面卸载时， 所有对象 URL 占用的内存都会被释放。不过，最好在不使用时就立即释放内存，以便尽可能保持页面占用最少资源。

#### 读取拖放文件

这是个非常方便的功能，在一些图片操作上。

可以从桌面上拖动文件到浏览器里，触发drop事件，通过事件中的event.dataTransfer.files读取拖拽的文件。

```js
    let droptarget = document.getElementById("droptarget");
    function handleEvent(event) {
      event.preventDefault();
      let info = "",
        output = document.getElementById("output"),
        files, i, len;

      if (event.type == "drop") {
        files = event.dataTransfer.files;
        i = 0;
        len = files.length;
        while (i < len) {
          info += `${files[i].name} (${files[i].type}, ${files[i].size} bytes)<br>`;
          const imageFile = files[i];
          const imageElement = document.getElementById('image');
          const imageURL = URL.createObjectURL(new Blob([imageFile]));
          imageElement.setAttribute('src', imageURL);
          i++;
        }
        output.innerHTML = info;

      }
    }
    droptarget.addEventListener("dragenter", handleEvent);
    droptarget.addEventListener("dragover", handleEvent);
    droptarget.addEventListener("drop", handleEvent);
```

注意：必须取消dragenter、dragover 和 drop事件的默认行为。比如chrome的默认行为就是直接新开一个标签展示图片

#### 媒体元素

html5新增了两个与媒体相关的元素标签

```html
<audio></audio> 
<video></video>
```

元素要求至少有一个src属性，表示要加载的媒体文件。

一些其他常用属性：

- poster 视频加载期间显示的占位图也可以使用poster来设置图片URI
- controls 控制浏览器是否显示播放界面，让用户直接控制媒体
- ...

另外由于浏览器支持的媒体格式不同，所以可以指定多个不同的媒体源，为此需要从元素中删除src属性，并在标签内部添加一个或者多个source元素。然后在source上添加src属性指定不同的源。

```js
<!-- 嵌入视频 -->
<video id="myVideo">
<source src="conference.webm" type="video/webm; codecs='vp8, vorbis'"> <source src="conference.ogv" type="video/ogg; codecs='theora, vorbis'"> <source src="conference.mpg">
Video player not available.
</video>
<!-- 嵌入音频 --> 
<audio id="myAudio">
  <source src="song.ogg" type="audio/ogg">
  <source src="song.mp3" type="audio/mpeg">
  Audio player not available.
</audio>
```

**检测编码器**
并不是所有浏览器都支持<video>和<audio>的所有编解码器，所以我们可以

```js
    let audio = document.getElementById("audio-player"); // 很可能是"maybe"
    if (audio.canPlayType("audio/mpeg")) {
      // 执行某些操作 }
      // 可能是"probably"
      // 同时提供mime和解码器
      if (audio.canPlayType("audio/ogg; codecs=\"vorbis\"")) { // 执行某些操作
      }
    } 
```

注意，编解码器必须放到引号中。同样，也可以在视频元素上使用 canPlayType()检测视频格式。

**音频类型**

\<audio>元素还有一个名为 Audio 的原生 JavaScript 构造函数，支持在任何时候播放音频。Audio 类型与 Image 类似，都是 DOM 元素的对等体，只是不需插入文档即可工作。要通过 Audio 播放音频， 只需创建一个新实例并传入音频源文件:

```js
let audio = new Audio("sound.mp3");
// 下面两是演示代码 EventUtil.addHandler不存在
EventUtil.addHandler(audio, "canplaythrough", function(event) {
      audio.play();
    });
```

#### 原生拖放

**拖放事件**

拖放的关键是确定每个事件是在哪里被触发，在元素被拖动时会按照顺序触发以下时间：

- dragstart
- drag
- dragend

再按住鼠标不放并开始移动鼠标那一刻，被拖动的元素就会触发dragstart 事件，鼠标开始移动时接着就会持续触发drag事件，当拖动停止时就会触发dragend事件。

在把元素拖动到一个有效的防止目标上时，会依次触发以下事件：

- dragenter
- dragover
- dragleave或者drop

把元素拖动到放置目标上，dragenter事件就会触发。dragenter事件触发之后，会触发dragover事件并且元素在放置目标范围内被拖动期间此事件会持续触发。当元素被拖动到放置目标之外，dragover 事件停止触发，dragleave 事件触发(类似于 mouseout 事件)。如果被拖动元素被放到了目标上，则会触发 drop 事件而不是 dragleave 事件。这些事件的目标是放置目标元素。

**自定义放置目标**

可以使用以下代码将一个元素转换为一个放置对象

```js
    const droptarget = document.querySelector('.drop')

    droptarget.addEventListener("dragover", (event) => {
      event.preventDefault();
      console.log('over', event);
    });
    droptarget.addEventListener("dragenter", (event) => {
      event.preventDefault();
      console.log('enter', event);
    });
  
// 也需要取消 drop 的默认行为 防止拖拽图片后导航到图片预览标签页
droptarget.addEventListener("drop", (event) => {
      event.preventDefault();
    });
```

当我们将某个元素拖拽到droptarget上后就会触发dragover和dragenter事件了。

**dataTransfer**

该属性就是为了实现拖拽传输数据而实现的。

dataTransfer 对象有两个主要方法:getData()和 setData()

```js
// 传递文本
event.dataTransfer.setData("text", "some text"); 
let text = event.dataTransfer.getData("text");
// 传递URL
event.dataTransfer.setData("URL", "http://www.wrox.com/"); 
let url = event.dataTransfer.getData("URL");
```

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>dnd</title>
  <style>
    .drag,
    .drop {
      width: 100px;
      height: 100px;
      border: 1px dashed #ccc;
      margin-bottom: 100px;
      user-select: auto;
    }
  </style>
</head>

<body>
  <div class="drag" draggable="true">drag</div>
  <div class="drop">drop</div>
  <script>
    const droptarget = document.querySelector('.drop');
    const dragtarget = document.querySelector('.drag')

    dragtarget.addEventListener("dragstart", (event) => {
      console.log('start', event);
      event.dataTransfer.setData('key', 666)
    });
    dragtarget.addEventListener("drag", (event) => {
     // console.log('drag');
    });
    dragtarget.addEventListener("dragend", (event) => {
      console.log('end');
    });

    droptarget.addEventListener("dragover", (event) => {
      event.preventDefault();
      //console.log('dragover');
    });
    droptarget.addEventListener("dragenter", (event) => {
      event.preventDefault();
      console.log('dragenter');
    });

    droptarget.addEventListener("drop", (event) => {
      event.preventDefault();
      console.log('drop', event.dataTransfer.getData('key'));
    });


  </script>
</body>

</html>
```

**dropEffect**与**effectAllowed**

dataTransfer 对象不仅可以用于实现简单的数据传输，还可以用于确定能够对被拖动元素和放置 目标执行什么操作。为此，可以使用两个属性:dropEffect 与 effectAllowed。

dropEffect属性告诉浏览器允许哪种放置行为，属性有以下四个可能的值。

- none 被拖动的元素不能放到这里，这是除文本框之外所有元素的默认值（这里的不能放是可能不能放，即还与effectAllowed有关）。
- move:被拖动元素应该移动到放置目标。
- copy:被拖动元素应该复制到放置目标。
- link:表示放置目标会导航到被拖动元素(仅在它是 URL 的情况下)。

dropEffect 需要设置在dragenter和dragover 事件中

effectAllowed属性指定被拖放操作所允许的一个效果，限定dropEffect能设置的值。

- uninitialized:没有给被拖动元素设置动作。 
- none:被拖动元素上没有允许的操作。
- copy:只允许"copy"这种 dropEffect。
- link:只允许"link"这种 dropEffect。
- move:只允许"move"这种 dropEffect。
- copyLink:允许"copy"和"link"两种 dropEffect。
- copyMove:允许"copy"和"move"两种 dropEffect。
- linkMove:允许"link"和"move"两种 dropEffect。
- all:允许所有 dropEffect。

需在dragstart事件里设置effectAllowed

注意：

- 如果只设置了effectAllowed没有设置dropEffect 则效果会按照effectAllowed的来生效
- 如果effectAllowed和dropEffect设置的值范围不重合的话也不会生效

对于放置行为是否生效主要体现在drop事件是否会被执行以及鼠标指针样式的显示。

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>dnd</title>
  <style>
    .drag,
    .drop {
      width: 100px;
      height: 100px;
      border: 1px dashed #ccc;
      margin-bottom: 100px;
      user-select: auto;
    }
  </style>
</head>

<body>
  <div style="width: 200px; height: 200px;">
    <div id="ceshi" class="drag" draggable="true">drag</div>
  </div>
  <div class="drop-wrapper" style="width: 200px; height: 200px;">
    <div class="drop">drop</div>
  </div>

  <script>
    const droptarget = document.querySelector('.drop');
    const dragtarget = document.querySelector('.drag');
    const dropWrapper = document.querySelector('.drop-wrapper');

    dragtarget.addEventListener("dragstart", (event) => {
      console.log('start', event);
      event.dataTransfer.setData('id', event.target.id)
      event.dataTransfer.effectAllowed = 'move'
    });
    dragtarget.addEventListener("drag", (event) => {
      console.log('drag');
    });
    dragtarget.addEventListener("dragend", (event) => {
      console.log('dragend');
    });

    droptarget.addEventListener("dragover", (event) => {
      event.preventDefault();
      console.log(event.dataTransfer.dropEffect);
      event.dataTransfer.dropEffect = 'move'
    });
    droptarget.addEventListener("dragenter", (event) => {
      event.preventDefault();
      //event.dataTransfer.dropEffect = 'move'
      console.log(event.dataTransfer.dropEffect);
      console.log('dragenter');
    });

    droptarget.addEventListener("drop", (event) => {
      event.preventDefault();
      console.log('drop');
      const data= event.dataTransfer.getData('id')
      dropWrapper.appendChild(document.getElementById(data));

    });
  </script>
</body>

</html>
```

默认情况下，图片、链接和文本是可拖动的，这意味着无须额外代码用户便可以拖动它们。文本只 有在被选中后才可以拖动，而图片和链接在任意时候都是可以拖动的。

**可拖动能力**

我们也可以让其他元素变得可以拖动。HTML5 在所有 HTML 元素上规定了一个 draggable 属性， 表示元素是否可以拖动。图片和链接的 draggable 属性自动被设置为 true，而其他所有元素此属性 的默认值为 false。如果想让其他元素可拖动，或者不允许图片和链接被拖动，都可以设置这个属性。 例如:

```html
<!-- 禁止拖动图片 -->
<!--注意 draggable是枚举类型 所以不能只写属性名-->
 <img src="/Users/zhangheng/Desktop/json2type/smile.gif" draggable="false" alt="Smiley face"> <!-- 让元素可以拖动 -->
 <div draggable="true">...</div>
```

#### Notifications API

用于向用户显示通知
Notifications API 在 Service Worker 中非常有用。渐进 Web 应用(PWA，Progressive Web Application) 通过触发通知可以在页面不活跃时向用户显示消息。

**通知权限**

为防止API被滥用，浏览器默认设置了以下安全措施

- 通知只能在运行在安全上下文的代码中被触发。
- 通知必须按照每个源的原则明确得到用户允许。

```js
    Notification.requestPermission()
      .then((permission) => {
        console.log('User responded to permission request:', permission);
      });
// 同意就是granted 拒绝就是denied
// 如果用户拒接了就无法再次通过编码方式触发授权了
```



**显示和隐藏通知**

```js
// 最简单的格式
new Notification('Title text!');
// 可以自定义图标主题以及是否震动
new Notification('Title text!', {       body: 'Body text!',
  image: 'path/to/image.png',           vibrate: true
});
```

隐藏通知

```js
const n = new Notification('I will close in 1000ms'); 
setTimeout(() => n.close(), 1000);
```

通知生命周期回调

对弹窗的交互也有以下声明周期

```js
const n = new Notification('foo');
n.onshow = () => console.log('Notification was shown!');
n.onclick = () => console.log('Notification was clicked!'); 
n.onclose = () => console.log('Notification was closed!');
n.onerror = () => console.log('Notification experienced an error!');
```

#### Page Visibility API

Page Visibility API 旨在为 开发者提供页面对用户是否可见的信息。 比如用户最小化或者隐藏页面了就不需要再去轮询服务器和播放动画了

API包含以下部分：

- document.visibilityState
  - 页面在后台标签页或者浏览器中最小化了
  - 页面在前台标签页中。
  - 实际页面隐藏了，对于页面的预览时可见的（比如用户移动到任务栏图标上会显示网页预览）
  - 页面在屏幕外预渲染
  - document.visibilityState 的值是以下三个字符串之一:
    - hidden 此时页面内容至少是部分可见。即此页面在前景标签页中，并且窗口没有最小化。
    - visible 此时页面对用户不可见。即文档处于背景标签页或者窗口处于最小化状态，或者操作系统正处于 '锁屏状态' .
    - prerender 页面此时正在渲染中，因此是不可见的
- visibilitychange 事件 当页面从可见变为隐藏或者反之，就会触发该事件。
- document.hidden 表示页面是否隐藏。
- 这个值是为了向后兼容才继续被浏览器支持的，应该优先使用 document.visibilityState 检测页面可见性。

#### Streams API

流 ，可以将数据比做某种管道中输送的液体。

Stream API定义了三种流：可读流，可写流，转换流。

块，内部队列，反压

流的基本单位是**块**，块可以是任意数据类型，通常是定型数组。每个块都是离散的流片段， 可以作为一个整体来处理。更重要的是，块不是固定大小的，也不一定按固定间隔到达。理想的流中，每个块大小近似相同，到达间隔近似相等。

每种类型的流都有入口和出口的概念，由于流的进出口速率不同，可能会出现不匹配的情况。所以为了平衡流会出现以下三种情况：

1. 流的出口处理数据的速度比入口提供数据的速度快，导致出口空闲，这种情况浪费一点内存或者计算资源（这种情况的流不平衡是可以接受的）
2. 流的出口和入口数据均衡，理想情况。
3. 流的出口速度比入口提供数据的速度慢，这种情况会导致数据积压。所以需要做出一定的处理。

当然流也为这种不平衡提供了解决方法，就是利用队列处理。

所有流都会为已进入流但尚未离开流的块提供一个**内部队列**。对于均衡流，这个内部队列中会有零个或少量排队的块，因为流出口块出列的速度与流入口块入列的速度近似相等。这种流的内部队列所占用的内存相对比较小。 如果块入列速度快于出列速度，则内部队列会不断增大。流不能允许其内部队列无限增大，因此 会使用**反压(backpressure)** 通知流入口停止发送数据，直到队列大小降到某个既定的阈值之下。这个阈值由排列策略决定，这个策略定义了内部队列可以占用的最大内存，即高水位线(high water mark)。

##### 可读流

可读流是对底层数据源的封装。底层数据源可以将数据填充到流中，允许消费者通过流的公共接口 读取数据。

```js

    // 生成器 每秒递增生成一个数
    async function* ints(l = 5) {
      for (let i = 0; i < l; i++) {
        yield await new Promise(resolve => setTimeout(resolve, 1000, i))
      }
    }


    const readStream = new ReadableStream({
      async start(controller) {
        for await (let chunk of ints()) {
          controller.enqueue(chunk);
        }
        controller.close();
      }
    })

    const readableStreamDefaultReader = readStream.getReader();

    (async function () {
      while (true) {
        const { value, done } = await readableStreamDefaultReader.read();
        if (done) {
          break;
        }
        console.log(value, done);
      }
    })();

```

##### 可写流

可写流是底层数据槽的封装。底层数据槽处理通过流的公共接口写入的数据。

```js
   // 生成器 每秒递增生成一个数
    async function* ints(l = 5) {
      for (let i = 0; i < l; i++) {
        yield await new Promise(resolve => setTimeout(resolve, 1000, i))
      }
    }


    const writeStream = new WritableStream({
      async write(value) {
        // 写入时会在这里打印
        console.log(value);
      }
    })
    

    const writableStreamDefaultWriter = writeStream.getWriter();

    (async function () {
      for await (const chunk of ints()) {
        await writableStreamDefaultWriter.ready
        writableStreamDefaultWriter.write(chunk);
      }
      writableStreamDefaultWriter.close();
    })();
```

##### 转换流

转换流用于组合可读流和可写流。数据块在两个流之间的转换是通过 transform()方法完成的。

```js
    async function* ints(l = 5) {
      for (let i = 0; i < l; i++) {
        yield await new Promise(resolve => setTimeout(resolve, 1000, i))
      }
    }


    const { writable, readable } = new TransformStream({
      transform(chunk, controller) {
        // 将值翻倍
        controller.enqueue(chunk * 2)
      }
    })


    const writableStreamDefaultWriter = writable.getWriter();
    const readableStreamDefaultReader = readable.getReader();


    // 生产者
    (async function () {
      for await (const chunk of ints()) {
        await writableStreamDefaultWriter.ready
        writableStreamDefaultWriter.write(chunk);
      }
      writableStreamDefaultWriter.close();
    })();

    // 消费者
    (async function () {
      while (true) {
        const { done, value } = await readableStreamDefaultReader.read();
        if (done) {
          break;
        }
        console.log(value)
      }
    })();
```

##### 通过管道连接流

流可以通过管道连接成一串。常见的用例是使用 pipeThrough()方法把 ReadableStream 接入 TransformStream。从内部看，ReadableStream 先把自己的值传给 TransformStream 内部的 WritableStream，然后执行转换，接着转换后的值又在新的 ReadableStream 上出现。

```js
    // 生成器 每秒递增生成一个数
    async function* ints(l = 5) {
      for (let i = 0; i < l; i++) {
        yield await new Promise(resolve => setTimeout(resolve, 1000, i))
      }
    }


    const readStream = new ReadableStream({
      async start(controller) {
        for await (let chunk of ints()) {
          controller.enqueue(chunk);
        }
        controller.close();
      }
    })

    const doublingStream = new TransformStream({
      transform(chunk, controller){
        // 处理为3倍
        controller.enqueue(chunk * 3)
      }
    })
   
   // 通过管道连接流
   const pipeStream = readStream.pipeThrough(doublingStream);
   const pipedStreamDefaultReader = pipeStream.getReader();
    
// 读取
    (async function () {
      while (true) {
        const { value, done } = await pipedStreamDefaultReader.read();
        if (done) {
          break;
        }
        console.log(value, done);
      }
    })();
```

还可以使用pipeTo方法将ReadableStream连接到WritableStream，和pipThrough类似

```js
    // 生成器 每秒递增生成一个数
    async function* ints(l = 5) {
      for (let i = 0; i < l; i++) {
        yield await new Promise(resolve => setTimeout(resolve, 1000, i))
      }
    }


    const readStream = new ReadableStream({
      async start(controller) {
        for await (let chunk of ints()) {
          controller.enqueue(chunk);
        }
        controller.close();
      }
    })

    const writeStream = new WritableStream({
      write(value) {
        console.log(value)
      }
    })

    // 通过管道连接流
    const pipeStream = readStream.pipeTo(writeStream);
   // 注意这里的管道操作隐式从 ReadableStream 获得了一个读取器，并把产生的值填充到 WritableStream。
```

#### 计时API

Performance接口

其由多个API构成：

- High Resolution Time API
-  Performance Timeline API
- Navigation Timing API
- User Timing API
- Resource Timing API
- Paint Timing API

##### High Resolution Time API

为了精准的度量程序运行的时间我们可以使用window.performance.now() 这个方法返回一个微秒精度的浮点值。

这个API的特点：

- 两次执行不会出现相等的情况
- 两次执行能保证时间戳单调增长

window.performance.now()计时器采用相对度量，计时器在执行上下文创建时从0开始计时

performance.timeOrigin 属性返回计时器初始化时全局系统时钟的值。

```js
    const relativeTimestamp = performance.now();
    const absoluteTimestamp = performance.timeOrigin + relativeTimestamp;
    console.log(performance.timeOrigin);
    console.log(relativeTimestamp);
    console.log(absoluteTimestamp); 
```

##### Performance Timeline API

该API使用一套用于度量客户端延迟的工具扩展了 Performance 接口。性能度量将会采用计算结束与开始时间差的形式。

性能度量将会采用计算结束与开始时间差的形式。这些开始和结束时间会被记录为 DOMHighResTimeStamp 值，而封装这个时间戳的对象是 PerformanceEntry 的实例。

浏览器会自动记录各种 PerformanceEntry 对象，而使用 performance.mark()也可以记录自定 义的 PerformanceEntry 对象。在一个执行上下文中被记录的所有性能条目可以通过 performance. getEntries()获取:

```js
console.log(performance.getEntries())
```

返回的集合代表浏览器的性能时间线(performance timeline)。每个 PerformanceEntry 对象 都有 name、entryType、startTime 和 duration 属性。

##### User Timing API

User Timing API 用于记录和分析自定义性能条目。

使用performance.mark()方法来记录自定义性能条目

在计算开始前和结束后各创建一个自定义性能条目可以计算时间差。最新的标记(mark)会被推到 getEntriesByType()返回数组的开始:

```js
    performance.mark('foo');
    for (let i = 0; i < 1E6; ++i) { }
    performance.mark('bar');
    // 获取标记的两个mark
    const [endMark, startMark] = performance.getEntriesByType('mark'); 
    console.log(startMark.startTime - endMark.startTime); // 1.3299999991431832
```

另外还可以生产性能度量条目,由 performance.measure方法生成
performance.measure方法在浏览器性能记录缓存中创建了一个名为[`时间戳`](https://developer.mozilla.org/zh-CN/docs/Web/API/DOMHighResTimeStamp)的记录来记录两个特殊标志位（通常称为开始标志和结束标志）。被命名的[`时间戳`](https://developer.mozilla.org/zh-CN/docs/Web/API/DOMHighResTimeStamp)称为一次测量（measure）

```js
    performance.mark('foo');
    for (let i = 0; i < 1E6; ++i) { }
    performance.mark('bar');
    performance.measure('baz', 'foo', 'bar');
    const [differenceMark] = performance.getEntriesByType('measure');
    console.log(differenceMark);
```

##### Navigation Timing API

Navigation Timing API 提供了高精度时间戳，用于度量当前页面加载速度。浏览器会在导航事件发生时自动记录 PerformanceNavigationTiming 条目。这个对象会捕获大量时间戳，用于描述页面是 何时以及如何加载的。

```js
const [performanceNavigationTimingEntry] = performance.getEntriesByType('navigation');
```

#### Resource Timing API

Resource Timing API 提供了高精度时间戳，用于度量当前页面加载时请求资源的速度。浏览器会在加载资源时自动记录 PerformanceResourceTiming。这个对象会捕获大量时间戳，用于描述资源加载的速度。

比如下面的例子记录了一张图片的加载时间

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <img src="https://fanyi-cdn.cdn.bcebos.com/webStatic/translation/asset/screenshot.0a87e41d.png" alt="">
  <script>
    window.onload = function () {
      const performanceResourceTimingEntry = performance.getEntriesByType('resource')[0]
    console.log(performanceResourceTimingEntry);
    }
  </script>
</body>

</html>
```

#### web组件

web组件在这里指的只是增强DOM行为的工具。包括影子 DOM、自定义元素和 HTML 模板。

##### template

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>template</title>
</head>
<body>
  <!--不会展示-->
  <template id="foo">
    #DocumentFragment
    <p>I'm inside a template!</p>
  </template>
  
</body>
</html>
```

我们可以通过template的content的属性获取DocumentFragment引用

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>template</title>
</head>

<body>
  <template id="foo">
    <p>I'm inside a template!</p>
  </template>

  <script>
    const temp = document.getElementById('foo');
    const p = temp.content;
    console.log(document.querySelector('p')); // null
    console.log(p.querySelector('p')); // <p>...<p>
  </script>

</body>
</html>
```

DocumentFragment 也是批量向 HTML 中添加元素的高效工具。比如，我们想以最快的方式给某 个 HTML 元素添加多个子元素。如果连续调用 document.appendChild()，则不仅费事，还会导致多 次布局重排。而使用 DocumentFragment 可以一次性添加所有子节点，最多只会有一次布局重排.

如果想复制模版，可以使用importNode方法克隆DocumentFragment

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>template</title>
</head>

<body>
  <template id="foo">
    <p>I'm inside a template!</p>
  </template>

  <div id="box"></div>

  <script>
    const box = document.getElementById('box')
    const temp = document.getElementById('foo');
    const fragment = temp.content;
    console.log(document.querySelector('p')); // null
    console.log(fragment.querySelector('p')); // <p>...<p>
    box.appendChild(document.importNode(fragment, true))
    box.appendChild(document.importNode(fragment, true))
    box.appendChild(fragment)

  </script>

</body>

</html>
```

##### 模版脚本

脚本执行可以推迟到将 DocumentFragment 的内容实际添加到 DOM 树。

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>index2</title>
</head>
<body>
  <template id="script">
    <script>
      console.log('template')
    </script>
    <div>666</div>
  </template>
  <div id="box"></div>
  <script>
    const box = document.getElementById('box')
    const template = document.getElementById('script').content;
    box.appendChild(template);
  </script>
</body>
</html>
```

##### 影子DOM

概念上讲，影子 DOM(shadow DOM) Web 组件相当直观，通过它可以将一个完整的 DOM 树作为 节点添加到父 DOM 树。这样可以实现 DOM 封装，意味着 CSS 样式和 CSS 选择符可以限制在影子 DOM 子树而不是整个顶级 DOM 树中。

影子DOM和HTML类似但是也有区别，影子DOM会将内容实际渲染到页面上，而HTML模版的内容不会。

##### 创建影子DOM

考虑到安全及避免影子 DOM 冲突，并非所有元素都可以包含影子 DOM。尝试给无效元素或者已经有了影子 DOM 的元素添加影子 DOM 会导致抛出错误。

以下是可以容纳影子DOM的元素：

- 任何以有效名称创建的自定义元素[链接](https://developer.mozilla.org/en-US/docs/Web/API/CustomElementRegistry)

  ```html
  <article>
  <aside>
  <blockquote>
  <body>
  <div>
  <footer>
  <h1>
  <h2>
  <h3>
  <h4>
  <h5>
  <h6>
  <header>
  <main>
  <nav>
  <p>
  <section>
  <span>
  ```



影子DOM是通过attachShadow() 方法创建并添加给有效的HTML元素的，容纳影子DOM的元素为影子宿主。影子DOM的根节点被称为影子根。

attachShadow()方法需要一个 shadowRootInit 对象，返回影子 DOM 的实例。shadowRootInit 对象必须包含一个 mode 属性，值为"open"或"closed"。对"open"影子 DOM 的引用可以通过 shadowRoot属性在 HTML 元素上获得，而对"closed"影子 DOM 的引用无法这样获取。

以下代码展示了不同的mode区别：

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shadow</title>
</head>

<body>
  <script>

    document.body.innerHTML = `
<div id="foo"></div>
<div id="bar"></div>
`;
    const foo = document.querySelector('#foo');
    const bar = document.querySelector('#bar');
    const openShadowDOM = foo.attachShadow({ mode: 'open' });
    const closedShadowDOM = bar.attachShadow({ mode: 'closed' });
    console.log(foo.shadowRoot);
    console.log(bar.shadowRoot); // null
  </script>
</body>

</html>
```

![image-20230824214104664](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230824214104664.png)

一般来讲，对于需要创建保密（closed）影子DOM的场景很少。但是恶意代码还是有很多方式绕过这个限制。所以不能为了安全而创建保密影子DOM。

当然，要想保护独立的DOM的树不受未信任代码影响。更可靠的是使用iframe并施加跨域限制。

##### 使用影子DOM

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>shadow</title>
</head>

<body>
  <script>
    for (let color of ['red', 'green', 'blue']) {
      const div = document.createElement('div');
      const shadowDOM = div.attachShadow({ mode: 'open' });
      document.body.appendChild(div);
      shadowDOM.innerHTML = `
        <p>Make me ${color}</p>
<style> 
  p{
          color: ${color};
        }
</style> `;
    }
  </script>
</body>

</html>
```

可以看到他们设置的样式只能各自影响到所在的影子DOM上。

##### 合成与影子DOM槽位

影子 DOM 是为自定义 Web 组件设计的，为此需要支持嵌套 DOM 片段。从概念上讲，可以这么说: 
位于影子宿主中的 HTML 需要一种机制以渲染到影子 DOM 中去，但这些 HTML 又不必属于影子 DOM 树。

默认情况下，嵌套内容会隐藏。来看下面的例子，其中的文本在 1000 毫秒后会被隐藏:

```js
    document.body.innerHTML = `
    <div id="box">
      <p>hello</p>  
    </div>
    `

    const box = document.getElementById('box');
    setTimeout(() => {
      box.attachShadow({ mode:'open' });
    }, 1000)
```

影子DOM添加到元素去其优先级就是最高的，会优先渲染它的内容，即使为空。

当然为了显示文本内容，需要使用slot标签来指示浏览器在那里放置原来的HTML。

```js
    document.body.innerHTML = `
    <div id="box">
      <p>hello</p>  
      <p>hell1o</p>  
    </div>
    `

    const box = document.getElementById('box');
    setTimeout(() => {
      box.attachShadow({ mode:'open' }).innerHTML = ` 
      <div id="box">
        <slot></slot>
      </div>
      `;
    }, 1000)
```

可以看到，影子dom里的slot中显示了原来的真实div中的内容

![image-20230824220930627](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230824220930627.png)

slot中的就是dom内容的投射，实际元素仍在外部。

##### 命名槽位

上面我们用slot的就是默认槽位。我们还可以使用命名槽位来实现多个投射。

```js
    document.body.innerHTML = `
<div>
  <p slot="foo">Foo</p>
  <p slot="bar">Bar</p>
</div> `;
    document.querySelector('div').attachShadow({ mode: 'open' }).innerHTML = `
<slot name="bar"></slot>
    <slot name="foo"></slot>
`;
// Renders:
// Bar // Foo
```

可以看到实际渲染出来的和真实dom渲染出来的位置相反。

##### 事件重定向

如果影子 DOM 中发生了浏览器事件(如 click)，那么浏览器需要一种方式以让父 DOM 处理事件。 不过，实现也必须考虑影子 DOM 的边界。为此，事件会逃出影子 DOM 并经过事件重定向(event retarget) 在外部被处理。逃出后，事件就好像是由影子宿主本身而非真正的包装元素触发的一样。下面的代码演示了这个过程:

```js
// 创建一个元素作为影子宿主
document.body.innerHTML = `
<div onclick="console.log('Handled outside:', event.target)"></div> `;
// 添加影子DOM并向其中插入HTML 
document.querySelector('div')
  .attachShadow({ mode: 'open' })
.innerHTML = `
<button onclick="console.log('Handled inside:', event.target)">Foo</button> `;
// 点击按钮时:
// Handled inside: <button onclick="..."></button> // Handled outside: <div onclick="..."></div>
```

可以看到shadow内部的事件冒泡到了真实的dom上。

注意：事件重定向只会发生在影子 DOM 中实际存在的元素上。使用<slot>标签从外部投射进来的 元素不会发生事件重定向，因为从技术上讲，这些元素仍然存在于影子 DOM 外部。

#### 自定义元素

##### 直接创建

默认情况我们自己直接定义的自定义元素也是会作为通用元素整合到DOM，也会被变成一个HTMLElement实例。

```js
    document.body.innerHTML = `
      <x-ele>666</x-ele>
    `
 console.log(document.querySelector('x-ele') instanceof HTMLElement); // true
```

##### 官方的创建方式

```js
    class FooElement extends HTMLElement { }
    customElements.define('x-foo', FooElement);
    document.body.innerHTML = `
    <x-foo>I'm inside a nonsense element.</x-foo>
    `;
    console.log(document.querySelector('x-foo') instanceof FooElement); // true
```

注意：自定义元素至少包含一个不再名称开头和结尾的连字符，且标签不能自闭合。

以下是一个自定义元素，创建时会打印一些信息

```js
    class FooElement extends HTMLElement {
      constructor() {
super();
        console.log('x-foo')
      }
    }
    customElements.define('x-foo', FooElement);
    document.body.innerHTML = `
    <x-foo></x-foo>
    <x-foo></x-foo>
    <x-foo></x-foo>
`;
    // x-foo
    // x-foo
    // x-foo
```

注意：在自定义元素的构造函数中，必须始终先调用super()。如果元素继承了HTMLElement 或相似类型而不会覆盖构造函数，则没有必要调用 super()，因为原型构造函数默认会做这件事。很少有创建自定义元素而不继承 HTMLElement 的。

还有一种定义自定义元素的方法：

```js
// 使用 is 属性和 extends 选项将标签指定为该自定义 元素的实例
    class FooElement extends HTMLDivElement {
      constructor() {
        super();
        console.log('x-foo')
      }
    }
    customElements.define('x-foo', FooElement, {extends:'div'});
    document.body.innerHTML = `
    <div is="x-foo">1</div>
    <div is="x-foo">2</div>
    <div is="x-foo">3</div>
    `;
    // x-foo
    // x-foo
    // x-foo
```

##### 给自定义元素添加内容

不能在构造函数中添加子 DOM(会抛出 DOMException)，但可以为自定义元素添加影子DOM 并将内容添加到这个影子 DOM 中

```js
    class FooElement extends HTMLElement {
      constructor() {
        super();
        // this 引用 Web 组件节点
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
          <p>I'm inside a custom element!</p>
          `;
      }
    }
    customElements.define('x-foo', FooElement);
    document.body.innerHTML += `<x-foo></x-foo>`;
```

##### 使用自定义元素生命周期方法

可以在自定义元素的不同生命周期执行代码。带有相应名称的自定义元素类的实例方法会在不同生 命周期阶段被调用。自定义元素有以下 5 个生命周期方法。

- constructor():在创建元素实例或将已有 DOM 元素升级为自定义元素时调用。
- connectedCallback():在每次将这个自定义元素实例添加到 DOM 中时调用。
- disconnectedCallback():在每次将这个自定义元素实例从 DOM 中移除时调用。
- attributeChangedCallback():在每次可观察属性的值发生变化时调用。在元素实例初始化时，初始值的定义也算一次变化。
- adoptedCallback():在通过document.adoptNode()将这个自定义元素实例移动到新文档对象时调用。

```js
    class FooElement extends HTMLElement {
      constructor() {
        super();
        console.log('created')
      }
      // 哪些属性需要监听修改
      static get observedAttributes() {
        return ['foo']
      }
      connectedCallback() {
        console.log('connected');
      }
      disconnectedCallback() {
        console.log('disconnected');
      }
      attributeChangedCallback(name, oldV, newV) {
        console.log('attributeChanged',name, oldV, newV)
      }

    }

    customElements.define('x-foo', FooElement);
    document.body.innerHTML += `<x-foo></x-foo>`;
    const xFoo = document.getElementsByTagName('x-foo');
    xFoo.item(0).innerHTML = '666';
    xFoo.item(0).setAttribute('foo', 'item');
    xFoo.item(0).setAttribute('bar', 'item1');

    document.body.removeChild(xFoo.item(0));
// created
// connected
// attributeChanged foo null item
// disconnected
```

##### 反射自定义元素属性

自定义元素既是 DOM 实体又是 JavaScript 对象，因此两者之间应该同步变化。换句话说，对 DOM 的修改应该反映到 JavaScript 对象，反之亦然。要从 JavaScript 对象反射到 DOM，常见的方式是使用获 取函数和设置函数。下面的例子演示了在 JavaScript 对象和 DOM 之间反射 bar 属性的过程:

```js
    class FooElement extends HTMLElement {
      constructor() {
        super();
        this.bar = true;
      }
      get bar() {
        return this.getAttribute('bar');
      }
      set bar(value) {
        this.setAttribute('bar', value)
      }
    }
    customElements.define('x-foo', FooElement);
    document.body.innerHTML = '<x-foo></x-foo>';
 console.log(document.body.innerHTML); // <x-foo bar="true"></x-foo>
```

另一个方向的反射 DOM-》JavaScript这就需要给属性添加监听器，并配合attributeChangedCallback()方法进行设置了

```js
    class FooElement extends HTMLElement {
      constructor() {
        super();
        this.bar = true;
      }
      static get observedAttributes() {
        return ['bar']
      }
      get bar() {
        return this.getAttribute('bar');
      }
      set bar(value) {
        this.setAttribute('bar', value)
      }
      attributeChangedCallback(name, oldV, newV) {
        if(oldV !== newV){
          console.log('changed')
          this[name] = newV;
        }
        
      }
    }
    customElements.define('x-foo', FooElement);
    document.body.innerHTML = '<x-foo></x-foo>';
    const xFoo = document.querySelector('x-foo');
    xFoo.setAttribute('bar', 666)
    console.log(document.body.innerHTML); 
    // changed
    // <x-foo bar="666"></x-foo>
```

##### 升级自定义元素

并非始终可以先定义自定义元素，然后再在 DOM 中使用相应的元素标签。为解决这个先后次序问 题，Web 组件在 CustomElementRegistry 上额外暴露了一些方法。这些方法可以用来检测自定义元 素是否定义完成，然后可以用它来升级已有元素。

如果自定义元素已经有定义，那么 CustomElementRegistry.get()方法会返回相应自定义元素 的类。类似地，CustomElementRegistry.whenDefined()方法会返回一个期约，当相应自定义元素 有定义之后解决:

```js
    customElements.whenDefined('x-foo').then(() => console.log('defined!')); 
    console.log(customElements.get('x-foo'));
    // undefined
    customElements.define('x-foo', class { });
    // defined!
    console.log(customElements.get('x-foo')); // class FooElement {}
```

连接到 DOM 的元素在自定义元素有定义时会自动升级。如果想在元素连接到 DOM 之前强制升级， 可以使用 CustomElementRegistry.upgrade()方法:

```js
    // 在自定义元素有定义之前会创建 HTMLUnknownElement 对象 
    const fooElement = document.createElement('x-foo');
    // 创建自定义元素
    class FooElement extends HTMLElement { } 
    customElements.define('x-foo', FooElement);
    console.log(fooElement instanceof FooElement); // false 
    // 强制升级
    customElements.upgrade(fooElement); 
    console.log(fooElement instanceof FooElement); // true
```

该方法更新 root 子树中所有包含影子 DOM 的自定义元素，甚至在它们载入主文档之前也可以更新。

#### Web Cryptography API

##### 随机数生成

在需要生成随机值时，很多人会使用 Math.random()。这个方法在浏览器中是以伪随机数生成器 (PRNG，PseudoRandom Number Generator)方式实现的。

伪随机数。指的是生成过程中不是真随机，而是模拟的随机特性。浏览器中的PRNG只是对一个内部状态使用了固定的算法。每调用random,内部状态都会被一个算法进行修改。结果会被转换 为一个新的随机值。例如，V8 引擎使用了一个名为 xorshift128+的算法来执行这种修改。由于算法本身是固定的，其输入只是之前的状态，因此随机数顺序也是确定的。xorshift128+使用 128 位内部状态，而算法的设计让任何初始状态在重复自身之前都会产生 2128–1 个伪随机值。这种循环 被称为置换循环(permutation cycle)，而这个循环的长度被称为一个周期(period)。很明显，如果攻击 者知道 PRNG 的内部状态，就可以预测后续生成的伪随机值。如果开发者无意中使用 PRNG 生成了私有 密钥用于加密，则攻击者就可以利用 PRNG 的这个特性算出私有密钥。

伪随机数生成器主要用于快速计算出看起来随机的值。不过并不适合用于加密计算。为解决这个问 题，密码学安全伪随机数生成器(CSPRNG，Cryptographically Secure PseudoRandom Number Generator) 额外增加了一个熵作为输入，例如测试硬件时间或其他无法预计行为的系统特性。这样一来，计算速度 明显比常规 PRNG 慢很多，但 CSPRNG 生成的值就很难预测，可以用于加密了。

使用crypto.getRandomValues()生成随机值,与 Math.random()返回一个介于 0 和 1 之间的浮点数不同，getRandomValues() 会把随机值写入作为参数传给它的定型数组。定型数组的类不重要，因为底层缓冲区会被随机的二进制位填充。

```js
    const array = new Uint8Array(1);
    for (let i = 0 ; i < 5; i++ ) {
      // 生成0-255内的随机数
      const arr = crypto.getRandomValues(array);
      console.log(arr, arr.toString());
    }
```

getRandomValues最多可以生成2^16字节，超出就会抛出错误。

```js
      const array1 = new Uint8Array(2**16);
      const array2 = new Uint8Array(2**16+1);
      const arr1 = crypto.getRandomValues(array1);
      const arr2 = crypto.getRandomValues(array2);// 报错
      console.log(arr1);
      console.log(arr2);
```

使用getRandomValues来实现Math.random

可以通过生成一个随机的 32 位数值，然后用它去除 最大的可能值 0xFFFFFFFF（2^32-1）。这样就会得到一个介于 0 和 1 之间的值

```js
    const arr = new Uint32Array(1);
    const maxUint32 = 0xFFFFFFFF;
    const num = crypto.getRandomValues(arr)[0] / maxUint32;
    console.log(num);
```

##### 使用**SubtleCrypto**对象

通过window.crypto.subtle 访问

```js
console.log(crypto.subtle); // SubtleCrypto {}
```

这个对象包含一组方法，用于执行常见的密码学功能，如加密、散列、签名和生成密钥。因为所有 密码学操作都在原始二进制数据上执行，所以 SubtleCrypto 的每个方法都要用到 ArrayBuffer 和 ArrayBufferView 类型。由于字符串是密码学操作的重要应用场景，因此 TextEncoder 和 TextDecoder 是经常与 SubtleCrypto 一起使用的类，用于实现二进制数据与字符串之间的相互转换。

**注意** SubtleCrypto 对象只能在安全上下文(https)中使用。在不安全的上下文中， subtle 属性是 undefined。

**生成密码学摘要**

SubtleCrypto.digest()方法用于生成消息摘要。要使用的散列算法通过字符串"SHA-1"、 "SHA-256"、"SHA-384"或"SHA-512"指定。

```js
// 使用 SHA-256 为字符串"foo"生成消息摘要
    (async function () {
      const textEncoder = new TextEncoder();
      const message = textEncoder.encode('foo');
      // 是一个ArrayBuffer
      const messageDigest = await crypto.subtle.digest('SHA-256', message);
      // 转为16进制 两位16进制的刚好好可以覆盖8位二进制无符号整型的大小。同时使用padStart补零
      const str = Array.from(new Uint8Array(messageDigest)).map(item => item.toString(16).padStart(2, '0')).join('');
      console.log(str);
      // 2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae
    })();
```

软件公司通常会公开自己软件二进制安装包的摘要，以便用户验证自己下载到的确实是该公司发布 的版本(而不是被恶意软件篡改过的版本)。下面的例子演示了下载 Firefox v67.0，通过 SHA-512 计算 22 其散列，再下载其 SHA-512 二进制验证摘要，最后检查两个十六进制字符串匹配:

```js
    (async function () {
      const mozillaCdnUrl = 'https://download-origin.cdn.mozilla.net/pub/firefox/releases/67.0/';
      const firefoxBinaryFilename = 'linux-x86_64/en-US/firefox-67.0.tar.bz2';
      const firefoxShaFilename = 'SHA512SUMS';
      console.log('Fetching Firefox binary...');
      // 下载包 转为 ArrayBuffer
      const fileArrayBuffer = await (await fetch(mozillaCdnUrl + firefoxBinaryFilename))
        .arrayBuffer();
      console.log('Calculating Firefox digest...');
      // 计算二进制摘要
      const firefoxBinaryDigest = await crypto.subtle.digest('SHA-512', fileArrayBuffer);
      const firefoxHexDigest = Array.from(new Uint8Array(firefoxBinaryDigest))
        .map((x) => x.toString(16).padStart(2, '0'))
        .join('');


      console.log('Fetching published binary digests...');
      // SHA 文件包含此次发布的所有 Firefox 二进制文件的摘要，
      // 因此要根据其格式进制拆分
      const a = (await (await fetch(mozillaCdnUrl + firefoxShaFilename)).text());
      console.log(a);
      const shaPairs = a
        .split(/\n/).map((x) => x.split(/\s+/));
        console.log(shaPairs);
      let verified = false;
      console.log('Checking calculated digest against published digests...'); 
      for (const [sha, filename] of shaPairs) {
        if (filename === firefoxBinaryFilename) {
          if (sha === firefoxHexDigest) {
            verified = true;
            break;
          }
        }
      }
      console.log('Verified:', verified);
    })();
    // Fetching Firefox binary...
    // Calculating Firefox digest...
    // Fetching published binary digests...
    // Checking calculated digest against published digests...
    // Verified: true
```

**CryptoKey 与算法**

SubtleCrypto 对象使用 CryptoKey 类的实例来生 成密钥。CryptoKey 类支持多种加密算法，允许控制密钥抽取和使用。

**生成 CryptoKey**

使用 SubtleCrypto.generateKey()方法可以生成随机 CryptoKey，这个方法返回一个期约， 解决为一个或多个 CryptoKey 实例。使用时需要给这个方法传入一个指定目标算法的参数对象、一个表示密钥是否可以从 CryptoKey 对象中提取出来的布尔值，以及一个表示这个密钥可以与哪个 SubtleCrypto 方法一起使用的字符串数组(keyUsages),由于不同的密码系统需要不同的输入来生成密钥，上述参数对象为每种密码系统都规定必需的输入:

- RSA 密码系统使用 RsaHashedKeyGenParams 对象;
-  ECC 密码系统使用 EcKeyGenParams 对象;
- HMAC 密码系统使用 HmacKeyGenParams 对象; 
- AES 密码系统使用 AesKeyGenParams 对象。

![image-20230829112349379](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230829112349379.png)

参考代码：

```js
    (async function () {
      const params = {
        name: 'AES-CTR',
        length: 128
      };
      const keyUsages = ['encrypt', 'decrypt'];
      const key = await crypto.subtle.generateKey(params, false, keyUsages);
      console.log(key);
      // CryptoKey {type: "secret", extractable: true, algorithm: {...}, usages: Array(2)}
    })();
```

![image-20230829112555460](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230829112555460.png)

```js
   (async function () {
      const params = {
        name: 'ECDSA',
        namedCurve: 'P-256'
      };
      const keyUsages = ['sign', 'verify'];
      const { publicKey, privateKey } = await crypto.subtle.generateKey(params, true, keyUsages);
      console.log(publicKey,privateKey);
    })()
```

**导入导出密钥**

```js
// exportKey
(async function () {
      const params = {
        name: 'AES-CTR',
        length: 128
      };
      const keyUsages = ['encrypt', 'decrypt'];
      const key = await crypto.subtle.generateKey(params, true, keyUsages);
      const rawKey = await crypto.subtle.exportKey('raw', key);
      console.log(new Uint8Array(rawKey));
      // Uint8Array[93, 122, 66, 135, 144, 182, 119, 196, 234, 73, 84, 7, 139, 43, 238,
      // 110] 21
    })();
```

与 exportKey()相反的操作要使用 importKey()方法实现。importKey()方法的签名实际上是 generateKey()和 exportKey()的组合。下面的方法会生成密钥、导出密钥，然后再导入密钥

```js
    (async function () {
      const params = {
        name: 'AES-CTR',
        length: 128
      };
      const keyUsages = ['encrypt', 'decrypt'];
      const keyFormat = 'raw';
      const isExtractable = true;
      const key = await crypto.subtle.generateKey(params, isExtractable, keyUsages);
      const rawKey = await crypto.subtle.exportKey(keyFormat, key);
      const importedKey = await crypto.subtle.importKey(keyFormat, rawKey, params.name, isExtractable, keyUsages);
      console.log(importedKey);
      // CryptoKey {type: "secret", extractable: true, algorithm: {...}, usages: Array(2)}
    })();
```

**主密钥派生密钥**

使用 SubtleCrypto 对象可以通过可配置的属性从已有密钥获得新密钥。SubtleCrypto 支持一 个 deriveKey()方法和一个 deriveBits()方法，前者返回一个解决为 CryptoKey 的期约，后者返回 一个解决为 ArrayBuffer 的期约。

**注意**deriveKey()与deriveBits()的区别很微妙，因为调用deriveKey()实际上与 调用 deriveBits()之后再把结果传给 importKey()相同。

deriveBits()方法接收一个算法参数对象、主密钥和输出的位长作为参数。当两个人分别拥有自 己的密钥对，但希望获得共享的加密密钥时可以使用这个方法。下面的例子使用 ECDH 算法基于两个密钥对生成了对等密钥，并确保它们派生相同的密钥位:

```js
    (async function () {
      const ellipticCurve = 'P-256';
      const algoIdentifier = 'ECDH';
      const derivedKeySize = 128;
      const params = {
        name: algoIdentifier,
        namedCurve: ellipticCurve
      };
      const keyUsages = ['deriveBits'];
      const keyPairA = await crypto.subtle.generateKey(params, true, keyUsages); 
      const keyPairB = await crypto.subtle.generateKey(params, true, keyUsages);
      // 从 A 的公钥和 B 的私钥派生密钥位
      const derivedBitsAB = await crypto.subtle.deriveBits(
        Object.assign({ public: keyPairA.publicKey }, params),
        keyPairB.privateKey,
        derivedKeySize);

      // 从 B 的公钥和 A 的私钥派生密钥位
      const derivedBitsBA = await crypto.subtle.deriveBits(
        Object.assign({ public: keyPairB.publicKey }, params),
        keyPairA.privateKey,
        derivedKeySize);
      const arrayAB = new Uint32Array(derivedBitsAB);
      const arrayBA = new Uint32Array(derivedBitsBA);
      // 确保密钥数组相等 
      console.log(
      arrayAB.length === arrayBA.length &&
        arrayAB.every((val, i) => val === arrayBA[i])); // true
    })();
```

**使用非对称密钥签名和验证消息**

通过 SubtleCrypto 对象可以使用公钥算法用私钥生成签名，或者用公钥验证签名。这两种操作分别通过 SubtleCrypto.sign()和 SubtleCrypto.verify()方法完成。

签名消息需要传入参数对象以指定算法和必要的值、CryptoKey 和要签名的 ArrayBuffer 或 ArrayBufferView。下面的例子会生成一个椭圆曲线密钥对，并使用私钥签名消息:

```js
    (async function () {
      const keyParams = {
        name: 'ECDSA',
        namedCurve: 'P-256'
      };
      const keyUsages = ['sign', 'verify'];
      // 生成公私钥
      const { publicKey, privateKey } = await crypto.subtle.generateKey(keyParams, true, keyUsages);
      const message = (new TextEncoder()).encode('I am Satoshi Nakamoto');
      const signParams = {
        name: 'ECDSA',
        hash: 'SHA-256'
      };
      // 生成加密签名
      const signature = await crypto.subtle.sign(signParams, privateKey, message);
      const arr = new Uint32Array(signature);
      console.log(arr);// Uint32Array(16) [2202267297, 698413658, 1501924384, 691450316, 778757775, ... ] 
      console.log(Array.from(arr).map(item => item.toString(16).padStart(8,'0')).join(''));
  })();
```

希望通过这个签名验证消息的人可以使用公钥和 SubtleCrypto.verify()方法。这个方法的签名 几乎与 sign()相同，只是必须提供公钥以及签名。下面的例子通过验证生成的签名扩展了前面的例子:

```js
    (async function () {
      const keyParams = {
        name: 'ECDSA',
        namedCurve: 'P-256'
      };
      const keyUsages = ['sign', 'verify'];
      const { publicKey, privateKey } = await crypto.subtle.generateKey(keyParams, true, keyUsages);
      const message = (new TextEncoder()).encode('I am Satoshi Nakamoto');
      const signParams = {
        name: 'ECDSA',
        hash: 'SHA-256'
      };
      const signature = await crypto.subtle.sign(signParams, privateKey, message);
      const verified = await crypto.subtle.verify(signParams, publicKey, signature, message);
      console.log(verified); // true
    })();
```

**使用对称密钥加密和解密**

SubtleCrypto 对象支持使用公钥和对称算法加密和解密消息。这两种操作分别通过 SubtleCrypto.encrypt()和 SubtleCrypto.decrypt()方法完成。 加密消息需要传入参数对象以指定算法和必要的值、加密密钥和要加密的数据。下面的例子会生成

对称 AES-CBC 密钥，用它加密消息，最后解密消息:

```js
    (async function () {
      const algoIdentifier = 'AES-CBC';
      const keyParams = {
        name: algoIdentifier,
        length: 256
      };
      const keyUsages = ['encrypt', 'decrypt'];

      const key = await crypto.subtle.generateKey(keyParams, true,
        keyUsages);

      const originalPlaintext = (new TextEncoder()).encode('I am Satoshi Nakamoto');
      const encryptDecryptParams = {
        name: algoIdentifier,
        iv: crypto.getRandomValues(new Uint8Array(16))
      };

      const ciphertext = await crypto.subtle.encrypt(encryptDecryptParams, key, originalPlaintext);
      console.log(ciphertext);
      // ArrayBuffer(32) {}
      const decryptedPlaintext = await crypto.subtle.decrypt(encryptDecryptParams, key, ciphertext);
      console.log(decryptedPlaintext); // ArrayBuffer(21) {}
      console.log(key); 25 // CryptoKey {type: "secret", extractable: true, algorithm: {...}, usages: Array(1)}
      console.log((new TextDecoder()).decode(decryptedPlaintext));
      // I am Satoshi Nakamoto
    })();
```

**包装和解包密钥**

SubtleCrypto 对象支持包装和解包密钥，以便在非信任渠道传输。这两种操作分别通过 Subtle-Crypto.wrapKey()和 SubtleCrypto.unwrapKey()方法完成。 包装密钥需要传入一个格式字符串、要包装的 CryptoKey 实例、要执行包装的 CryptoKey，以及一个参数对象用于指定算法和必要的值。下面的例子生成了一个对称 AES-GCM 密钥，用 AES-KW 来包装这个密钥，最后又将包装的密钥解包:

```js
    (async function () {
      const keyFormat = 'raw';
      const extractable = true;
      const wrappingKeyAlgoIdentifier = 'AES-KW';
      const wrappingKeyUsages = ['wrapKey', 'unwrapKey'];
      const wrappingKeyParams = {
        name: wrappingKeyAlgoIdentifier,
        length: 256
      };
      const keyAlgoIdentifier = 'AES-GCM';
      const keyUsages = ['encrypt'];
      const keyParams = {
        name: keyAlgoIdentifier,
        length: 256
      };
      // 用来包装的key
      const wrappingKey = await crypto.subtle.generateKey(wrappingKeyParams, extractable, wrappingKeyUsages);
      console.log(wrappingKey);
      // CryptoKey {type: "secret", extractable: true, algorithm: {...}, usages: Array(2)}
      // 要包装的key
      const key = await crypto.subtle.generateKey(keyParams, extractable, keyUsages);
      console.log(key);

      const wrappedKey = await crypto.subtle.wrapKey(keyFormat, key, wrappingKey, wrappingKeyAlgoIdentifier);
      console.log(wrappedKey);
      // ArrayBuffer(40) {}
      const unwrappedKey = await crypto.subtle.unwrapKey(keyFormat, wrappedKey, wrappingKey, wrappingKeyParams, keyParams, extractable, keyUsages);
      console.log(unwrappedKey);
      // CryptoKey {type: "secret", extractable: true, algorithm: {...}, usages: Array(1)}
    })()
```

### 小结

- Atomics API 用于保护代码在多线程内存访问模式下不发生资源争用。
- postMessage() API 支持从不同源跨文档发送消息，同时保证安全和遵循同源策略。
- Encoding API 用于实现字符串与缓冲区之间的无缝转换(越来越常见的操作)。
- File API 提供了发送、接收和读取大型二进制对象的可靠工具。
- 媒体元素<audio>和<video>拥有自己的 API，用于操作音频和视频。并不是每个浏览器都会支持所有媒体格式，使用 canPlayType()方法可以检测浏览器支持情况。
- 拖放 API 支持方便地将元素标识为可拖动，并在操作系统完成放置时给出回应。可以利用它创建自定义可拖动元素和放置目标。

- Notifications API 提供了一种浏览器中立的方式，以此向用户展示消通知弹层。
- Streams API 支持以全新的方式读取、写入和处理数据。
- Timing API 提供了一组度量数据进出浏览器时间的可靠工具。
- Web Components API 为元素重用和封装技术向前迈进提供了有力支撑。
- Web Cryptography API 让生成随机数、加密和签名消息成为一类特性。

## 错误处理与调试

### 错误处理

#### try/catch

```js
    try {
      window.something();
    } catch (error) {
      console.log('error', error)
    }
```

#### finally

try/catch 语句中可选的 finally 子句始终运行。如果 try 块中的代码运行完，则接着执行finally 块中的代码。如果出错并执行 catch 块中的代码，则 finally 块中的代码仍执行。try 或 catch 块无法阻止 finally 块执行，包括 return 语句。比如:

```js
    function testFinally() {
      try {
        console.log('d1');
        return 2;
        console.log('d2');
      } catch (error) {
        console.log('d3');
         return 1;
         console.log('d4');
      } finally {
        console.log('d5');
        return 0;
      }
    }

    console.log(testFinally());
```

**注意** 只要代码中包含了finally子句，try块或catch块中的return语句就会被忽略，理解这一点很重要。在使用 finally 时一定要仔细确认代码的行为。

#### 错误类型

ECMA-262 定义了以下 8 种错误类型：

- Error 基本类型，其他的基本类型都继承这个类型

- InternalError 底层js引擎错误（栈溢出啥的）

- EvalError eval函数使用不当报错

- RangeError 数值越界报错

- ReferenceError 这种错误经常是由访问不存在的变量而导致的

- SyntaxError

  SyntaxError 经常在给 eval()传入的字符串包含 JavaScript 语法错误时发生，比如:

  eval("a ++ b"); // 抛出SyntaxError

- TypeError 最常见的错误 主要发生在变量不是预期类型，或者访问不存在的方法时。很 多原因可能导致这种错误，尤其是在使用类型特定的操作而变量类型不对时。

- URIError 只会在使用 encodeURI()或 decodeURI()但传入了格式错误的 URI 时发生

#### try/catch的用法

trycatch最好用在自己无法控制的错误上，比如使用了一个第三方库，但是这个库里的方法可能会抛出你意想不到的方法。所以可以使用trycatch处理，但如果你明确知道自己的代码会出问题，就没必要使用trycatch进行处理了。

#### 抛出错误

和try/catch语句对应的一个机制就是throw操作，throw操作符用于在任何时候自定义错误。throw 操作符必须有个值。可以是任意类型

```js
    try {
      throw 12345;
    } catch (error) {
      console.log(error);
    }

    try {
      throw "Hello world!";
    } catch (error) {
      console.log(error);
    }

    try {
      throw true;
    } catch (error) {
      console.log(error);
    }

    try {
      throw { name: "JavaScript" };
    } catch (error) {
      console.log(error);
    }
```

使用throw后代码就会停止执行，除非使用了try/catch捕获这个异常

**自定义错误类型**

可以通过继承的方式创建自定义的错误类型，创建时需要提供name和message属性

```js
    class CustomError extends Error {
      constructor(message) {
        super(message);
        this.name = "CustomError";
        this.message = message;
      }
    }
    throw new CustomError("My message");
```

在大型的应用中通常使用assert函数抛出错误

```js

// 函数接收一个应该为 true 的条件，并在条件为 false 时抛出错误。下面是一个基本的 assert()函数
function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}
// 和console.assert类似。
```



另外，这个 assert()函数可用于代替多个 if 语句，同时也是记录错误的好地方。下面的代码演示了如 何使用它:

```js
    function assert(condition, message) {
      if (!condition) {
        throw new Error(message);
      }
    }
    function divide(num1, num2) {
      assert(typeof num1 == "number" && typeof num2 == "number",
        "divide(): Both arguments must be numbers.");
      return num1 / num2;
    }

    divide(1,2)
    divide(1,'1')
```

#### onerror事件

对于没有别try/catch捕获到的错误，都会触发在window上的error事件

```js
    window.onerror = (a, b, c, d, e) => {
  console.log(`message: ${a}`);
  console.log(`source: ${b}`);
  console.log(`lineno: ${c}`);
  console.log(`colno: ${d}`);
  console.log(`error: ${e}`);
  
   // 返回true 就会取消 Window 错误事件的默认行为的事件处理程序属性（不会在控制台抛出错误了）
  return true;
};
  console.log(x)
```

### XML

略。。工作上几乎不接触

### JSON

#### 语法

json支持三种类型的值：

-  简单值 字符串，数值，布尔值和null
- 对象
- 数组

**字符串**

```json
"hello world!"
```

js字符串和json字符串最主要的区别就是json必须是双引号。

**对象**

```json
    {
      "name": "Nicholas",
      "age": 29,
      "school": {
        "name": "Merrimack College",
        "location": "North Andover, MA"
      }
}
```

与js对象相比较，json对象主要有两处不同，一个是没有变量声明，另一个是变量中的属性值后不能有分号

**数组**

```json
[25, "hi", true]
```

同样没有变量，也没有分号。

#### 解析和序列化

**JSON对象**

有两个方法stringify和parse

这两个方法分别可以将js序列化位json字符串以及，将json解析位js值

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book);
// {"title":"Professional JavaScript","authors":["Nicholas C. Zakas","Matt Frisbie"],"edition":4,"year":2017}
```

序列化后所有的函数和原型成员都会在结果中省略掉，值为undefined的属性也会跳过。

JSON 字符串可以直接传给 JSON.parse()，然后得到相应的 JavaScript 值。比如，可以使用以下 代码创建与 book 对象类似的新对象。

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book);
    console.log(JSON.parse(jsonText))

```

如果JSON.parse()穿入的JSON字符串无效则会导致抛出错误。

#### 序列化选项

JSON.stringify()方法除了要序列化的对象，还可以接收两个参数。这两个参数可以用 于指定其他序列化 JavaScript 对象的方式。第一个参数是过滤器，可以是数组或函数;第二个参数是用 于缩进结果 JSON 字符串的选项。单独或组合使用这些参数可以更好地控制 JSON 序列化。

**过滤结果**

如果第二个参数是一个数组，那么 JSON.stringify()返回的结果只会包含该数组中列出的对象 属性。比如下面的例子

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book, ['year', 'title']);
    console.log(JSON.parse(jsonText))
// {
//"year": 2017,
// "title": "Professional    //JavaScript"
// }
```

如果第二个参数是一个函数，则行为又有不同。提供的函数接收两个参数:属性名(key)和属性 值(value)。可以根据这个 key 决定要对相应属性执行什么操作。这个 key 始终是字符串，只是在值不属于某个键/值对时会是空字符串。

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book, (key, value) => {
      switch (key) {
        case "authors":
          return value.join(",")
        case "year":
          return 5000;
        case "edition":
          return undefined;
        default:
          return value;
      }
    });
    console.log(jsonText);
    // {"title":"Professional JavaScript","authors":"Nicholas C. Zakas,Matt Frisbie","year":5000}
```

**注意**，函数过滤器会应用到要序列化的对象所包含的所有对象，因此如果数组中包含多个具有这些 属性的对象，则序列化之后每个对象都只会剩下上面这些属性。

**字符串缩进**

JSON.stringify()方法的第三个参数控制缩进和空格。在这个参数是数值时，表示每一级缩进的空格数。例如，每级缩进 4 个空格，可以这样:

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book, (key, value) => {
      switch (key) {
        case "authors":
          return value.join(",")
        case "year":
          return 5000;
        case "edition":
          return undefined;
        default:
          return value;
      }
    },4);
    console.log(jsonText);
// {
//     "title": "Professional JavaScript",
//     "authors": "Nicholas C. Zakas,Matt Frisbie",
//     "year": 5000
// }
```

除了缩进，JSON.stringify()方法还为方便阅读插入了换行符。这个行为对于所有有效的

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017
    };
    let jsonText = JSON.stringify(book, (key, value) => {
      switch (key) {
        case "authors":
          return value.join(",")
        case "year":
          return 5000;
        case "edition":
          return undefined;
        default:
          return value;
      }
    },'---');
    console.log(jsonText);
// {
// ---"title": "Professional JavaScript",
// ---"authors": "Nicholas C. Zakas,Matt Frisbie",
// ---"year": 5000
// }
```

缩进就会被我们填入的字符串给替代，但是注意最大缩进值为 10。大于10会自动设置为10。使用字符串时同样有 10 个字符的长度限制。如果字符串长度超过 10，则会在第 10 个字符处截断。 

**toJSON()方法**

有时候，对象需要在 JSON.stringify()之上自定义 JSON 序列化。此时，可以在要序列化的对象 中添加 toJSON()方法，序列化时会基于这个方法返回适当的 JSON 表示。事实上，原生 Date 对象就 有一个 toJSON()方法，能够自动将 JavaScript 的 Date 对象转换为 ISO 8601 日期字符串(本质上与在 Date 对象上调用 toISOString()方法一样)。

```js
// 自定义JSON.stringify()方法    
let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017,
      toJSON:function(){
        return this.title
      }

    };
    let jsonText = JSON.stringify(book);
    console.log(jsonText);// "Professional JavaScript"
```

toJSON()方法可以与过滤函数一起使用，因此理解不同序列化流程的顺序非常重要。在把对象传给 JSON.stringify()时会执行如下步骤。

(1) 如果可以获取实际的值，则调用 toJSON()方法获取实际的值，否则使用默认的序列化。 

(2) 如果提供了第二个参数，则应用过滤。传入过滤函数的值就是第(1)步返回的值。
 (3) 第(2)步返回的每个值都会相应地进行序列化。

(4) 如果提供了第三个参数，则相应地进行缩进。

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017,
      toJSON:function(){
        return {title:this.title, authors:this.authors}
      }

    };
    let jsonText = JSON.stringify(book, ['title']);
    console.log(jsonText);// {"title":"Professional JavaScript"}
```

#### 解析选项

JSON.parse()方法也可以接收一个额外的参数，这个函数会针对每个键/值对都调用一次。为区别于传给 JSON.stringify()的起过滤作用的替代函数(replacer)，这个函数被称为还原函数(reviver)。 实际上它们的格式完全一样，即还原函数也接收两个参数，属性名(key)和属性值(value)，另外也需要返回值。

如果还原函数返回 undefined，则结果中就会删除相应的键。如果返回了其他任何值，则该值就 会成为相应键的值插入到结果中。还原函数经常被用于把日期字符串转换为 Date 对象。例如:

```js
    let book = {
      title: "Professional JavaScript",
      authors: [
        "Nicholas C. Zakas",
        "Matt Frisbie"
      ],
      edition: 4,
      year: 2017,
      releaseDate: new Date(2017, 11, 1)
    };
    let jsonText = JSON.stringify(book); 
    let bookCopy = JSON.parse(jsonText,
      (key, value) => key == "title" ? 'my title' : value);
   console.log(bookCopy);
//    {
//     "title": "my title",
//     "authors": [
//         "Nicholas C. Zakas",
//         "Matt Frisbie"
//     ],
//     "edition": 4,
//     "year": 2017,
//     "releaseDate": "2017-11-30T16:00:00.000Z"
// }
```

### 网络请求与远程资源

#### XMLHttpRequest 对象

所有现代浏览器都支持XMLHttpRequest构造函数

```js
  const xhr = new XMLHttpRequest();
    console.log(xhr);
```

#### 使用xhr

使用该对象前需要先调用xhr实例的open方法

方法接收三个参数，请求类型，请求的url以及是否异步请求

```js
    const xhr = new XMLHttpRequest();
    xhr.open('get', 'www.baidu.com', true);
```

**注意** 只能访问同源URL，也就是域名相同、端口相同、协议相同。如果请求的URL与 发送请求的页面在任何方面有所不同，则会抛出安全错误。

上述的代码调用open只是为发请求做准备，真正要调用还得调用send方法

```js
    const xhr = new XMLHttpRequest();
    xhr.open('get', 'http://xxx.yyy.cn/article', true);
    xhr.send(null)
```

send方法接受一个参数，是作为请求体发送的数据。如果不需要发送请求体，需要显式传递一个null。因为这个参数在某些浏览器里是必须的。

#### 接收响应

收到响应后，xhr对象中的以下属性会被填充上数据

-  responseText:作为响应体返回的文本。
- responseXML:如果响应的内容类型是"text/xml"或"application/xml"，那就是包含响应数据的 XML DOM 文档。
- status:响应的 HTTP 状态。
- statusText:响应的 HTTP 状态描述。

```js
    const xhr = new XMLHttpRequest();
    xhr.open('get', 'http://xxx.yyy.cn/article', false);
    xhr.send(null)
    const { responseText, responseXML, status, statusText } = xhr;
    console.log(responseText);
    console.log(responseXML);
    console.log(status);
    console.log(statusText);
    if(status === 200 && status < 300) {
      console.log('请求成功');
    }
```

XHR 对象有一个 readyState 属性，表示当前处在请求/响应过程的哪个阶段。 这个属性有如下可能的值：

- 0:未初始化(Uninitialized)。尚未调用 open()方法。
- 1:已打开(Open)。已调用 open()方法，尚未调用 send()方法。
- 2:已发送(Sent)。已调用 send()方法，尚未收到响应。
- 3:接收中(Receiving)。已经收到部分响应。
- 4:完成(Complete)。已经收到所有响应，可以使用了。

```js
    xhr.onreadystatechange = function(e) {
      console.log(xhr.readyState);
    }
```

在收到响应之前如果想取消异步请求，可以调用 abort()方法: 

```
    xhr.abort();
```

调用这个方法后，XHR 对象会停止触发事件，并阻止访问这个对象上任何与响应相关的属性。中断请求后，应该取消对 XHR 对象的引用。由于内存问题，不推荐重用 XHR 对象。

```js
xhr = null;
```

#### http头部

每个http的请求和响应都会携带一些头部字段，默认情况下xhr会携带以下头部字段。

- Accept: 浏览器可以处理的内容
- Accept-Charset:浏览器可以显示的字符集。
- Accept-Encoding:浏览器可以处理的压缩编码类型。
- Accept-Language:浏览器使用的语言。
- Connection:浏览器与服务器的连接类型。
- Cookie:页面中设置的 Cookie。
- Host:发送请求的页面所在的域。
-  Referer:发送请求的页面的 URI。注意，这个字段在 HTTP 规范中就拼错了，所以考虑到兼容性也必须将错就错。(正确的拼写应该是 Referrer。)
- User-Agent:浏览器的用户代理字符串。

如果要发送额外的请求头，可以使用setRequestHeader方法.

注意调用时机需要在open方法后send方法前

```js
setRequestHeader(key,value)
```

可以使用getResponseHeader读取响应头部

```js
// 读取指定头部
getResponseHeader(key);
// 读取所有
getAllResponseHeaders();
```

#### get请求

常用于向服务端发送应该保存的数据

发送 GET 请求最常见的一个错误是查询字符串格式不对。查询字符串中的每个名和值都必须使用 encodeURIComponent()编码，所有名/值对必须以和号(&)分隔，如下面的例子所示:

```js
xhr.open("get", "example.php?name1=value1&name2=value2", true);
// 可以定义一个工具函数
    function addURLParam(url, name, value) {
      url += (url.indexOf("?") == -1 ? "?" : "&");
      url += encodeURIComponent(name) + "=" + encodeURIComponent(value); return url;
    }

    console.log(addURLParam('www.baidu.con', 'k1', 'v1'));
    console.log(addURLParam(addURLParam('www.baidu.con', 'k1', 'v1'), 'k1', 'v1'));

```

#### post请求

每个post都应该在请求体中携带提交的数据。默认情况下，对服务器而言，POST 请求与提交表单是不一样的。服务器逻辑需要读取原始 POST 数据才能取得浏览器发送的数据。不过，可以使用 XHR 模拟表单提交。为此，第一步需要把 Content- Type 头部设置为"application/x-www-formurlencoded"，这是提交表单时使用的内容类型。

**注意** POST请求相比GET请求要占用更多资源。从性能方面说，发送相同数量的数据， GET 请求比 POST 请求要快两倍。

#### FormData 类型

现代 Web 应用程序中经常需要对表单数据进行序列化，因此 XMLHttpRequest Level 2 新增了 FormData 类型。FormData 类型便于表单序列化，也便于创建与表单类似格式的数据然后通过 XHR 发送。下面的代码创建了一个 FormData 对象，并填充了一些数据:

```js
 let data = new FormData();
 data.append("name", "Nicholas");
 xhr.send(data);
// 还可以直接传递一个表单元素
 let form = document.getElementById("user-info");
    xhr.send(new FormData(form));
```

#### 超时

可以直接给timeout赋值表示设置多少毫秒的超时：

```js
xhr.open("get", "xxx", true);
xhr.timeout = 1000; // 设置 1 秒超时 
xhr.ontimeout = function() {
  alert("Request did not return in a second.");
};
xhr.send(null);
```

上面的请求，如果超过一秒还没返回就会中断请求

**overrideMimeType**

overrideMimeType()方法用于重写 XHR 响应的 MIME 类型。

假设服务器实际发送了 XML 数据，但响应头设置的 MIME 类型是 text/plain。结果就会导致虽然数据是 XML，但 responseXML 属性值是 null。此时调用 overrideMimeType()可以保证将响应 当成 XML 而不是纯文本来处理：

```js
let xhr = new XMLHttpRequest(); xhr.open("get", "text.php", true); xhr.overrideMimeType("text/xml"); xhr.send(null);
```

#### 进度事件

有以下 6 个进度相关的事件：

- loadstart:在接收到响应的第一个字节时触发。 
- progress:在接收响应期间反复触发。
- error:在请求出错时触发。
- abort:在调用 abort()终止连接时触发。
- load:在成功接收完响应时触发。
- loadend:在通信完成时，且在 error、abort 或 load 之后触发。

每次请求都会首先触发 loadstart 事件，之后是一个或多个 progress 事件，接着是 error、abort或 load 中的一个，最后以 loadend 事件结束。

```js
    let divStatus = document.getElementById("status");
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function (e) {
      if (xhr.readyState === 4 && xhr.status === 200) {
        const allH = xhr.getAllResponseHeaders();
        console.log(allH);
      };
    }

    xhr.onload = function (event) {
      if ((xhr.status >= 200 && xhr.status < 300) ||
        xhr.status == 304) {
        //alert(xhr.responseText);
      } else {
        //alert("Request was unsuccessful: " + xhr.status);
      }
    };
    xhr.onprogress = function (event) {

      if (event.lengthComputable) {
        // 这里注意 浏览器不同 可能会有其他属性来计算进度条
// 红宝书使用的 position 和 totalSize
        // 上述两个属性在chrome是不存在 的,所以最好做下兼容处理
                let loaded  = event.loaded ||event.position;
        let total = event.total || event.totalSize;
        
         divStatus.innerHTML = "Received " + loaded + " of " +
          total +
          " bytes";
      }
    };

    xhr.open('get', 'http://saberblog.topzhang.cn/article', true);
    xhr.send(null)
    const { responseText, responseXML, status, statusText } = xhr;
    console.log(responseText);
    console.log(responseXML);
    console.log(status);
    console.log(statusText);
    if (status === 200 && status < 300) {
      console.log('请求成功');
    }
```

#### 跨域资源共享

通过 XHR 进行 Ajax 通信的一个主要限制是跨源安全策略。 

跨源资源共享(CORS，Cross-Origin Resource Sharing)定义了浏览器与服务器如何实现跨源通信。 CORS 背后的基本思路就是使用自定义的 HTTP 头部允许浏览器和服务器相互了解，以确实请求或响应 应该成功还是失败。

对于简单的请求，比如get或者post，没有自定义头部，请求就会在发送的时候携带一个额外的头部叫origin。origin包含发送请求页面的源，以便服务器确定是否为其提供相应。

如果服务器确定响应，就会在响应头里发送Access-Control-Allow-Origin 头部，包含相同的源; 或者如果资源是公开的，那么就包含"*"

```js
// e.g
Access-Control-Allow-Origin: http://www.nczonline.net
```

如果没有这个头部，或者有但源不匹配，则表明不会响应浏览器请求。否则，服务器就会处理这个 请求。注意，无论请求还是响应都不会包含 cookie 信息。现代浏览器通过 XMLHttpRequest 对象原生支持 CORS。在尝试访问不同源的资源时，这个行为 会被自动触发。

跨域 XHR 对象允许访问 status 和 statusText 属性，也允许同步请求。出于安全考虑，跨域 XHR 对象也施加了一些额外限制。

- 不能使用 setRequestHeader()设置自定义头部
- 不能发送和接收 cookie。
- getAllResponseHeaders()方法始终返回空字符串。

#### 预检请求

CORS通过语种预检请求的服务器验证机制，允许使用自定义头部、除 GET 和 POST 之外的方法，以及不同请求体内容类型。在要发送涉及上述某种高级选项的请求时，会先向服务器发送一个“预检”请求。这个请求使用 OPTIONS 方法发送并包含以下头部。

- Origin:与简单请求相同。
- Access-Control-Request-Method:请求希望使用的方法。
- Access-Control-Request-Headers:(可选)要使用的逗号分隔的自定义头部列表。

请求发送后，服务器可以确定是否允许这种类型的请求，服务器会在响应头中发送如下响应头:

- Access-Control-Allow-Origin:与简单请求相同。
- Access-Control-Allow-Methods:允许的方法(逗号分隔的列表)。
- Access-Control-Allow-Headers:服务器允许的头部(逗号分隔的列表)。
- Access-Control-Max-Age:缓存预检请求的秒数。

预检请求返回后，结果会按响应指定的时间缓存一段时间。换句话说，只有第一次发送这种类型的 请求时才会多发送一次额外的 HTTP 请求。

#### 凭据请求

默认情况，跨域不提供cookie，http认证和ssl证书。可以通过将 withCredentials 属性设置为 true 来表明请求会发送凭据。如果服务器允许带凭据的请求，那么可 以在响应中包含如下 HTTP 头部:

```txt
    Access-Control-Allow-Credentials: true
```

#### cors外的跨源技术

**图片探测**

图片探测是与服务器之间简单、跨域、 26 单向的通信。数据通过查询字符串发送，响应可以随意设置，不过一般是位图图片或值为 204 的状态码。 浏览器通过图片探测拿不到任何数据，但可以通过监听 onload 和 onerror 事件知道什么时候能接收 到响应。只能发送GET请求以及能不能获取响应内容

**JSONP**

JSONP 格式包含两个部分:回调和数据。回调是在页面接收到响应之后应该调用的函数，通常回调函数的名称是通过请求来动态指定的。而数据就是作为参数传给回调函数的 JSON 数据。之后js再执行服务端返回的已经拼接好的带有参数的函数。（注意回调函数需提前定义好）

```js
function callback(data){
  //...
}

// jsonp
// 返回 callback(data) 在新建的script脚本执行
callback(data)
```

### Fetch

#### 基本使用

fetch方法只有一个必要参数

```js
fetch(url)
```

方法执行后会返回一个Promise，解决是一个Response对象,我们需要读取Response对象中的text()来获取数据，而text方法还会返回一个promise，所以写法如下：

```js
    fetch('http://saberblog.topzhang.cn/article').then(res => {
      console.log(res);
      // 或者res.json()处理json
      return res.text()
    }).then(res =>{
      console.log(res);
    })
```

#### 处理状态码和请求失败

fetch支持 Response的status和statusText属性检查响应状态。

```js
    fetch('http://xxx.xxx.cn/article').then(res => {
      console.log(res);
      console.log(res.status); // 200
      console.log(res.statusText);// ok
      // 或者res.json()处理json
      return res.text()
    }).then(res =>{
      console.log(res);
    })
```

遇到违反 CORS、无网络连接、HTTPS 错配及其他浏览器/网络策略问题都会导致期约被拒绝。可以通过url属性查询fetch()发送时的完整url

```js
  fetch('www.a.com/article').then(res => {
      console.log(res.url);
    })
```

#### 自定义选项

只向fetch中传递一个参数时，fetch就会发送get请求，也只包含必要的请求头，要进一步配置请求，需要传入第二个参数init对象 
属性看这个 https://developer.mozilla.org/en-US/docs/Web/API/fetch

与 XMLHttpRequest 一样，fetch()既可以发送数据也可以接收数据。使用 init 对象参数，可以配置 fetch()在请求体中发送各种序列化的数据。

```js
    let payload = JSON.stringify({
      foo: 'bar'
    });
    let jsonHeaders = new Headers({
      'Content-Type': 'application/json'
    });
    fetch('http://www.abc.com/send-me-json', {
      method: 'POST', // 发送请求体时必须使用一种 HTTP 方法 body: payload,
      headers: jsonHeaders
    });
```

**加载blob文件**

Fetch API 也能提供 Blob 类型的响应，而 Blob 又可以兼容多种浏览器 API。一种常见的做法是明确将 图片文件加载到内存，然后将其添加到 HTML 图片元素。为此，可以使用响应对象上暴露的 blob()方法。 这个方法返回一个期约，解决为一个 Blob 的实例。然后，可以将这个实例传给 URL.createObjectUrl() 以生成可以添加给图片元素 src 属性的值:

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>fetch</title>
</head>

<body>
  <img id="img" width="200" height="200" src="" alt="">
  <script>
    const image = document.getElementById('img')
    fetch('https://p3.music.126.net/BMtoKNKsW9VV6Bsc1L-wGw==/109951168025869701.jpg?param=90y90').then(res => {
     return res.blob();
    }).then(res => {
      console.log(res);
      image.src = URL.createObjectURL(res)
    })
  </script>
</body>

</html>
```

**中断请求**

Fetch API 支持通过 AbortController/AbortSignal 对中断请求。

调用 AbortController. abort()会中断所有网络传输，特别适合希望停止传输大型负载的情况。

```js
    let abortController = new AbortController();
    const image = document.getElementById('img')
    fetch('https://p3.music.126.net/BMtoKNKsW9VV6Bsc1L-wGw==/109951168025869701.jpg?param=90y90', { signal: abortController.signal }).then(res => {
      return res.blob();
    }).then(res => {
      console.log(res);
      image.src = URL.createObjectURL(res)
    })
    setTimeout(() => abortController.abort(), 10)
```

题外话 AbortController 也支持对事件进行取消。

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>fetch</title>
</head>

<body>
  <img id="img" width="200" height="200" src="" alt="">
  <button id="btn">取消</button>
  <script>
    let abortController = new AbortController();
    const image = document.getElementById('img')
    image.addEventListener('click', (e) => {
      console.log(e);
    }, { signal: abortController.signal })
    const btn = document.getElementById('btn');
    btn.addEventListener('click', () => {
      abortController.abort();
    })
  </script>
</body>

</html>
```

#### Headers 对象

Headers 对象与 Map 对象极为相似。这是合理的，因为 HTTP 头部本质上是序列化后的键/值对，

它们的 JavaScript 表示则是中间接口。Headers 与 Map 类型都有 get()、set()、has()和 delete() 等实例方法，如下面的代码所示:

```js
    let h = new Headers();
    let m = new Map();
    // 设置键 
    h.set('foo', 'bar');
    m.set('foo', 'bar');
    // 检查键
    console.log(h.has('foo')); // true 
    console.log(m.has('foo')); // true 
    console.log(h.has('qux')); // false 
    console.log(m.has('qux')); // false
    // 获取值 
    console.log(h.get('foo')); // bar 
    console.log(m.get('foo')); // bar
    // 更新值 
    h.set('foo', 'baz');
    m.set('foo', 'baz');
    console.log(h);
```

Headers独有的特性，Headers可以在初始化的时候使用键/值对进行初始化

```js
let h = new Headers({k1:'v1'});
console.log(h.get('k1'));
```

#### fetch使用可读流

```js
    const decoder = new TextDecoder();
    fetch('https://fetch.spec.whatwg.org/')
      .then((response) => response.body)
      .then(async (body) => {
        let reader = body.getReader();
        console.log(reader); // ReadableStreamDefaultReader {}
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            break;
          } else {
            console.log(decoder.decode(value, { stream: true }))
          }
        }
      });
```

上述的读取流的过程可以利用生成器结合循环进行简化:

```js
    const decoder = new TextDecoder();
    fetch('https://fetch.spec.whatwg.org/')
      .then((response) => response.body)
      .then(async (body) => {
        for await (const chunk of streamGenerator(body)) {
          console.log(decoder.decode(chunk, { stream: true }));
        }
      });

    async function* streamGenerator(stream) {
      const reader = stream.getReader();
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            break;
          } else {
            yield value;
          }
        }
      } catch (error) {
        console.log(error);
        // 如果异常就释放对流的锁定
        reader.releaseLock();
      }
    }
```

**双流技术**

因为可以使用 ReadableStream 创建 Response 对象，所以就可以在读取流之后，将其通过管道导入另一个流。这样就可以随着流的到达实时检 查和操作流内容。

```js
    fetch('https://fetch.spec.whatwg.org/')
      .then((response) => response.body)
      .then(async (body) => {
        const reader = body.getReader();
        return new ReadableStream({
          async start(controller) {
            try {
              while (true) {
                const {
                  done,
                  value
                } = await reader.read();
                if (done) {
                  break;
                } else {
                  controller.enqueue(value);
                }
              }
            } finally {
              controller.close();
              reader.releaseLock();
            }
          }
        })
      }).then(res => new Response(res)).then(res =>
        res.text()
      ).then(console.log)
```

### Beacon API

### web socket

## 客户端存储

### cookie

最初用于在客户端存储会话信息

#### 限制

- 不超过 300 个 cookie;
- 每个 cookie 不超过 4096 字节（4kb。。。）;
- 每个域不超过 20 个 cookie;
- 每个域不超过 81 920 字节。

#### cookie的构成

- 名称：唯一标识cookie的名称，cookie不区分大小写，cookie名称必须经过url编码。
- 值：存储在cookie中的字符串值，也需要url编码。
- 域：cookie的有效域
- 路径： 请求URL中默认包含这个路径才会把cookie发送到服务器
- 过期时间： 表示什么时候删除cookie
- 安全标志：设置之后只有ssl链接才会吧cookie发送到服务器。

上述这些值会在cookie中以key/value的形式，并以分号；间隔开。

域、路径、过期时间和 secure 标志用于告诉浏览器什么情况下应该在请求中包含 cookie。这些参数并不会随请求发送给服务器，实际发送的只有 cookie 的名/值对。



#### 操作cookie

设置cookie的值或者名称最好对值和名称都进行encodeURIComponent()。

下面是一个简单的cookie操作工具代码

```js
    class CookieUtils {
      static get(name) {
        let cookieName = `${encodeURIComponent(name)}=`,
          cookieStart = document.cookie.indexOf(cookieName),
          cookieValue = null;
        if (cookieStart > -1) {
          // 从start开始找到;的位置
          let cookieEnd = document.cookie.indexOf(";", cookieStart);
          if (cookieEnd === -1) {
            cookieEnd = document.cookie.length;
          }
          cookieValue = decodeURIComponent(document.cookie.slice(cookieStart + cookieName.length, cookieEnd));
        }
        return cookieValue;
      }

      static set(name, value, expires, path, domain, secure) {
        let cookieText =
          `${encodeURIComponent(name)}=${encodeURIComponent(value)}`
        if (expires instanceof Date) {
          cookieText += `; expires=${expires.toGMTString()}`;
        }
        if (path) {
          cookieText += `; path=${path}`;
        }
        if (domain) {
          cookieText += `; domain=${domain}`;
        }
        if (secure) {
          cookieText += "; secure";
        }
        document.cookie = cookieText;
      }

      static unset(name, path, domain, secure) {
        CookieUtils.set(name, "", new Date(0), path, domain, secure);
      }
    }

    CookieUtils.set('k1', 'v1', new Date('2024'))
    CookieUtils.unset('k1');
    console.log(CookieUtils.get('k1'));
```

#### 子cookie

为了绕过浏览器对每个域的cookie数限制，子cookie的概念产生了。本质上就是在cookie中的单个值存储错个key/value。最常用的模式如下：

```js
name=name1=value1&name2=value2&name3=value3&name4=value4&name5=value5
```

```js
    class SubCookieUtils {
      // 获取cookie
      static get(name, subName) {
        let subCookies = SubCookieUtils.getAll(name);
        return subCookies ? subCookies[subName] : null;
      }
      // 获取所有的子cookie
      static getAll(name) {
        let cookieName = encodeURIComponent(name) + "=",
          cookieStart = document.cookie.indexOf(cookieName),
          cookieValue = null,
          cookieEnd,
          subCookies,
          parts,
          result = {};

        if (cookieStart > -1) {
          cookieEnd = document.cookie.indexOf(";", cookieStart);
          if (cookieEnd == -1) {
            cookieEnd = document.cookie.length;
          }
          cookieValue = document.cookie.substring(cookieStart +
            cookieName.length, cookieEnd);
          if (cookieValue.length > 0) {
            subCookies = cookieValue.split("&");
            for (let i = 0, len = subCookies.length; i < len; i++) {
              parts = subCookies[i].split("=");
              result[decodeURIComponent(parts[0])] =
                decodeURIComponent(parts[1]);
            }
            return result;
          }
        }
        return null;
      }

      static set(name, subName, value, expires, path, domain, secure) {
        let subcookies = SubCookieUtils.getAll(name) || {};
        subcookies[subName] = value;
        SubCookieUtils.setAll(name, subcookies, expires, path, domain, secure);
      }

      static setAll(name, subcookies, expires, path, domain, secure) {
        let cookieText = encodeURIComponent(name) + "=",
          subcookieParts = new Array(),
          subName;
        console.log(subcookieParts);
        for (subName in subcookies) {
          if (subName.length > 0 && subcookies.hasOwnProperty(subName)) {
            subcookieParts.push(
              `${encodeURIComponent(subName)}=${encodeURIComponent(subcookies[subName])}`);
          }
        }
        if (subcookieParts.length > 0) {
          cookieText += subcookieParts.join("&");
          if (expires instanceof Date) {
            cookieText += `; expires=${expires.toGMTString()}`;
          }
          if (path) {
            cookieText += `; path=${path}`;
          }
          if (domain) {
            cookieText += `; domain=${domain}`;
          }
          if (secure) {
            cookieText += "; secure";
          }
        } else {
          cookieText += `; expires=${(new Date(0)).toGMTString()}`;
        }
        document.cookie = cookieText;
      }

      static unset(name, subName, path, domain, secure) {
        // 取出所有的子cookie然后删除，最后再将剩下的重新设置
        let subcookies = SubCookieUtils.getAll(name);
        if (subcookies) {
          delete subcookies[subName]; // 删除
          SubCookieUtils.setAll(name, subcookies, null, path, domain, secure);
        }
      }
      static unsetAll(name, path, domain, secure) {
        SubCookieUtils.setAll(name, null, new Date(0), path, domain, secure);
      }
    }

    document.cookie = `data=c1=cv1&c2=cv2;`;

    SubCookieUtils.set('data', 'c2', '666')
    console.log(document.cookie);
    SubCookieUtils.unsetAll('data')
    console.log(document.cookie);
```



### Web Storage

两个对象localStorage和sessionStorage

**注意**Storage 类型只能存储字符串。非字符串数据在存储之前会自动转换为字符串。 注意，这种转换不能在获取数据时撤销。

sessionStorage对象只能存储会话数据，这意味着数据在浏览器关闭后就会被清除。

localStorage则是永久存储，除非用户手动删除

#### 存储事件

当Storage对象发生变化时，会在文档上触发storage事件。使用属性或者setItem()设置值，使用delete或者removeItem()删除值，以及每次调用clear()都会触发这个事件，事件的对象有以下四个属性：

- domain
- key
- newValue 设置后的值 被删除则为null
- oldValue 设置前的值

```js
  window.addEventListener("storage",
        (event) => alert('Storage changed for ${event.domain}'));
```

#### 限制

Web Storage 也有限制。具体限制取决于特定的浏览器。

不同浏览器给 localStorage 和 sessionStorage 设置了不同的空间限制，但大多数会限制为每 个源 5MB。

### IndexDB

是浏览器中存储机构话数据的方法

indexDB类似MYsql的数据库，相比的不同点是indexDB使用的是对象存储而不是表格存储

#### 使用方式

- 调用indexedDB.open()方法 
  参数是要打开的数据库名称，如果存在，则就是发送一个打开它的请求，不存在就会创建并打开。方法返回一个IDBRequest实例，可以在实力上加上onerror和onsuccess事件。

  ```js
      const myIndexedDB = indexedDB.open('test1');
      myIndexedDB.onsuccess = function(e) {
        console.log(e.target.result);// IDBDatabase {}
      }
      myIndexedDB.onerror = function(e) {
       
      }
  ```

- 创建好后我们就该使用对象存储了，我们存储一个对象，其对象一定要有一个唯一的键。

  ```js
      const myIndexedDB = indexedDB.open('test1');
      myIndexedDB.onsuccess = function (e) {
        console.log(e.target.result);// IDBDatabase {}
      }
      myIndexedDB.onerror = function (e) {
  
      }
  // 数据库未存在第一次调用open会触发
      myIndexedDB.onupgradeneeded = function (e) {
        const db = e.target.result;
        // 第二个参数的 keyPath 属性表示应该用作键的存储对象的属性名。
        const store = db.createObjectStore("users", { keyPath: "username" });
      }
  ```

- 事务

  创建了对象存储之后，剩下的操作就交由事务来完成了

  - 首先我们创建事务
    ```js
    //  如果不指定参数，则对数据库中所有的对象存储有只读权限。
    let transaction = db.transaction();
    // 更具体的方式是指定一个或多个要访 问的对象存储的名称(多个就用数组格式)
     let transaction = db.transaction("users");
    // or
    let transaction = db.transaction(["users", "anotherStore"]);
    // 第二个参数 设置访问模式
    // "readonly"、"readwrite"或"versionchange"。
     let transaction = db.transaction("users", "readwrite");
    ```

  有了事务的引用，就可以使用 objectStore()方法并传入对象存储的名称以访问特定的对象存储。 然后，可以使用 add()和 put()方法添加和更新对象，使用 get()取得对象，使用 delete()删除对象， 使用 clear()删除所有对象。其中，get()和 delete()方法都接收对象键作为参数，这 5 个方法都创 建新的请求对象

  🌰：

  ```js
      const myIndexedDB = indexedDB.open('test1');
      myIndexedDB.onsuccess = function (e) {
        //console.log(e.target.result);// IDBDatabase {}
        const db = e.target.result;
        let transaction = db.transaction('users', "readwrite"),
          store = transaction.objectStore("users"),
          request1 = store.get('zhangsan1')
        // 这里添加对象可以用add和put，区别在于add只能新增，如果添加重复键的对象会保存，而put就可以添加重复键对象，会覆盖原来的对象，可以理解为add为新增，而put为更新。
          request = store.add({
            username: 'zhangsan1',
            age: 18
          });
          request.onsuccess = (e) => {
            console.log('success',e);
          }
          request.onerror = (e) => {
            console.log('error',e);
          }
          request1.onsuccess = (e) => {
            console.log('success', e.target.result);
          }
          request1.onerror = (e) => {
            console.log('error',e);
          }
  
          // 事务本身也有事件
          transaction.onsuccess = function(e) {
            console.log('transaction-success',e);
          }
          transaction.onerror = function(e) {
            console.log('transaction-error',e);
          }
  
      }
      myIndexedDB.onerror = function (e) {
  
      }
      myIndexedDB.onupgradeneeded = function (e) {
        console.log(11);
        const db = e.target.result;
        db.createObjectStore("users", { keyPath: "username" });
      }
  ```

  **注意**不能通过 oncomplete 事件处理程序的 event 对象访问 get()请求返回的任何数据。因此，仍然需要通过这些请求的 onsuccess 事件处理程序来获取数据

#### 通过游标查询

使用事务可以通过一个已知的键进行查找记录，如果想获取多条数据，就需要在事务中创建一个游标

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        request = store.openCursor();


        request.onsuccess = (e) => {
          console.log('openCursor-success',e);
        }
        request.onerror = (e) => {
          console.log('openCursor-error',e);
        }

        // 事务本身也有事件
        transaction.onsuccess = function(e) {
          console.log('transaction-success',e);
        }
        transaction.onerror = function(e) {
          console.log('transaction-error',e);
        }

    }
    myIndexedDB.onerror = function (e) {

    }
    myIndexedDB.onupgradeneeded = function (e) {
      console.log(11);
      const db = e.target.result;
      db.createObjectStore("users", { keyPath: "username" });
    }
```

在调用 onsuccess 事件处理程序时，可以通过 event.target.result 访问对象存储中的下一条 记录，这个属性中保存着 IDBCursor 的实例(有下一条记录时)或 null(没有记录时)。这个 IDBCursor 实例有几个属性。

- direction:字符串常量，表示游标的前进方向以及是否应该遍历所有重复的值。可能的值包括: NEXT("next")、NEXTUNIQUE("nextunique")、PREV("prev")、PREVUNIQUE("prevunique")。

- key:对象的键。

- value:实际的对象。

- primaryKey:游标使用的键。可能是对象键或索引键

  可以像下面这样取得一个结果:

```js

request.onsuccess = (event) => { const cursor = event.target.result; if (cursor) { // 永远要检查
console.log(`Key: ${cursor.key}, Value: ${JSON.stringify(cursor.value)}`); }
};
```

游标可用于更新个别记录。update()方法使用指定的对象更新当前游标对应的值。与其他类似操作 一样，调用 update()会创建一个新请求

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        request = store.openCursor();


      request.onsuccess = (e) => {
        const cursor = event.target.result; let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          if (cursor.key == "zhangsan") {
            value = cursor.value;
            value.age = 99;
            // 更新当前游标所指向的对象
            updateRequest = cursor.update(value);
            // 请求保存更新后的对象 
            updateRequest.onsuccess = () => {
              // 处理成功 
            };
            updateRequest.onerror = () => { // 处理错误
            };
          }
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }
```

当然也可以使用delete来删除游标所指向的对象

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        request = store.openCursor();


      request.onsuccess = (e) => {
        const cursor = event.target.result; let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          if (cursor.key == "zhangsan") {
            value = cursor.value;
            value.age = 99;
            updateRequest = cursor.delete(value);
            // 请求保存更新后的对象 
            updateRequest.onsuccess = () => {
              // 处理成功 
            };
            updateRequest.onerror = () => { // 处理错误
            };
          }
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }

```

**注意**如果事务没有修改对象存储的权限，update()和 delete()都会抛出错误。

默认情况下，每个游标只会创建一个请求。要创建另一个请求，必须调用下列中的一个方法。

- continue(key):移动到结果集中的下一条记录。参数 key 是可选的。如果没有指定 key，游标就移动到下一条记录;如果指定了，则游标移动到指定的键。
- advance(count):也是和continue类似 ，游标向前移动指定的 count 条记录。

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        request = store.openCursor();


      request.onsuccess = (e) => {
        const cursor = event.target.result;
        let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          value = cursor.value;
          value.age = 99;
          // continue 方法参数可选 默认移动到下一个key，设置了值就移动到对应key的地方
          cursor.continue();// 调用后会触发request.onsuccess事件直到最后一个键
          console.log(cursor.value);
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }
```

#### 键范围

使用键范围(key range) 可以让游标更容易管理。键范围对应 IDBKeyRange 的实例。有四种方式指定键范围，第一种是使用 only()方法并传入想要获取的键:

```js
 // 只获取"007"记录
const onlyRange = IDBKeyRange.only("007");
      console.log(onlyRange);

      // 从"007"记录开始，直到最后
      const lowerRange = IDBKeyRange.lowerBound("007");
      console.log(lowerRange);
      // 从"007"的下一条记录开始，直到最后(开区间)
      const lowerRange1 = IDBKeyRange.lowerBound("007", true);
      console.log(lowerRange1);

      // 从头开始，到"ace"记录为止
      const upperRange = IDBKeyRange.upperBound("ace");
      console.log(upperRange);
      // 从头开始，到"ace"的前一条记录为止(开区间)
      const upperRange1 = IDBKeyRange.upperBound("ace", true);
      console.log(upperRange1);


      // 同时指定上下限
      // 从"007"记录开始，到"ace"记录停止
      const boundRange = IDBKeyRange.bound("007", "ace");
      // 从"007"的下一条记录开始，到"ace"记录停止
      const boundRange1= IDBKeyRange.bound("007", "ace", true);
      // 从"007"的下一条记录开始，到"ace"的前一条记录停止
      const boundRange2 = IDBKeyRange.bound("007", "ace", true, true); // 从"007"记录开始，到"ace"的前一条记录停止
      const boundRange3 = IDBKeyRange.bound("007", "ace", false, true);
      console.log(boundRange, boundRange1, boundRange2, boundRange3);
```

定义了范围之后，把范围传给 openCursor()方法，就可以得到位于该范围内的游标:

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        boundRange = IDBKeyRange.bound("zhangsan", "zhangsan1", false, false);
        request = store.openCursor(boundRange);

      request.onsuccess = (e) => {
        const cursor = event.target.result;
        let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          value = cursor.value;
          value.age = 99;
          // continue 方法参数可选 默认移动到下一个key，设置了值就移动到对应key的地方
          cursor.continue();
          console.log(cursor.value);
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }
```

#### 设置游标方向

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        boundRange = IDBKeyRange.bound("zhangsan", "zhangsan1", false, false);
      // 还有nextunique prevunique prev三个方向。nextunique prevunique 只是过滤出不重复的记录 当然正常情况也不应该存在键重复的情况，所以这个方法应该是处理一些未知异常导致的键重复问题
        request = store.openCursor(boundRange, 'prev');

      request.onsuccess = (e) => {
        const cursor = event.target.result;
        let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          console.log(cursor.value);
          // continue 方法参数可选 默认移动到下一个key，设置了值就移动到对应key的地方
          cursor.continue();
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }
```

#### 索引

```js
    const myIndexedDB = indexedDB.open('test1', 3);
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('users', "readwrite"),
        store = transaction.objectStore("users"),
        boundRange = IDBKeyRange.bound("zhangsan", "zhangsan1", false, false);
      request = store.openCursor(boundRange, 'prev');

      request.onsuccess = (e) => {
        const cursor = event.target.result;
        let value,
          updateRequest;
        if (cursor) { // 永远要检查 
          console.log(cursor.value);
          // continue 方法参数可选 默认移动到下一个key，设置了值就移动到对应key的地方
          cursor.continue();
        }
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }
   
// 需要在触发更新的时候设置索引
    myIndexedDB.onupgradeneeded = function (e) {
      const db = e.target.result;
      let store = db.createObjectStore('role1', { keyPath: 'username' });
      const index = store.createIndex("username", "username", { unique: true });
      console.log(index);
    }
```

通过索引来高效检索

```js
    const myIndexedDB = indexedDB.open('test1');
    myIndexedDB.onsuccess = function (e) {
      //console.log(e.target.result);// IDBDatabase {}
      const db = e.target.result;
      let transaction = db.transaction('role1', "readwrite"),
        store = transaction.objectStore("role1");
          store.openCursor(boundRange, 'nextunique');
      const index = store.index('username');

      request = index.get('zhgangsan666')

      request.onsuccess = (e) => {
        console.log(event.target.result);
      }
      request.onerror = (e) => {
        console.log('openCursor-error', e);
      }

      // 事务本身也有事件
      transaction.onsuccess = function (e) {
        console.log('transaction-success', e);
      }
      transaction.onerror = function (e) {
        console.log('transaction-error', e);
      }

    }

    myIndexedDB.onupgradeneeded = function (e) {
      const db = e.target.result;
      let store = db.createObjectStore('role1', { keyPath: 'username' });
      const index = store.createIndex("username", "username", { unique: true });
      console.log(index);
    }
```



#### 并发

两个不同的标签同时打开会存在这个问题。

第一次打开数据库时，添加 onversionchange 事件处理程序非常重要。另一个同源标签页将数据库打开到新版本时，将执行此回调。对这个事件最好的回应是立即关闭数据库，以便完成版本升级。例如:

```js
let request, database;
request = indexedDB.open("admin", 1);
request.onsuccess = (event) => {
  database = event.target.result;
  database.onversionchange = () => database.close();
};
```

## 模块

### 入口

相互依赖的模块必须制定一个模块作为入口，这也是代码执行的起点。js是顺序执行的，单线程。下图就是一个有向图表示的模块依赖关系。

![image-20230904114311934](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230904114311934.png)

所以模块依赖的加载方式有如下：

- 同步加载 模块加载是 阻塞 的 这种方式存在性能和复杂度问题。
- 异步依赖 在必要的时候加载新模块，按需引入。script标签里的应用 defer 或 async 属性，再加上能够识别异步 脚本何时加载和初始化的逻辑。
- 动态依赖 在程序的运行中动态的引入依赖

#### 静态分析

模块中包含的发送到浏览器的 JavaScript 代码经常会被静态分析，分析工具会检查代码结构并在不实际执行代码的情况下推断其行为。对静态分析友好的模块系统可以让模块打包系统更容易将代码处理 为较少的文件。它还将支持在智能编辑器里智能自动完成。

更复杂的模块行为，例如动态依赖，会导致静态分析更困难。不同的模块系统和模块加载器具有不 同层次的复杂度。至于模块的依赖，额外的复杂度会导致相关工具更难预测模块在执行时到底需要哪些 依赖。

#### 循环依赖

js中要想构建一个没有循环依赖的js应用程序是不可能的，所以目前主流的模块解决方案cjs amd和esm都支持循环依赖。

例如如下模块模拟依赖加载顺序：

![image-20230905211942538](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230905211942538.png)

如果moudleA先加载打印如下：

```js
moduleB  
moduleC
moduleD
moduleA
```

如果c先加载则打印如下：

```js
moduleD
moduleA
moduleB
moduleC
```

加载器对于循环引用则是利用深度优先的方式进行加载：

![image-20230905212343960](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230905212343960.png)

#### 闭包实现一个凑合的模块系统

```js
    (function() {
      let a = 1;
      console.log(a);
    })()
```

暴露一个公共对象

```js
    const Foo = (function() {
      return  {
        bar:'baz',
        baz:function() {
          return this.bar;
        }
      }
    })();
    console.log(Foo.baz());
```

**泄漏模块模式**

```js
    const Foo = (function () {
      let bar = 'bar';
      let baz = function () {
        console.log(bar);
      }
      return {
        bar,
        baz
      }
    })();
    Foo.baz()
    console.log(Foo.bar);
```

**嵌套的模块**

```js
    const Foo = (function () {
      let bar = 'bar';
      let baz = function () {
        console.log(bar);
      }
      return {
        bar,
        baz
      }
    })();
    Foo.baz = (function () {
      return {
        foo:function() {
          console.log('foo');
        }
      }
    })() 
    Foo.baz.foo();
    console.log(Foo.bar);
```

传递参数

```js
    const Foo = (function (global) {
      let bar = 'bar';
      let baz = function () {
        console.log(bar, global);
      }
      return {
        bar,
        baz
      }
    })('666');
    Foo.baz();
```

拓展模块

```js
    let Foo = (function (global) {
      let bar = 'bar';
      let baz = function () {
        console.log(bar, global);
      }
      return {
        bar,
        baz
      }
    })('666');
    Foo.baz(); //bar 666
    Foo = (function(module) {
      module.baz = function() {
        console.log(Foo.bar);
      }
      return module;
    })(Foo);

    Foo.baz(); //bar
```

#### cjs

cjs规范概述了同步声明依赖的模块定义

**注意** 一般认为，Node.js的模块系统使用了CommonJS规范，实际上并不完全正确。Node.js 使用了轻微修改版本的 CommonJS，因为 Node.js 主要在服务器环境下使用，所以不需要考虑网络延迟问题。

CommonJS 模块定义需要使用 require()指定依赖，而使用 exports 对象定义自己的公共 API。

```js
// 导出
const a  = {word: 'hello'};

module.exports = {
  a
}
```

```js
// 导出
const a = require('./a');

const a1 = require('./a');
// 单例模式 只会加载一次
console.log(a === a1);
```

cjs中模块加载是同步操作，也是运行时加载，所以可以配合条件语句进行动态加载

#### 异步模块 AMD

#### esmodule

与传统脚本不同，所有模块都会像<script defer>加载的脚本一样按顺序执行。解析到<script type="module">**标签后会立即下载模块文件，但执行会延迟到文档解析完成**。无论对嵌入的模块代码， 还是引入的外部模块文件，都是这样。<script type="module">在页面中出现的顺序就是它们执行 的顺序。与<script defer>一样，修改模块标签的位置，无论是在<head>还是在<body>中，只会影 响文件什么时候加载，而不会影响模块什么时候加载。

![image-20230905220434507](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230905220434507.png)

也可以给模块标签添加 async 属性。这样影响就是双重的:不仅模块执行顺序不再与<script>标 签在页面中的顺序绑定，模块也不会等待文档完成解析才执行。不过，入口模块仍必须等待其依赖加载完成。

与<script type="module">标签关联的 ES6 模块被认为是模块图中的入口模块。一个页面上有多少个入口模块没有限制，重复加载同一个模块也没有限制。同一个模块无论在一个页面中被加载多少次，也不管它是如何加载的，实际上都只会加载一次。

```js
<!-- moduleA 在这个页面上只会被加载一次 -->
    <script type="module">
      import './moduleA.js'
    <script>
    <script type="module">
      import './moduleA.js'
    <script>
    <script type="module" src="./moduleA.js"></script>
    <script type="module" src="./moduleA.js"></script>
```

#### 模块行为

esmodule有以下特点：

- 模块只在加载后执行
- 模块只能加载一次
- 模块是单例
- 模块可以定义公共接口，其他模块可以基于这个公共接口观察和交互。
- 模块可以请求加载其他模块。
- 支持循环依赖。
- ES6 模块默认在严格模式下执行。
- ES6 模块不共享全局命名空间。
- 模块顶级 this 的值是 undefined(常规脚本中是 window)。
- 模块中的 var 声明不会添加到 window 对象。
-  ES6 模块是异步加载和执行的。

#### 模块导出

导出语句必须在模块顶级，不能有嵌套。

命名导出

```js
export { a }
```

默认导出

```js
export default a
// 也相当于 export { a as default }
```

命名导出和默认导出不会冲突，所以 ES6 支持在一个模块中同时定义这两种导出

```js
export { a }
export default b;
//等于 export {a, b as default};
```

#### 模块导入

```js
import { a } from 'xxx';
```

导入对模块而言是只读的，实际上相当于 const 声明的变量。在使用*执行批量导入时，赋值给别名的命名导出就好像使用 Object.freeze()冻结过一样。直接修改导出的值是不可能的，但可以修改导出对象的属性。同样，也不能给导出的集合添加或删除导出的属性。要修改导出的值，必须使用有内部变量和属性访问权限的导出方法。

命名导入

```js
// 也可以指定别名    
import { foo, bar, baz as baz_xx } from 'xxxx'
// 或者使用as 来聚合选项 就不用一个一个列出来
import * as Foo from './foo.js';
// console.log(Foo.foo);

```

默认导入

```js
// 等效
import { default as foo } from './foo.js'; import foo from './foo.js';
```

默认导入导出合并为命名导出

```js
// d.js
const a = 'hello';
const b = 'world';

export default {
  a, b
};


//------
// c.js 
import ab from'./d.js';
export {
   ab
}

// 和上面的分开导入再导出的效果一致
export {default as ab} from './d.js'
//------


// 使用
 import { ab } from './c.js'
 console.log(ab.a,ab.b);




```



#### 模块转移导出

```js
// foo 
const a = 'hello';
const b = 'world';

export { a, b };


// bar
export * from './foo.js';


// 导入bar的入口文件
 import { a, b } from './bar.js'

 console.log(a, b);
```

默认导出转移

```js
// foo 
const a = 'hello';
const b = 'world';

export default b;


// bar
export { default } from './foo.js';


// 导入bar的入口文件
 import xx from './bar.js'

 console.log(xx);// world
```

命名导入转为默认导入

```js
// foo 
const a = 'hello';
const b = 'world';

export {
  a, b
};


// bar
export {a, b as default} from './foo.js';


// 导入bar的入口文件
 import b, { a } from './bar.js'
 console.log(a,b);
```

#### 工作者模块

ECMAScript 6 模块与 Worker 实例完全兼容。在实例化时，可以给工作者传入一个指向模块文件的 路径，与传入常规脚本文件一样。Worker 构造函数接收第二个参数，用于说明传入的是模块文件。

下面是两种类型的 Worker 的实例化行为:

```js
// 第二个参数默认为{ type: 'classic' }
const scriptWorker = new Worker('scriptWorker.js');
const moduleWorker = new Worker('moduleWorker.js', { type: 'module' });
```

注意：在基于模块的工作者内部，self.importScripts()方法通常用于在基于脚本的工作者中加载外 部脚本，调用它会抛出错误。这是因为模块的 import 行为包含了 importScripts()。

#### 向后兼容

```js
// 支持模块的浏览器会执行这段脚本
// 不支持模块的浏览器不会执行这段脚本
<script type="module" src="module.js"></script>
// 支持模块的浏览器不会执行这段脚本
// 不支持模块的浏览器会执行这段脚本
<script nomodule src="script.js"></script>
```

## 工作者线程

一般来讲，JS是单线程，这描述了 JavaScript 在浏览器 中的一般行为。

工作者线程的价值所在:允许把主线程的工作转嫁给独立的实体，而不会改变现有的单线程模型。

JavaScript 环境实际上是运行在托管操作系统中的虚拟环境。在浏览器中每打开一个页面，就会分 配一个它自己的环境。这样，每个页面都有自己的内存、事件循环、DOM，等等。每个页面就相当于 一个沙盒，不会干扰其他页面。对于浏览器来说，同时管理多个环境是非常简单的，因为所有这些环境 都是并行执行的。

使用工作者线程，浏览器可以在原始页面环境之外再分配一个完全独立的二级子环境。这个子环境 不能与依赖单线程交互的 API(如 DOM)互操作，但可以与父环境并行执行代码。

### 工作者线程与线程之间的区别

- 工作者线程是以实际的线程实现的
- 工作者线程并行执行
- 工作者线程可以共享某些内存但不共享全部内存
- 创建工作者线程的开销更大，所以不建议大量使用

### 工作者线程的类型

- 专用工作者线程
  专用工作者线程，通常简称为工作者线程、Web Worker 或 Worker，是一种实用的工具，可以让脚 本单独创建一个 JavaScript 线程，以执行委托的任务。专用工作者线程，顾名思义，只能被创建它的页 面使用。

- 共享工作者线程

  共享工作者线程与专用工作者线程非常相似。主要区别是共享工作者线程可以被多个不同的上下文使用，包括不同的页面。任何与创建共享工作者线程的脚本同源的脚本，都可以向共享工作者线程发送 消息或从中接收消息。

- 服务工作者线程
  服务工作者线程与专用工作者线程和共享工作者线程截然不同。它的主要用途是拦截、重定向和修 改页面发出的请求，充当网络请求的仲裁者的角色。

### WorkerGlobalScope

在工作者线程内部，没有window的概念。这里的全局对象是 WorkerGlobalScope 的实例，通过 self 关键字暴露出来。

```js
// 工作者线程
console.log(self)
```

![image-20231007094133392](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007094133392.png)

### 专用工作者线程

#### 创建专用工作者线程

最常见的方法是直接加载js文件

```js
console.log(location.href); // "https://example.com/"
const worker = new Worker(location.href + 'emptyWorker.js'); console.log(worker); // Worker {}
```

#### 工作者线程安全的限制

工作者线程脚本文件只能从与父页面相同的源加载。从不同源加载的的脚本会导致错误。

注意：不能使用非同源脚本创建工作者线程，并不影响执行其他源的脚本。在工作者线程内部，使用 importScripts()可以加载其他源的脚本。

#### 使用worker对象

Worker()构造函数返回的 Worker 对象是与刚创建的专用工作者线程通信的连接点。它可用于在工作者线程和父上下文间传输信息，以及捕获专用工作者线程发出的事件。

注意：要管理好使用Worker()创建的每个Worker对象。在终止工作者线程之前，它不 会被垃圾回收，也不能通过编程方式恢复对之前 Worker 对象的引用。

![image-20231007100946290](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007100946290.png)


#### DedicatedWorkerGlobalScope

专用工作者线程内部，全局作用域就是 **DedicatedWorkerGlobalScope**,可以通过self来访问

```js
console.log(self)
```

![image-20231007101429363](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007101429363.png)

工作者线程具有不可忽略的启动延迟，所以即使 Worker 对象存在，工作者线程的日志也会 在主线程的日志之后打印出来。

![image-20231007101838187](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007101838187.png)

#### 专用工作者线程的生命周期

一般会有 初始化，活动，终止这三个阶段。

- 初始化时，虽然工作者线程脚本尚未执行，但可以先把要发送给工作者线程的消息加入队列。这些 消息会等待工作者线程的状态变为活动，再把消息添加到它的消息队列。下面的代码演示了这个过程。

![image-20231007102650059](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007102650059.png)

- 创建之后，专用工作者线程就会伴随页面的整个生命期而存在，除非自我终止(self.close()) 或通过外部终止(worker.terminate())。即使线程脚本已运行完成，线程的环境仍会存在。只要工作者线程仍存在，与之关联的 Worker 对象就不会被当成垃圾收集掉。

  自我终止和外部终止最终都会执行相同的工作者线程终止例程。来看下面的例子，其中工作者线程 在发送两条消息中间执行了自我终止:

  ![image-20231007102719693](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007102719693.png)

- 调用了 close()，但显然工作者线程的执行并没有立即终止。close()在这里会通知工作者线 程取消事件循环中的所有任务，并阻止继续添加新任务。这也是为什么"baz"没有打印出来的原因。工 作者线程不需要执行同步停止，因此在父上下文的事件循环中处理的"bar"仍会打印出来。

![image-20231007102742338](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007102742338.png)

#### 配置worker选项

![image-20231007103726243](/Users/zhangheng/Library/Application Support/typora-user-images/image-20231007103726243.png)

#### 在js行内创建工作者线程

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <script>
    // 创建要执行的 JavaScript 代码字符串 
    const workerScript = `
    self.onmessage = ({data}) => console.log(data);
    `;
    // 基于脚本字符串生成 Blob 对象
    const workerScriptBlob = new Blob([workerScript]);
    // 基于Blob实例创建对象URL
    const workerScriptBlobUrl = URL.createObjectURL(workerScriptBlob);
    // 基于对象 URL 创建专用工作者线程
    const worker = new Worker(workerScriptBlobUrl);
    worker.postMessage('blob worker script');
    // blob worker script

  </script>
</body>

</html>
```

还可以这样写

```js
    function add(a, b) {
      console.log(a+b);
    }
    // 创建要执行的 JavaScript 代码字符串 
    const workerScript = `
    (${add.toString()})(6,7)
    `;
    // 基于脚本字符串生成 Blob 对象
    const workerScriptBlob = new Blob([workerScript]);
    // 基于Blob实例创建对象URL
    const workerScriptBlobUrl = URL.createObjectURL(workerScriptBlob);
    // 基于对象 URL 创建专用工作者线程
    const worker = new Worker(URL.createObjectURL(new Blob([workerScript])));
    worker.postMessage('blob worker script');
    // 13
```

### 共享工作者线程

### 服务工作者线程

## 最佳实践

