## 使用记录

### controll 基本使用

### 错误处理

- 内置错误
- 自定义异常错误
- 异常过滤器
  - 局部过滤器
  - 全局过滤器

### 动态模块

### 循环依赖

**注意：桶形文件引入问题** [参见](https://github.com/nestjs/nest/issues/825)

### 依赖参考

**注意**

ModuleRef 获取的已注册的提供程序是获取的当前模块中实例化的（providers中列出的），不包括imports中的模块实例，要导入其他模块上下文中的提供程序可以设置strict: false

### 动态注入provider

#### 根据配置批量注册provider



## 技术

### 配置

### mongoose

局域网**连接数据库**

连接不上请检查：

- 局域网连接，请检查防火墙是否关闭(win 上搜索防火墙和网络保护，将正在使用的防火墙关闭)
- 以win系统为例，检查 C:\Program Files\MongoDB\Server\[version]\bin\mongod.cfg 中bindIp是否设置的127.0.0.1 ,否则修改为0.0.0.0允许所有ipv4连接

**批量处理字段**

mongo数据库会自带_id和__v这两个字段，如果我们查询想自定义的话可以使用插件进行处理

```ts
import type { Schema } from 'mongoose';
import * as mongoose from 'mongoose';

/**
 * @description id 格式化 生成 带有model前缀的id 注意：定义schema时需要覆盖原本的_id
   详见：https://mongoose.nodejs.cn/docs/guide.html#%E8%AF%86
   设置toJSON和toObject的转换规则
 * @param schema
 * @param catModelName
 * @returns
 */
export function defaultIdFormat(schema: Schema, modelName: string) {
  return function () {
    schema.pre('save', function (next) {
      this._id = `${modelName}-${new mongoose.Types.ObjectId()}`;
      next();
    });
    // toJSON后会默认加上id这个虚拟字段 直接从数据库里查询出来的document对象返回给nestjs控制器会自动调用toJSON
    schema.set('toJSON', {
      virtuals: true,
      transform: (_, ret) => {
        delete ret._id;
        delete ret.__v;
        return ret;
      },
    });
  };
}
```

```ts
// app.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { defaultIdFormat } from './schemas/plugin/id';

import { catModelName, CatSchema, CatDocument } from './schemas/cat.schema';

@Module({
  imports: [
    // ...
    MongooseModule.forFeatureAsync([
      {
        name: catModelName,
        useFactory: () => {
          const schema = CatSchema;
          schema.plugin(defaultIdFormat(schema, catModelName));
          return schema;
        },
      },
    ]),
  ],
  controllers: [],
  providers: [],
})
export class AppModule implements NestModule {}
```

#### 数据库操作

**填充自定义类型**

场景： 用户关联权限，并为权限设置过期时间 使用子文档进行关联查询

schema定义如下：

```ts
// 子文档
export const PermissionSubSchema = new mongoose.Schema(
  {
    id: {
      type: mongoose.Schema.Types.String,
      ref: MODEL_NAME.PERMISSION,
    },
    valid_from: String,
    valid_until: String,
  },
  { _id: false },
);

export const UserSchema = new mongoose.Schema(
  {
    // 自定义id
    _id: String,
   // ...
    permissions: [PermissionSubSchema],
    // ...
  },
  {
    timestamps: true,
  },
);
```

查询并填充：

```ts
this.userModel
//查询条件
      .find({ $and: conditions })
// 填充路径 填充字段
      .populate('permissions.id', 'name code description')
      .exec();

```

**批量更新操作**

场景：为多个符合条件的角色更新引用用户的信息  使用bulkWrite /updateMany

```ts
  // 给角色绑定用户
  async addUser(roles: string[], userId: string) {
    // 批量操作用 bulkWrite 提升效率
    const bulkOps = roles.map((roleId) => ({
      updateOne: {
        filter: { _id: roleId },
        update: {
          $addToSet: {
            users: userId,
          },
        },
      },
    }));
    // 
    return this.roleModel.bulkWrite(bulkOps);
  }

// 或者使用updateMany
```

#### 聚合操作命令

https://www.mongodb.com/zh-cn/docs/manual/reference/operator/aggregation/addFields/



### 验证

对传入服务端的负载进行验证

- 过滤掉类中定义属性外的属性可以通过设置修饰符+whiteList: true来实现

  whitelist：true表示会过滤掉负载中没有修饰符修饰的属性

  ```ts
  class CreateCatDto implements z.infer<typeof createCatScheme> {
    @IsNotEmpty()
    name: string;
  
    @IsNotEmpty()
    @IsNumber()
    age: number;
    // 当不知道设置什么规则约束，设置改修饰符防止被whitelist过滤
    @Allow()
    @Type(() => String)
    breed: string;
  
    @Allow()
    owner: string[];
  
    @Allow()
    sss: string;
  }
  ```

  

- 转换负载对象需要配合class-transformer使用(需要先设置transform: true)
  transform: true是将负载对象转换为类型检测类的实例 即：body instanceof Dto === true

```ts
class CreateCatDto implements z.infer<typeof createCatScheme> {
  @IsNotEmpty()
  name: string;

  age: number;

  breed: string;

  owner: string[];

  @IsNotEmpty()
// transform：true 则会执行转换
  @Transform((value) => value.value + '111111111111111111111111111')
  sss: string;
}
```

### 缓存

使用cache-manage进行缓存处理

**自动缓存响应**

cache-manage 的CacheInterceptor可以用来自动拦截请求进行缓存处理，可以设置在控制器上或者全局设置

```ts
// app.module.ts
// ...
providers: [
    {
      provide: APP_INTERCEPTOR,
      useClass: CacheInterceptor,
    },
  //...
  ],
```

或者单独的控制器上

```ts
@UseInterceptors(CacheInterceptor)
export class CatsController {}
```

### 版本控制

- uri控制
- 自定义标头控制
- Accept标头控制
- 自定义控制

### Redis

**redis安装**

首先安装Redis，以windows为例

[下载地址](https://github.com/tporadowski/redis/releases/tag/v5.0.14.1)

安装后，目录中的redis.server.exe 为redis的服务程序，这里我们可以配置一些选项

打开配置文件redis.windows.conf

我们要求能够局域网连接，所以修改以下选项：

- bind 127.0.0.1  -> bind 0.0.0.0 // 允许所有ipv4地址 
- protected-mode yes -> protected-mode no // 关闭保护模式允许外部连接
- requirepass password  // 设置密码，这里最好设置一个

修改后保存文件，关闭redis服务程序

管理员命令在redis程序根目录打开一个新的cmd，输入以下命令运行服务端

```shell
# 读取redis.windows.conf配置运行服务
redis.server.exe redis.windows.conf
```



**nestjs引入Redis**

nestjs中引入Redis通过注册微服务方式进行,需要下载以下依赖

```shell
npm i ioredis @nestjs/microservices -S
```

首先在main.ts中连接微服务, 注册redis服务端

```ts
// main.ts
import { Transport } from '@nestjs/microservices';

app.connectMicroservice({
    transport: Transport.TCP,
  // 以下是配置服务，自行配置
    options: {
      host: configService.get('BASE_HOST'),
      port: configService.get('REDIS_PORT'),
    },
  });
```

新建一个module进行Redis服务的注册和封装

```ts
// redis.module.ts
import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { RedisService } from './redis.service';

@Global()
@Module({
  imports: [
    ClientsModule.registerAsync([
      {
        name: 'REDIS_CLIENT',
        useFactory: (configService: ConfigService) => ({
          transport: Transport.REDIS,
          options: {
            host: configService.get('BASE_HOST'),
            port: configService.get('REDIS_PORT'),
            password: configService.get('REDIS_AUTH'),
          },
        }),
        inject: [ConfigService],
      },
    ]),
  ],
  providers: [RedisService],
  exports: [RedisService],
})
export class RedisModule {}

```

```ts
// redis.service.ts 这里按照需要自行封装
import type { Redis } from 'ioredis';

import { Inject, Injectable, OnApplicationBootstrap } from '@nestjs/common';
import { ClientRedis } from '@nestjs/microservices';

@Injectable()
export class RedisService implements OnApplicationBootstrap {
  redis: Redis;
  constructor(@Inject('REDIS_CLIENT') private redisClient: ClientRedis) {}

  async onApplicationBootstrap() {
    await this.redisClient.connect();
    this.redis = this.redisClient.createClient();
  }

  getValue(key: string) {
    return this.redis.get(key);
  }

  setValue(key: string, value: any) {
    return this.redis.set(key, value);
  }

  /**
   * @description 设置有过期时间的value
   * @param key
   * @param exp
   * @param value
   * @returns
   */
  setExValue(key: string, exp: number, value: any) {
    return this.redis.setex(key, exp, value);
  }

  /**
   * @description 获取并删除有过期时间的value （getex是高版本的redis新方法，请按照redis版本进行使用）
   * @param key
   * @returns
   */
  getDelValue(key: string) {
    return this.redis.get(key, () => {
      this.redis.del(key);
    });
  }
}

```

## 疑惑概念

用法不清楚，以及应用场景不清楚

- 可选提供器
  部分提供器可能需要根据配置进行动态注册，所以在使用提供器的地方需要设置可选修饰符









## 问题记录

**mongoose 使用populate填充失败**

模型定义：猫和主人，多对多关系

```ts
// cat.schema.ts
import type { HydratedDocument } from 'mongoose';
import * as mongoose from 'mongoose';

import { ownModelName } from './own.schema.ts'

export interface ICat {
  name: string;
  age: number;
  breed: string;
  owner?: string[];
}

export const CatSchema = new mongoose.Schema({
  // 自定义id
  _id: String,
  name: String,
  age: Number,
  breed: String,
  owner: [{ type: mongoose.Schema.Types.String, ref: ownModelName }],
});

export const catModelName = 'cat';

export type CatDocument = HydratedDocument<ICat>;

```

```ts
// own.schema.ts
import type { HydratedDocument } from 'mongoose';

import * as mongoose from 'mongoose';

import { catModelName } from './cat.schema.ts'

export interface IOwn {
  name: string;
  age: number;
  cats: string[];
}

export const OwnSchema = new mongoose.Schema({
  _id: String,
  name: String,
  age: Number,
  cats: [{ type: mongoose.Schema.Types.String, ref: catModelName }],
});

export const ownModelName = 'own';

export type OwnDocument = HydratedDocument<IOwn>;
```

模型定义如上，进行查询时却遇到个奇怪的问题：

```ts
// xxx.service.ts
// 能正常查询，且own信息能正常填充  
findAllCat(): Promise<ICat[]> {
    return this.catModel.find().populate('owner', 'name age id').exec();
  }

 // 能正常查询但是cats信息没有被填充
 findAllOwn(): Promise<IOwn[]> {
    return this.ownModel.find().populate('cats', 'name age id').exec();
  }
```

解决方法是 将 catModelName和ownModelName单独提到一个文件中定义然后在分别引入，不要产生相互引用，或者。直接使用常量

初步分析是由于循环应用，模块加载顺序不一致导致populate无法正常工作

### 序列化失败

使用内置的ClassSerializerInterceptor拦截器序列化失败
原因是Mongoose 返回的对象是带有额外属性和方法的特殊文档对象（例如 `Document` 对象），而不是纯粹的 JavaScript 对象。为了能够正确地使用 `class-transformer` 进行序列化，需要将 Mongoose 文档转换为普通的 JavaScript 对象（调用toObject()）。

```ts
async function getUserDto(userId: string): Promise<UserDto> {
  const userDoc: Document = await User.findById(userId);
  // 将 Mongoose 文档转换为普通对象
  const plainUserObject = userDoc.toObject();
  
  //...
}
```

### 循环依赖问题

A模块引入B 模块，同时B模块又引入了A模块，可以使用forwardRef来解决循环依赖问题
```js
// A.module.ts
@Module({
  imports:[forwardRef(() => B)]
})
export class A {};

// B.module.ts
@Module({
  imports:[forwardRef(() => A)]
})
export class B {};
```

### 轮询函数

```js
/**
 * 轮询函数，直到满足特定条件或达到最大尝试次数。
 *
 * @param {Function} apiCall - 用于执行API请求的异步函数。
 * @param {Function} checkResult - 检查API响应是否满足停止轮询条件的函数。应该接受响应并返回true/false。
 * @param {Object} options - 配置选项包括轮询间隔和最大尝试次数。
 * @returns {Promise} - 当满足条件时解析，或在达到最大尝试次数时拒绝。
 */
async function poll(
  fn: () => Promise<any>,
  checkResult: (e: any) => boolean | undefined,
  options: { interval?: number; maxAttempts?: number } = {},
) {
  const defaultOptions = {
    interval: 1000, // 默认轮询间隔为1秒
    maxAttempts: 10, // 默认最大尝试次数为10次
  };

  const { interval, maxAttempts } = { ...defaultOptions, ...options };
  let attempts = 0;

  while (attempts < maxAttempts) {
    let timeoutId = null; // 用于存储当前的setTimeout ID
    if (timeoutId !== null) {
      clearTimeout(timeoutId); // 清除定时器
    }
    try {
      const response = await fn();
      if (checkResult(response)) {
        return response; // 返回满足条件的结果
      }
    } catch (error) {
      return Promise.reject(error);
    }

    attempts++;
    if (attempts >= maxAttempts) {
      throw new Error(`Reached maximum number of attempts (${maxAttempts}).`);
    }
    await new Promise((resolve) => {
      timeoutId = setTimeout(resolve, interval);
    }); // 等待下一次轮询
  }
}
```

