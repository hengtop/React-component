# LRU

least recently used 最近最少使用 一种缓存策略

比如：内存中存了 5 个数 1-5（按照从小到大的顺序加入的）

现在新加入一个数6，我们就需要踢出去一个数，当然我们得按照一定的规则来决定哪一个数被踢出去。
按照LRU策略来，则就是把最先加入的 1 给踢出去 所以目前的内存中就是 2-6了， 如果再加入一个数 7 ，则就把 2 给踢出去。



理解之后我们来设计下代码思路：

1. 能够快速读取数据---Map
2. 能够新增/修改/删除数据，选择   Doubly Linked List  这些操作时间都为复杂度O（1）
   - 如果新增的时候没有容量了，需要把最老的给删除掉
   - 如果更新，则更新对应的值并将其移动到最开始的位置

所以我们需要设计一下接口：

- get 获取最新的值
- put 添加值
- remove 删除值
- append 移动值，移动到最新的位置

数据结构如下：

![image-20230801164704715](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230801164704715.png)

我们的Map每一个key存储，双向链表的一个节点，在get/put的时候对链表进行维护满足LRU策略。

代码示例：

```js
// 最近 最少使用
class DoubleNode {
  constructor(key, val) {
    this.key = key;
    this.val = val;
    this.prev = null;
    this.next = null;
  }
}

class LRUCache {
  DEFAULT_CAPACITY = 5;
  constructor(capacity) {
    this.capacity = capacity ?? this.DEFAULT_CAPACITY;
    this.map = new Map();

    this.head = null;
    this.tail = null;
  }

  get(key) {
    const node = this.map.get(key);
    if (!node) {
      return -1;
    } else {
      const res = node.val;
      this.remove(node);
      // 移动到开头
      this.appendHead(node);
      return res;
    }
  }

  put(key, value) {
    // 判断是否有这个key
    let node = this.map.get(key);
    if (node) {
      node.val = value;
      // 移动到第一位
      this.remove(node);
      this.appendHead(node);
    } else {
      // 新增一个双向链表节点
      node = new DoubleNode(key, value);
      // 超过容积
      if (this.map.size >= this.capacity) {
        // 从map中删除
        this.map.delete(this.tail.key);
        // 从链表中删除
        this.remove(this.tail);
        this.appendHead(node);
        this.map.set(key, node);
      } else {
        // 放置到头部
        this.appendHead(node);
        this.map.set(key, node);
      }
    }
  }

  // 更新头部元素
  appendHead(node) {
    if (this.head === null) {
      this.head = this.tail = node;
    } else {
      node.next = this.head;
      this.head.prev = node;
      this.head = node;
    }
  }
  remove(node) {
    // 只有一个
    if (this.head === this.tail) {
      this.head = this.tail = null;
    } else if (this.head === node) {
      this.head = this.head.next;
      this.head.prev = null;
      node.next = null;
    } else if (this.tail === node) {
      this.tail = this.tail.prev;
      this.tail.next = null;
      node.prev = null;
    } else {
      node.prev.next = node.next;
      node.next.prev === node.prev;
      node.prev = null;
      node.next = null;
    }
  }
  // 迭代器
  [Symbol.iterator]() {
    let current = this.head;
    return {
      next() {
        if (current) {
          let prev = current;
          current = current.next;
          return {
            done: false,
            value: prev.val,
          };
        } else {
          return {
            done: true,
            value: undefined,
          };
        }
      },
    };
  }
}

const lru = new LRUCache();

lru.put(1, 1);
lru.put(2, 3);
lru.put(3, 4);
lru.put(5, 5);
lru.put(2, 6);

for (const iterator of lru) {
  console.log(iterator);
}

```

