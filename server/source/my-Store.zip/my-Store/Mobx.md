## Mobx

## 安装

```shell
# yarn
yarn add mobx
# npm
npm install mobx
```

## 核心概念



## action

## computeds

类似于计算属性，可以通过其他的可观察对象中派生信息，同时会对结果惰性求值缓存输出，只有当依赖的可观察对象被改变的时候才会重新计算。

```js
import { makeObservable, observable, computed, autorun } from 'mobx';

class OrderLine {
  price = 1;
  amount = 1;

  constructor(price) {
    makeObservable(this, {
      price: observable,
      amount: observable,
      total: computed,
    });
    this.price = price;
  }

  get total() {
    console.log('Computing...');
    return this.price * this.amount;
  }

  changeSome(amount) {
    this.amount = amount;
  }
}

const order = new OrderLine(0);

const stop = autorun(() => {
  console.log('Total: ' + order.total);
});
// Computing...
// Total: 0

// console.log(order.total);
// // (不会重新计算!)
// // 0

// order.amount = 5;
// // console.log(order.total);
// // // Computing...
// // // (无需 autorun)

// Computing...
// Total: 10
order.amount = 5;
order.amount = 2;

console.log(order.total);

```

## Reactions

reactions的目的就是对自动发生的副作用进行建模，对可观察状态创建消费者，当关联的可观察对象发生变化的时候就自动运行副作用。

### Autorun

接受一个函数作为参数，当函数观察的值发生变化的时候就应该运行。

### Reaction

### when

注意：一旦不再需要Reactions这些方法中的副作用时，请务必调用它们所返回的 disposer 函数。 否则可能导致内存泄漏。