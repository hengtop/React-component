# 浏览器适配

作为前端工程师，布局是一个项目开始就接触，同时也贯穿整个项目的部分，也是最能体现基本功的一项能力。日常工作中经常应对pc，移动端/小程序的项目，布局往往都是使用项目工程中已经集成的方案，所以平时更多也是专注于业务。

正好最近有点时间摸鱼，就总结下浏览器适配的一些知识，刨根问底，探究下其原理。

首先先探讨一些名词，主要最近也是看了很多相关的文章，说实话给我看迷糊了，这里就再再再总结下的，大家基本讨论一致的结论。

## 像素

单独解释像素这个词，其本意指的就是呈现图像的基本单位，拥有颜色和位置属性

### 物理像素 

物理像素也叫设备像素，指的是设备显示屏幕真实的像素，同时每个像素的大小是出场就固定不变的

### 逻辑像素

逻辑像素别名有很多：
设备独立像素
css像素（注意，缩放为1的情况 css像素等同于逻辑像素）

逻辑像素是人为定义的一层抽象的像素，每个设备不一定一样，主要用于保证ui在不同设备下都能展示差不多的大小

在一般的pc上 一个物理像素是等于一个逻辑像素，但是在手机上就不一定了，比如，下图这两款手机，右边尺寸没变，但物理分辨率却翻倍了，如果之前的ui（ui是按照css像素规定的尺寸）还是按照1对1的物理像素展示的话，就会很小，所以为了保证ui展示的尺寸差不错右边的1个逻辑像素就需要使用到4个物理像素展示，这样就能保证ui尺寸差不多，同时清晰度也提升了。

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230810164240404.png" alt="image-20230810164240404" style="zoom: 25%;" /><img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230810163221654.png" alt="image-20230810163221654" style="zoom: 25%;" />

### css 像素

可以称做逻辑像素的一种

默认情况 web页面的缩放比为100%，那么，1css像素=1逻辑像素

**在没有缩放的情况下，1个css像素等同于一个设备独立像素。**

CSS像素在视觉上是很容易改变大小的，比如缩放浏览器页面，就是改变的CSS像素，当放大一倍，那么一个CSS像素在横向或者纵向上会覆盖两个设备独立像素。例如宽度`100px`，当页面放大一倍，它会在横向上由原本占据100个逻辑像素像素，变成占据200个逻辑像素；如果缩小，则恰好相反，只能占据50个设备独立像素。
公式：逻辑像素 = css像素*缩放比例

## 分辨率

### 显示分辨率

也可以称做 物理分辨率，设备分辨率

显示分辨率（屏幕分辨率）是屏幕图像的精密度，是指显示器所能显示的像素有多少，简单来讲就是说宽高各有多少个设备像素
比如iphone6的显示分辨率1334x750 即 手机横向由750个像素，竖向有1334个方向

### 图像分辨率

图像分辨率决定了图像输出的质量，图像分辨率和图像尺寸(高宽)的值一起决定了文件的大小，且该值越大图形文件所占用的磁盘空间也就越多 ，代表显示屏能够以越高的密度显示图像，画面的细节就会越丰富。

### 逻辑分辨率

即按照逻辑像素来定义的分辨率

可以使用window.screen.width/height获取当前屏幕的逻辑分辨率

## 视口

视口相关的文章可以看下这篇 里面还有两篇续作[A tale of two viewports — part one](https://www.quirksmode.org/mobile/viewports.html)

### 布局视口

layout viewport`的宽度可以通过 `document.documentElement.clientWidth

layout viewport 为布局视口，即网页布局的区域，它是 html 元素的父容器，只要不在 css 中修改  元素的宽度， 元素的宽度就会撑满 layout viewport 的宽度。
 很多时候浏览器窗口没有办法显示出 layout viewport 的全貌，但是它确实是已经被加载出来了，这个时候滚动条就出现了，你需要通过滚动条来浏览 layout viewport 其他的部分。
 layout viewport 用 css 像素来衡量尺寸，在缩放、调整浏览器窗口的时候不会改变。缩放、调整浏览器窗口改变的只是 visual viewport。

### 视觉视口

visual viewport`的宽度可以通过`window.innerWidth 来获取

George Cummins在stack overflow上解释了布局视口和视觉视口的基本的概念：

将`layout viewport`想象为一个不会改变大小或形状的大图像。现在想象你有一个较小的框架，通过它你可以看到这个大图片。小框架由不透明的材料构成，通过它你只能看到大图像的一部分，这一部分就叫做 `visual viewport` .你可以拿着这个框架和图像拉开一定的距离(zoom out)看到整个图像，你也可以让自己离图像更近(zoom in)看到其中的一部分。你也可以旋转这个框架的方向，但是这个图片(`layout viewport`)的大小和形状永远不会改变。

visual viewport 就像一台摄像机，layout viewport 就像一张纸，摄像机对准纸的哪个部分，你就能看见哪个部分。你可以改变摄像机的拍摄区域大小（调整浏览器窗口大小），也可以调整摄像机的距离（调整缩放比例），这些方法都可以改变 visual viewport，但是 layout viewport 始终不变。

### 理想视口

ideal viewport 为理想视口，不同的设备有自己不同的 ideal viewport，ideal viewport 的宽度等于移动设备的屏幕宽度，所以其是最适合移动设备的 viewport。只要在 css 中把某一元素的宽度设为 ideal viewport 的宽度(单位用 px )，那么这个元素的宽度就是设备屏幕的宽度了，也就是宽度为100% 的效果。   ideal viewport 的意义在于，无论在何种分辨率的屏幕下，那些针对ideal viewport 而设计的网站，不需要用户手动缩放，也不需要出现横向滚动条，都可以完美的呈现给用户。

## 利用 meta 标签对 viewport 进行控制

对于移动端来讲，默认的布局视口是比屏幕要宽的，可能980px左右，这个是为了保证pc端的网页在移动端的布局不会崩坏，挤成一坨

但是我们进行移动端开发是需要保证ideal viewport = layout viewport 所以我们可以使用meta标签进行设置

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
```

该 meta 标签的作用是让当前 viewport 的宽度等于设备的宽度，同时不允许用户手动缩放。如果你不这样的设定的话，那就会使用那个比屏幕宽的默认 viewport（layout viewport）980px，也就是说会出现横向滚动条。
相关的属性意义如下所示

| width         | 设置 layout viewport  的宽度，为一个正整数，或字符串 "width-device" |
| ------------- | ------------------------------------------------------------ |
| height        | 设置页面的初始缩放值，为一个数字，可以带小数                 |
| initial-scale | 允许用户的最小缩放值，为一个数字，可以带小数                 |
| minimum-scale | 允许用户的最大缩放值，为一个数字，可以带小数                 |
| maximum-scale | 设置 layout viewport  的高度，这个属性对我们并不重要，很少使用 |
| user-scalable | 是否允许用户进行缩放，值为"no"或"yes", no 代表不允许，yes 代表允许 |

另外关于initial-scale缩放问题

有以下公式：视觉视口 = 理想视口 / initial-scale缩放值

### 一些细节

meta同时设置`width` 和 `initial-scale=1` 不会冲突么？

不会 会取最终两个值中的最大的一个设置为布局视口

width=400表示将 布局视口 设置为400，而initial-scale设置后会改变 视觉视口 的大小 比如再将initial-scale设置为0.5 ，在理想视口味375px的条件下，其 视觉视口 就变为375/0.5=750px 那么 此时 的布局视口 就会取这两个值中的最大值进行设置，所以此时的 布局视口    大小就取的400和750中的750了。

要把当前的 `viewport`宽度设为`ideal viewport`的宽度，既可以设置 `width=device-width`，也可以设置 `initial-scale=1`，但这两者各有一个小缺陷，就是会横竖屏不分。iphone、ipad设置 `width=device-width`的话通通以竖屏的`ideal viewport`宽度为准。而IE 设置`initial-scale=1`会以竖屏的`ideal viewport`宽度为准 。所以，最完美的写法应该是两者都写上去，这样 :`initial-scale=1` 解决了 iphone、ipad的毛病，`width=device-width`则解决了IE的毛病。

总之：

- `width=device-width`：将布局视口的宽度设置为设备的屏幕宽度。这样，网页的布局视口会与设备的物理屏幕大小相匹配，确保网页内容不会超出屏幕边界，避免出现横向滚动条。
- `initial-scale=1.0`：将视觉视口的初始缩放比例设置为 1.0，即以原始大小加载网页内容。这可以确保网页在初始加载时不会被缩放，而是以设备的像素比例在视觉视口内显示。

通过同时设置这两个属性，可以实现以下效果：

1. 网页的布局视口宽度与设备屏幕宽度相匹配，确保网页的布局不会超出设备屏幕范围。
2. 网页的初始加载时，内容以原始大小在视觉视口内显示，避免了用户需要手动缩放来查看网页。
3. 网页在不同大小的移动设备上能够适应屏幕并提供一致的用户体验，无需用户进行额外的调整。

### 适配

浏览器适配一般分为两个大类pc适配和移动端适配

### pc

pc适配其实比较简单
通用的方法flex+媒体查询

可以看这篇文章https://www.topzhang.cn/archives/260/

### 移动端

#### `rem`布局

https://juejin.cn/post/6953091677838344199?searchId=20230810115708A90FF7FF8C779DF96420#heading-4

#### vw/vh布局

vw/vh布局也是类似，只是不需要rem中的js进行动态设置根字体了

https://juejin.cn/post/6953091677838344199?searchId=20230810115708A90FF7FF8C779DF96420#heading-7



## 关于移动端1px问题

所以这个问题也可以得到解释：

小程序使用的是rpx单位，而这个单位会根据用户手机的屏幕转换成rem
比如支付宝小程序规定屏幕宽750rpx 。以 Apple iPhone6 为例，屏幕宽度（设备独立像素）为 375px，共有 750 个物理像素

所以750rpx = 375px< --- > 1rpx =0.5px

而对于部分浏览器而言 0.5px的具体呈现效果也不同：

- chrome：把小于0.5px的当成0，大于等于0.5px的当作1px

- firefox：会把大于等于0.55px的当作1px

- safiri:把大于等于0.75px的当作1px 进一步在手机上观察iOS的Chrome会画出0.5px的边，而安卓(5.0)原生浏览器是不行的。所以直接设置0.5px不同浏览器的差异比较大。

而设计师想要的1px指的是不同机型的1个物理像素

如果我们固定在css里写死1px的话部分机型会渲染出多个物理像素，导致部分机型看起来偏粗，而使用rpx的话又会出现0.5px问题，所以以下记录这个问题的解决方案：

使用transform scale+伪元素设置宽度

```js
   &::after {
        content: '';
        position: absolute;
        left: 0;
        bottom: 0rpx;
        width: calc(100%);
        height: 1px;
        transform: scaleY(0.5);// 这里缩放比例可以根据手机dpr进行设置 dpr=2 就设置0.5 dpr=3设置0.333 dpr=1就设置1
        background-color: #eee;
      }

```

## 参考文献

1. [作为前端，你应该的分辨率/逻辑像素/物理像素/retina屏知识](https://www.swvq.com/boutique/detail/55521)
2. [CSS像素、物理像素、逻辑像素、设备像素比、PPI、Viewport](https://www.cnblogs.com/zaoa/p/8630393.html)
3. [A tale of two viewports — part one](https://www.quirksmode.org/mobile/viewports.html)
4. [深入浅出移动端适配（总结版）](https://juejin.cn/post/6844903951012200456#heading-0)
5. [2022 年移动端适配方案指南 — 全网最新最全](https://juejin.cn/post/7046169975706353701?searchId=20230810111418B441A2A1E7F829F5F990#heading-28)
6. [移动端适配的5种方案](https://juejin.cn/post/6953091677838344199?searchId=20230810115708A90FF7FF8C779DF96420#heading-2)
