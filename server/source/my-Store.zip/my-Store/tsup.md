# tsup使用

## 是什么

tsup 是基于 esbuild 开发的一个新型打包工具（比 rollup 还新）。内置了 TypeScript 支持，零配置、开箱即用，帮助你高效创建现代 TypeScript/JavaScript 库。

[GitHub地址](https://github.com/egoist/tsup)

[官网地址](https://tsup.egoist.dev/)

## 安装

```shell
npm i tsup -D
# Or Yarn
yarn add tsup --dev
```



## helloworld

### 新建目录

建立一个tsup-demo文件夹，使用喜欢的包管理工具初始化生成package.json

```shell
npm init
# or Yarn
yarn init
```

建立一个src目录，在src目录下新建一个index.ts文件。图片中其他文件目录先忽略。

![image-20230827195823529](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827195823529.png)



我们在index.ts中写一个简单的求和函数

```js
export function add(x: number, y: number) {
  return x + y;
}
```

### 打包

配置package.json，添加如下命令注意根据自己使用的包管理来添加：

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827200050699.png" alt="image-20230827200050699" style="zoom:33%;" />

然后我们运行

```js
yarn dev
# or
npm run dev
```

- 注意 该demo基于tsup 7.2.0 后续tsup版本更新后按照上面的简单配置运行时 可能会报错找不到  typescript 模块 可以自行下载 yarn add typescript -D or npm i typescript -D
  

可以看到在dist目录生成了index.js文件

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827200348488.png" alt="image-20230827200348488" style="zoom:33%;" />

内容如下：

```js
"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  add: () => add
});
module.exports = __toCommonJS(src_exports);
function add(x, y) {
  return x + y;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  add
});
```

可以看到里面有我们定义的add函数了。其余的一部分代码是和导入导出相关，有兴趣的可以深究下。

### 使用

我们新建一个demo文件进行测试

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827200957975.png" alt="image-20230827200957975" style="zoom:33%;" />
可以看到成功运行了

## 自定义配置

### 多格式配置

目前常用的包导入方式是esmodule和cjs 所以我们写的库尽量兼容这两种导入方式。

我们可以在根目录创建一个tsup.config.ts 进行配置

```ts
import type { Options } from 'tsup'

const config: Options = {
  entry: ['src/index.ts'],
  // 是否生成ts声明文件
  dts: true,
  // 源代码映射
  sourcemap: false,
  // build前是否清除dist目录
  clean:true,
  // 打包格式的设置 这里设置了生成cjs的包和esmodule的包
  format: ['cjs', 'esm'],
  // 文件监听的时候排除的文件
  ignoreWatch:['**/{.git,node_modules}/**']
}

export default config

```

然后配置下package.json 的导入目录

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827201412018.png" alt="image-20230827201412018" style="zoom:33%;" />

main 和module选项是分别配置 cjs 格式的文件入口和 esmodule 格式的文件入口。而exports是更广泛的一种配置文件入口的方式，其相关的知识点可以参照[链接](https://nodejs.org/api/packages.html#packages_conditional_exports)。这里两个配置文件入口的方式都配置上是因为main/module的兼容性更广，而exports是node版本较高的时候才加入的一个配置。即如果同时定义了“ export”和“ main”，那么在受支持的 Node.js 版本中，“ export”字段优先于“ main”字段。

配置好后打包就会生成相应格式的文件：

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202337804.png" alt="image-20230827202337804" style="zoom:33%;" />

### ts配置

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202112025.png" alt="image-20230827202112025" style="zoom:33%;" />

可以看到tsup.config.ts 配置就是设置是否生成ts声明文件的，设置为true打包就会生成*.d.ts文件

![image-20230827202247308](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202247308.png)

## 测试

我们写的函数最好也写几个单元函数进行测试下

这里我们使用jest来配置单元测试

### 安装jest

可以查看官网，这里我还配置了jest的babel和ts，都可参照下面官网链接进行配置 [官网](https://jestjs.io/zh-Hans/docs/getting-started)

编辑配置文件,我们在根目录下建立jest.config.js

编写一下代码，配置下哪些文件是test文件。

```js
/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: [
    '<rootDir>/tests/**/*.[jt]s?(x)',
    '<rootDir>/src/**/?(*.)+(spec|test).[jt]s?(x)'
  ]
};
```

### 测试函数

我们新建目录写下如下代码：

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202717928.png" alt="image-20230827202717928" style="zoom:33%;" />

```ts
import { add } from '../dist'
import { describe, expect, test } from "@jest/globals";

describe("sum module", () => {
  test("adds 1 + 2 to equal 3", () => {
    expect(add(1, 2)).toBe(3);
  });
});
```

### 设置测试命令

在package.json中配置test运行命令

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202812269.png" alt="image-20230827202812269" style="zoom:33%;" />

之后运行

```shell
yarn test
# or
npm run test
```

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827202901083.png" alt="image-20230827202901083" style="zoom:33%;" />

可以看到测试成功

## 调试

我们写的包要本地进行调试的话该如调试呢？

这里我们使用包管理的link方式，以yarn为例

在我们的开发工具目录下运行

```shell
yarn link
```

然后到需要使用该工具的项目根目录下运行

```shell
yarn link [工具名]
# e.g
yarn link "tsup-demo"
```

工具名就是package.json中的name字段

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827203324410.png" alt="image-20230827203324410" style="zoom:33%;" />

然后就可以像正常的包导入进行使用了

<img src="/Users/zhangheng/Library/Application Support/typora-user-images/image-20230827203434832.png" alt="image-20230827203434832" style="zoom:33%;" />

而且这种方式导入，我们对工具的更改也是实时生效的。

## 发布

发布可以参照这篇文件：

[npm包开发](https://www.topzhang.cn/archives/144/)

### 参考文献

1. https://juejin.cn/post/7265153491345489972?searchId=202308251634091F4C79B739B9778DD001#heading-0
2. https://nodejs.org/dist/latest-v18.x/docs/api/packages.html#packagejson-and-file-extensions

