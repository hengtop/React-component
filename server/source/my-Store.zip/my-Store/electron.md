## electron

### helloworld

官方文档快速体验 https://www.electronjs.org/zh/docs/latest/tutorial/quick-start

## 安装脚手架

实际上，快速开发和打包推荐使用官方的脚手架

### [Electron Forge](https://www.electronforge.io/)

```shell
tnpm init electron-app@latest my-app --template=vite-typescript
```

### 安装 [better-sqlite3](https://github.com/WiseLibs/better-sqlite3/tree/master)

![image-20240701174319341](/Users/zhangheng/Library/Application Support/typora-user-images/image-20240701174319341.png)

解决方案：https://github.com/WiseLibs/better-sqlite3/issues/1044

最好先把目录中的node_modules删掉

```shell
npm install
cd node_modules/better-sqlite3
npx node-gyp rebuild --debug --build-from-source --runtime=electron --target=[your_electron_version] --dist-url=https://electronjs.org/headers
cd ../..
npm run start
```

成功启动项目后我们来写一个demo---在node子进程运行sqlite3的操作，并将结果发送到主进程，再由主进程将结果发送到渲染进程：

#### sqlite3 demo

首先我们写一个简单的数据库表建立和查询
```js
// dbWorker.mjs

import Database from 'better-sqlite3';
import path from 'node:path';

const db = new Database(path.join('./src/db/database/user.db'), {
  verbose: console.log,
});

// 开启WAL模式
db.pragma('journal_mode = WAL');

// 创建表
db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, age INTEGER)`);

const stmt = db.prepare('INSERT INTO users (name, age) VALUES (@name, @age)');  

const insertMany = db.transaction((cats) => {
  // 批量运行
  for (const cat of cats) stmt.run(cat);
});

// 插入数据
insertMany([
  { name: 'Joey', age: 2 },
  { name: 'Sally', age: 4 },
  { name: 'Junior', age: 1 },
]);


const query = db.prepare('SELECT * FROM users');
const data = query.iterate()
  // 发送结果回主进程  
process.send([...data]);  
```

#### 主进程创建子进程并加载 dbWorker.mjs

```ts
import { app, BrowserWindow, ipcMain } from 'electron';
import path from 'path';
import { fork } from 'node:child_process'

// 创建子进程
const child = fork(path.join('./src/db/dbWorker.mjs'));  

// 接受子进程消息并触发主进程订阅的消息事件
child.on('message', (data) => {
  console.log('child-data',data);
  ipcMain.emit('database-result', data)
})

const createWindow = () => {
// ...其余代码


  // 接受消息后 将数据发送到渲染进程
  ipcMain.on('database-result', (data) => {  
    // 注意，需要等渲染进程的监听事件初始化完毕后再发送--dom-ready。
    console.log('main-pross',data);
    mainWindow.webContents.on('dom-ready', () => {
      mainWindow.webContents.send('database-data', data);  
    })
  }); 
};
// .... 其余代码

```

#### 通过preload.js暴露方法

注意preload.js 需要先被引入哈
![image-20240702092841239](/Users/zhangheng/Library/Application Support/typora-user-images/image-20240702092841239.png)

处于安全原因，这里我们通过preload.js脚本暴露一个方法来让渲染进程接收数据库查询结果

```ts
// preload.ts
import { ipcRenderer, contextBridge } from 'electron'

contextBridge.exposeInMainWorld('electronAPI', {
  getDataBaseData: (callback) => ipcRenderer.on('database-data', (_event, value) => {
    callback(value)
  })
})
```

#### 渲染进程接收事件

此时在渲染进程中我们就可以通过window.electronAPI.getDataBaseData来访问我们暴露的方法来

```ts
// render.ts
window.electronAPI.getDataBaseData((e) => {
  console.log(e);
})
```



### 集成React

数据库获取数据搞定了我们来集成下React开发一个简单的todo吧



