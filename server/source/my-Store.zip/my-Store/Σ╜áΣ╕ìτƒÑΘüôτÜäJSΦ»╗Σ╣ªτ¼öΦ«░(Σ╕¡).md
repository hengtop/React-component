## 你不知道的JS读书笔记(中)

## 类型

本书的定义：对语言引擎和开发人员来说，类型是值的内部特征，它定义了值的行为，以使其区别于其他值

### 内置类型

js中的 八个内置类型：

- null
- undefined
- boolean
- number
- string
- object
- symbol
- bigint

上述除了object外，都是基本类型

我们可以用typeof来查看值的类型

但是null 和object 使用typeof打印出来的值是一样的,

所以对于null类型的判断需要使用符合条件

```js
var a = null;
(! a && typeof a === "object"); // true
```

### 值和类型

JavaScript中的变量是没有类型的，只有值才有。变量可以随时持有任何类型的值。

因为JS并没有做类型强制，所以变量可以被赋给任意类型的值。

所以使用typeof获取到的是该变量持有值的类型

**安全检查**

对于不确定是否声明的变量进行判断可以使用，以下方式

```js
        // 这样会抛出错误
        if (DEBUG) {
            console.log( "Debugging is starting" );
        }
        // 这样是安全的
        if (typeof DEBUG ! == "undefined") {
            console.log( "Debugging is starting" );
        }
```

另外我们想书写一些polyfill代码，需要判断某个变量是否被占用，可以使用以下方式进行判断

```js
        if (typeof aa === "undefined") {
          // 不用var定义，避免if条件不成立也造成了变量提升
            aa = function() { /＊..＊/ };
        }
```

## 值

### 数组

js中的数组是动态的数组，可以容纳任意类型的值同时也不需要预先设置大小

### 字符串

js中字符串和数组有部分相同的内置方法。对于数组，字符串是不可变的，因为部分的数组方法调用后是会改变原数组，而字符串去借用这些方法调用后并不会修改原值(目前2023-2-2字符串借用会报错了。。。)。

```js
const a = 'foo';
const b = ['f', 'o', 'o'];

a[1] = 'O';
b[1] = 'O';
console.log(a);
console.log(b);
//foo
//[ 'f', 'O', 'o' ]
```

反正要调用的话就将字符串展位数组处理在转换回来就行了

### 数字

#### 较小的数值

js的数值规范是遵循IEEE 754，会出现以下情况

```js
        0.1 + 0.2 === 0.3; // false
```

#### 判断0.1+0.2===0.3？

- 设置误差范围值，对于js中这个数字可以设置为2^-52（2.220446049250313e-16）这个值在ES6可以通过这个常量获取Number.EPSILON

#### 32位有符号整数

a | 0可以将变量a中的数值转换为32位有符号整数，因为数位运算符|只适用于32位整数（它只关心32位以内的值，其他的数位将被忽略）。因此与0进行OR操作本质上没有意义。

#### void

可以将值或者表达式的返回值设置为undefined

```js
const a ='121';
const b = function foo(){}
console.log(void a);
console.log(void b);
```

#### NaN

表示不是数字的数字，往往是在进行数学运算错误的时候得到的值。

我们可以用内置函数isNaN来进行判断一个值是不是NaN，但是这方法有个问题：

```js
        var a = 2 / "foo";
        var b = "foo";

        a; // NaN
        b; "foo"

        window.isNaN( a ); // true
        window.isNaN( b ); // true——晕！
```

要是传入的字符串也会返回true。。。另外NaN还有个特性就是自身不等于自身，即NaN === NaN  //false

所以我们可以利用这一特性来设置一个isNaN的polyfill

```js
        if (! Number.isNaN) {
            Number.isNaN = function(n) {
              return n ! == n;
            };
        }
```

#### 零值

js中有个常规的0，也有带符号的+0和-0

乘除法运算可以得到-0

```js
        var a = 0 / -3; // -0
        var b = 0 ＊ -3; // -0
```

加减法是不会得到-0的

将其从字符串转换为数字，得到的结果是准确

```js
        +"-0";              // -0
        Number( "-0" );     // -0
        JSON.parse( "-0" ); // -0
```

如何区分-0和0

```js
          function isNegZero(n) {
              n = Number( n );
              return (n === 0) && (1 / n === -Infinity);
          }

          isNegZero( -0 );        // true
          isNegZero( 0 / -3 );    // true
          isNegZero( 0 );         // false
```

**为什么需要-0**

有些应用程序中的数据需要以级数形式来表示（比如动画帧的移动速度），数字的符号位（sign）用来代表其他信息（比如移动的方向）。此时如果一个值为0的变量失去了它的符号位，它的方向信息就会丢失。所以保留0值的符号位可以防止这类情况发生。

当然对于这些特殊值的判断我们还可以使用Object.is();

### 值和引用

js中基本类型总是通过值复制的方式进行赋值或者传递，复合类型（对象，函数等）总是通过引用复制的方式来赋值或者传递。

对于是否是值复制还是引用复制，一切都是由值的类型决定。

JavaScript中的引用和其他语言中的引用/指针不同，它们不能指向别的变量/引用，只能指向值。

## 原生函数

常用的原生函数有

String()  Number()  Boolean()  Array()  Object()  Function()  RegExp()  Date()  Error() Symbol()
原生函数也称之为内建函数

使用原生函数构建的对象：

```js
var s = new String( "Hello World! " );
console.log( s.toString() ); // "Hello World! "
console.log(typeof s); // object
```

通过构造函数（如new String("abc")）创建出来的是封装了基本类型值（如"abc"）的封装对象。注意并不是基本类型值。

### 内部属性[[Class]]

所有typeof返回值为object的对象都包含一个内部属性[[Class]],我们可以通过Object.prototype.toString()来查看:
```js
        Object.prototype.toString.call( [1,2,3] );
        // "[object Array]"
        Object.prototype.toString.call( /regex-literal/i );
        // "[object RegExp]"
```

```js
        Object.prototype.toString.call( null );
        // "[object Null]"

        Object.prototype.toString.call( undefined );
        // "[object Undefined]"
```

### 封装对象包装

由于基本类型值没有如.length或者.toString()属性和方法，需要通过封装对象进行访问，我们在通过基本类型使用一些属性或方法时，js引擎会自动版帮我们创建。

```js
        var a = "abc";

        a.length; // 3
        a.toUpperCase(); // "ABC"
```

#### 自行封装基本类型值

可以使用Object函数

```js
        var a = "abc";
        var b = new String( a );
        var c = Object( a );

        typeof a; // "string"
        typeof b; // "object"
        typeof c; // "object"

        b instanceof String; // true
        c instanceof String; // true

        Object.prototype.toString.call( b ); // "[object String]"
        Object.prototype.toString.call( c ); // "[object String]"
```

#### 拆封

想要得到封装对象中的基本类型值，可以使用valueOf函数:

```js
        var a = new String( "abc" );
        var b = new Number( 42 );
        var c = new Boolean( true );

        a.valueOf(); // "abc"
        b.valueOf(); // 42
        c.valueOf(); // true
```

### 原生原型

原生的一些构造函数都有自己的prototype对象，但是有一些原生原型并不是普通的对象：

```js
        typeof Function.prototype;          // "function"
        Function.prototype();               // 空函数！

        RegExp.prototype.toString();        // "/(? :)/"——空正则表达式
        "abc".match( RegExp.prototype );    // [""]
```

## 强制类型转换

### 值类型转换

将值从一种类型转换为另一种类型称之为类型转换，这是显式的情况，而隐式的情况一般称之为强制类型转换。

Js中，强制类型转换总是会发你会标量基本类型值，比如字符串，数字和布尔值，并不会返回对象或者函数。

```js
        var a = 42;
        var b = a + "";         // 隐式强制类型转换
        var c = String( a );    // 显式强制类型转换
```

### ToString

基本类型值的字符串话规则为

null转换为"null", undefined转换为"undefined", true转换为"true"。数字的字符串化则遵循通用规则

对普通对象来说，除非自行定义，否则toString()（Object.prototype.toString()）返回内部属性[[Class]]的值，如"[object Object]"。

如果对象有自己的toString()方法，字符串化时就会调用该方法并使用其返回值。

### ToNumber

有时候我们需要将非数字的值当作数字来进行使用，有以下转换规则：

|     基本值      | 转为number类型 |
| :-------------: | :------------: |
|   布尔值true    |       1        |
|   布尔值false   |       0        |
| 标识符undefined |      NaN       |
|      null       |       0        |

对于字符串的转换也是基本遵循数字常量的相关规则，处理失败返回NaN

为了将值转换为相应的基本类型值，抽象操作ToPrimitive会首先检查该值是否有valueOf()方法。如果有并且返回基本类型值，就使用该值进行强制类型转换。如果没有就使用toString()的返回值（如果存在）来进行强制类型转换。

如果valueOf和toString方法都没找到，就会报错误TypeError

### ToBoolean

JavaScript中有两个关键词true和false，分别代表布尔类型中的真和假

js中的值可以分为两类：

- 可以被强制转换为false的值
- 其他（被强转为true的值）

js中以下是假值，可以被强转为false

|      假值      |
| :------------: |
| null/undefined |
|     false      |
|  +0、-0、NaN   |
|       ""       |

逻辑上来讲除上述以外的值都为真值

### 日期显示转换为数字

一元运算符+的另一个常见用途是将日期（Date）对象强制类型转换为数字，返回结果为Unix时间戳，以毫秒为单位（从1970年1月1日00:00:00 UTC到当前时间）

```js
var d = new Date( "Mon, 18 Aug 2014 08:53:06 CDT" );

console.log(+d); // 1408369986000
```

当然最好用这个函数

```js
        var timestamp = Date.now();
```

### 显示解析数字字符串

解析字符串中的数字和将字符串强制类型转换为数字的返回结果都是数字。但解析和转换两者之间还是有明显的差别。

解析允许字符串中含有非数字字符，解析按从左到右的顺序，如果遇到非数字字符就停止。而转换不允许出现非数字字符，否则会失败并返回NaN。

parseInt解析字符串中的整数

parseInt会将参数强制类型转换为字符串再进行解析

另外，解析字符串中的浮点数可以使用parseFloat(..)函数

注意使用parseInt一定要注意指定一个radix

解释一个令人费解的输出

```js
        parseInt( 1/0, 19 ); // 18
```

首先1/0等于无穷，js中无穷选择的是Infinity表示，而19表示进制基数为19 那么数值范围就是0-9 a-i

parseInt会将参数强制类型转换为字符串再进行解析，从左到右解析只有第一个字符I在数值范围，第二个n就在数值之外了，所以就返回18

### 显示转换为布尔值

一般不会直接使用Boolean()

更多会使用!和!!

### 字符串和数字之间的转换

如果+的其中一个操作数是字符串（或者通过ToPrimitive抽象操作可以得到字符串），则执行字符串拼接；否则执行数字加法。

### 宽松相等和严格相等

宽松相等（loose equals）==和严格相等（strict equals）===都用来判断两个值是否“相等”，但是它们之间有一个很重要的区别，特别是在判断条件上。

==允许在相等比较中进行强制类型转换，而===不允许。

宽松相等符号的转换规则如下：

基本类型之间比较：

(1) 如果Type(x)是数字，Type(y)是字符串，则返回x == ToNumber(y)的结果。
(2) 如果Type(x)是字符串，Type(y)是数字，则返回ToNumber(x) == y的结果。
(3) 如果Type(x)是布尔类型，则返回ToNumber(x) == y的结果
(4) 如果Type(y)是布尔类型，则返回x == ToNumber(y)的结果。
(5) 如果x为null, y为undefined，则结果为true。
(6) 如果x为undefined, y为null，则结果为true。

可以理解为基本类型之间宽松比较出现强转都向数字类型转。

对象和非对象之间的比较：

(1) 如果Type(x)是字符串或数字，Type(y)是对象，则返回x == ToPrimitive(y)的结果
(2) 如果Type(x)是对象，Type(y)是字符串或数字，则返回ToPrimitive(x)== y的结果。

### 抽象比较

这可能与我们设想的大相径庭，即<=应该是“小于或者等于”。实际上JavaScript中<=是“不大于”的意思（即！(a > b)，处理为！(b < a)）。同理，a >= b处理为b <= a。

真抽象。。。

## 语法

### 语句和表达式

语句相当于句子，表达式相当于短语，运算符号相当于标点符号和连接词。

### 语句的结果值

js中语句都有个结果值

以赋值表达式b = a为例，其结果值是赋给b的值，但规范定义var的结果值是undefined。如果在控制台中输入var a = 42会得到结果值undefined，而非42。

### 运算符优先级

&&运算符先于||执行

[符号优先级](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Operator_Precedence)

### 短路

对&&和||来说，如果从左边的操作数能够得出结果，就可以忽略右边的操作数。我们将这种现象称为“短路”（即执行最短路径）。

### 错误

JavaScript中有很多错误类型，分为两大类：早期错误（编译时错误，无法被捕获）和运行时错误（可以通过try..catch来捕获）。所有语法错误都是早期错误，程序有语法错误则无法运行。

#### 提前使用变量

TDZ（暂时性死区）

```js
{
   a = 2;      // ReferenceError!
   let a;
}
```

### switch

注意点：

尽管可以使用==，但switch中case中的true和switch括号中的true之间仍然是严格相等比较。即如果case表达式的结果为真值，但不是严格意义上的true，那就不符合

```js
        var a = "hello world";
        var b = 10;
        switch (true) {
              case (a || b == 10):
                      // 永远执行不到这里
                      break;
              default:
                      console.log( "Oops" );
        }
        // Oops
```

```js
        var a = "42";

        switch (true) {
              case a == 10:
                      console.log( "10 or '10'" );
                      break;
              case a == 42;
                      console.log( "42 or '42'" );
                      break;
              default:
                      // 永远执行不到这里
        }
        // 42 or '42'
```

#### 多 case - 单一操作

```js
var Animal = "Giraffe";
switch (Animal) {
  case "Cow":
  case "Giraffe":
  case "Dog":
  case "Pig":
    console.log("This animal will go on Noah's Ark.");
    break;
  case "Dinosaur":
  default:
    console.log("This animal will not.");
}

```

#### 多 case - 关联操作

```js
var foo = 1;
var output = "Output: ";
switch (foo) {
  case 0:
    output += "So ";
  case 1:
    output += "What ";
    output += "Is ";
  case 2:
    output += "Your ";
  case 3:
    output += "Name";
  case 4:
    output += "?";
    console.log(output);
    break;
  case 5:
    output += "!";
    console.log(output);
    break;
  default:
    console.log("Please pick a number from 0 to 5!");
}
```



### 一些限制

• 字符串常量中允许的最大字符数（并非只是针对字符串值）

• 可以作为参数传递到函数中的数据大小（也称为栈大小，以字节为单位）

• 函数声明中的参数个数
具体多少和js引擎相关，同时超出限制后不同引擎报错内容也不一样。

• 未经优化的调用栈（例如递归）的最大层数，即函数调用链的最大长度
一般递归爆栈会出超出这个限制

• JavaScript程序以阻塞方式在浏览器中运行的最长时间（秒）；

• 变量名的最大长度。

## 异步和性能

### 事件循环

什么是事件循环，以一段伪代码进行演示：

```js
          // eventLoop是一个用作队列的数组
          //（先进，先出）
          var eventLoop = [ ];
          var event;

          // “永远”执行
          while (true) {
              // 一次tick
              if (eventLoop.length > 0) {
                // 拿到队列中的下一个事件
                event = eventLoop.shift();

                // 现在，执行下一个事件
                try {
                    event();
                }
                catch (err) {
                    reportError(err);
                }
              }
          }
```

可以看到，一个一直循环的while，每次循环称为一次tick，每次tick中，如果队列中有事件，就会取出进行调用，这个事件就是回调函数。任意时刻，一次只能从队列中处理一个事件。执行事件的时候，可能直接或间接地引发一个或多个后续事件。

setTimeout(..)并没有把你的回调函数挂在事件循环队列中。它所做的是设定一个定时器。当定时器到时后，环境会把你的回调函数放在事件循环中，这样，在未来某个时刻的tick会摘下并执行这个回调。

所以setTimeout并不是准时的，如果事件循环里已经有很多事件了，它得等前面的事件执行完才能执行，所以setTimeout只能保证不会在指定的时间之前运行。

### 并行线程

并行计算最常见的工具就是进程和线程。进程和线程独立运行，并可能同时运行：在不同的处理器，甚至不同的计算机上，但多个线程能够共享单个进程的内存。

### 并发

单线程时间循环是并发的一种形式

#### 非交互

两个或多个进程在同一个程序内并发交替的运行，这些任务之间彼此不相关就不一定需要交互，所以对于最终运行顺序的不确定性因素是没有影响的。

#### 交互

当任务之间有相互的依赖或者‘交流’，就需要对它们的交互进行协调以避免竞态bug的出现。

### 协作

取到一个长期运行的“进程”，并将其分割成多个步骤或多批任务，使得其他并发“进程”有机会将自己的运算插入到事件循环队列中交替运行。

```js
        var res = [];

        // response(..)从Ajax调用中取得结果数组
        function response(data) {
            // 添加到已有的res数组
            res = res.concat(
              // 创建一个新的变换数组把所有data值加倍            // 如果数据量大的话就会阻塞进程
              data.map( function(val){
                  return val ＊ 2;
              } )
            );
        }

        // ajax(..)是某个库中提供的某个Ajax函数
        ajax( "http://some.url.1", response );
        ajax( "http://some.url.2", response );
```

优化后：

```js
        var res = [];

        // response(..)从Ajax调用中取得结果数组
        function response(data) {
            // 一次处理1000个
            var chunk = data.splice( 0, 1000 );

            // 添加到已有的res组
            res = res.concat(
              // 创建一个新的数组把chunk中所有值加倍
              chunk.map( function(val){
                  return val ＊ 2;
              } )
            );

            // 还有剩下的需要处理吗？
            if (data.length > 0) {
              // 异步调度下一次批处理
              setTimeout( function(){
                  response( data );
              }, 0 );
            }
        }

        // ajax(..)是某个库中提供的某个Ajax函数
        ajax( "http://some.url.1", response );
        ajax( "http://some.url.2", response );
```

### 任务

#### 任务队列

挂在事件循环队列的每个tick之后的一个队列。在事件循环的每个tick中，可能出现的异步动作不会导致一个完整的新事件添加到事件循环队列中，而会在当前tick的任务队列末尾添加一个项目（一个任务）。

### Promise

识别Promise（或者行为类似于Promise的东西）就是定义某种称为thenable的东西，将其定义为任何具有then(..)方法的对象和函数。我们认为，任何这样的值就是Promise一致的thenable。

链式流程控制可行的Promise固有特性:

- 调用Promise的then()会自动创建一个新的promise从调用返回
- 在完成或拒绝处理函数内部，如果返回一个值或抛出一个异常，新返回的（可链接的）Promise就相应地决议。
- 如果完成或者拒绝处理函数返回一个Promise，它将会被展开，这样一来，不管它的决议值是什么，都会成为当前的then()返回的链接Promise的决议值

### 生成器

定义，带*的函数

```js
function *foo() {
    a++;
    yield;
    b = b * a;
    a = (yield b) + 3;
}
```

调用生成器会返回一个迭代器

### 生成器中的Promise并发

观察下面这段代码

```js
// 在此感谢Benjamin Gruenbaum（@benjamingr on GitHub）的巨大改进！
function run(gen) {
  var args = [].slice.call(arguments, 1), it;

  // 在当前上下文中初始化生成器
  it = gen.apply(this, args);

  // 返回一个promise用于生成器完成
  return Promise.resolve().then(function handleNext(value) {
    // 对下一个yield出的值运行
    var next = it.next(value);

    return (function handleResult(next) {
      // 生成器运行完毕了吗？
      if (next.done) {
        return next.value;
      }
      // 否则继续运行
      else {
        return Promise.resolve(next.value).then(
          // 成功就恢复异步循环，把决议的值发回生成器
          handleNext,

          // 如果value是被拒绝的promise，
          // 就把错误传回生成器进行出错处理
          function handleErr(err) {
            return Promise.resolve(it.throw(err)).then(handleResult);
          }
        );
      }
    })(next);
  });
}

function ajax(cb) {
  const rand = Math.random() * 10;
   const flag = rand > 1;
   return new Promise((resolve, reject) => {
    setTimeout(() => {
      if(flag) {
        resolve(rand)
      } else {
        reject('error')
      }
    },3000);
   })
}

// 并发
function* foo() {
  try {
    console.time(1);
    // 下面这两段代码就是同步执行进行决策了
    const p1 = ajax();
    const p2 = ajax();
    var text1 = yield p1;
    var text2 = yield p2;
    console.log('并发');
    console.timeEnd(1);
    console.log(text1+text2);
  } catch (err) {
    console.log(err);
  }
}

// 非并发
function* foo1() {
  try {
    console.time(2);
    var text1 = yield ajax();
    var text2 = yield ajax();
    console.log('非并发');
    console.timeEnd(2);
    console.log(text1+text2);
  } catch (err) {
    console.log(err);
  }
}

run(foo);
run(foo1);


// 并发
// 1: 3.004s
// 14.303664139989756
// 非并发
// 2: 6.006s
// 12.044890906792915
```

### 生成器委托

从一个生成器中调用另一个生成器

yield委托的具体语法是：yield ＊（注意多出来的＊）。

```js
function *foo() {
  console.log( "*foo() starting" );            
  yield 3;
  yield 4;
  console.log( "*foo() finished" );
}

function *bar() {
  yield 1;
  yield 2;
  yield *foo();    // yield委托！
  yield 5;
}

var it = bar();

console.log(it.next())
console.log(it.next())
console.log(it.next())
console.log(it.next())
console.log(it.next())
/**
{ value: 1, done: false }
{ value: 2, done: false }
*foo() starting
{ value: 3, done: false }
{ value: 4, done: false }
*foo() finished
{ value: 5, done: false }
 */
```

首先，和我们以前看到的完全一样，调用foo()创建一个迭代器。然后yield ＊把迭代器实例控制（当前＊bar()生成器的）委托给/转移到了这另一个＊foo()迭代器。

所以，前面两个it.next()调用控制的是＊bar()。但当我们发出第三个it.next()调用时，＊foo()现在启动了，我们现在控制的是＊foo()而不是＊bar()。这也是为什么这被称为委托：＊bar()把自己的迭代控制委托给了＊foo()。一旦it迭代器控制消耗了整个＊foo()迭代器，it就会自动转回控制＊bar()。

使用yield委托主要是将部分代码抽离处理，让代码组织更好看。保证程序可读性可维护性。

### 消息委托

```js
function* foo() {
  console.log("inside *foo():", yield "B");

  console.log("inside *foo():", yield "C");

  return "D";
}

function* bar() {
  console.log("inside *bar():", yield "A");

  // yield委托！
  console.log("inside *bar():", yield* foo());

  console.log("inside *bar():", yield "E");

  return "F";
}

var it = bar();

console.log("outside:", it.next().value);
// outside: A

console.log("outside:", it.next(1).value);
// inside *bar(): 1
// outside: B

console.log("outside:", it.next(2).value);
// inside *foo(): 2
// outside: C

console.log("outside:", it.next(3).value);
// inside *foo(): 3
// inside *bar(): D
// outside: E

console.log("outside:", it.next(4).value);
// inside *bar(): 4
// outside: F

```

### 异常委托

### 异步委托

### 递归委托

### 形式转换程序

用一个函数定义封装函数调用，包括需要的任何参数，来定义这个调用的执行，那么这个封装函数就是一个形实转换程序。之后在执行这个thunk时，最终就是调用了原始的函数。

#### 同步thunk

```js
        function foo(x, y) {
            return x + y;
        }

        function fooThunk() {
            return foo( 3, 4 );
        }

        // 将来

        console.log( fooThunk() );  // 7
```

#### 异步thunk

```js
        function foo(x, y, cb) {
            setTimeout( function(){
              cb( x + y );
            }, 1000 );
        }

        function fooThunk(cb) {
            foo( 3, 4, cb );
        }

        // 将来

        fooThunk( function(sum){
            console.log( sum );     // 7
        } );
```

```js
// 封装      
function thunkify(fn) {
  var args = [].slice.call( arguments, 1 );
  return function(cb) {
    args.push( cb );
    return fn.apply( null, args );
  };
}

function foo(x,y,cb){
  setTimeout(() => {
    cb(x+y)
  },1000);
}

var fooThunk = thunkify( foo, 3,4 );
// 将来

fooThunk( function(sum) {
  console.log( sum );      // 7
} );
```

```js
// 优化
function thunkify(fn) {
  return function () {
    var args = [].slice.call(arguments);
    return function (cb) {
      args.push(cb);
      return fn.apply(null, args);
    };
  };
}

function foo(x, y, cb) {
  setTimeout(() => {
    cb(x + y);
  }, 1000);
}

var thunkory = thunkify(foo);
const fooThunk1 = thunkory(1,2)
// 将来

fooThunk1(function (sum) {
  console.log(sum); // 7
});

```

### 生成器的原理

### 程序性能

利用并发处理一些独立的请求

#### web work

如果遇到一些密集型任务执行，但不希望阻塞主线程，这样我们就可以利用web work来开启一个新的线程运行这些任务。

可以通过如下方式来初始化一个worker

```js
          var w1 = new Worker( "你要加载的js文件路径" );
```

浏览器会单独开启一个线程来运行这个文件。除了提供一个指向外部文件的URL，你还可以通过提供一个Blob URL创建一个在线Worker（Inline Worker)，本质上就是一个存储在单个（二进制）值中的在线文件。

Worker之间以及它们和主程序之间，不会共享任何作用域或资源，之间的通信可以通过发布订阅来进行

## 性能测试和调优

一些工具

http://benchmarkjs.com/

http://calendar.perfplanet.com/2010/bulletproof-javascript-benchmarks）和这里（http://monsur.hosa.in/2012/12/11/benchmarksjs.html

### 尾调用优化

```js
function factorial(n) {
  function fact(n, res){
    if(n < 2){
    return res
  }
  return fact(n-1, n*res)
  }
  return fact(n,1)
}
 
console.log(factorial(5))
```

