## 你不知道的JS读书笔记（上）

## 作用域

### 什么是作用域

负责收集并维护由所有声明的标识符（变量）组成的一系列查询，并实施一套非常严格的规则，确定当前执行的代码对这些标识符的访问权限。
对于JS来讲，作用域也是一套规则，用户确定在何处，以及如何查找变量。如果查找的目的是对变量进行赋值，那么就会使用LHS查询；如果目的是获取变量的值，就会使用RHS查询。
如果查找的目的是对变量进行赋值，那么就会使用LHS查询；如果目的是获取变量的值，就会使用RHS查询。

不成功的RHS引用会导致抛出ReferenceError异常。不成功的LHS引用会导致自动隐式地创建一个全局变量（非严格模式下），该变量使用LHS引用的目标作为标识符，或者抛出ReferenceError异常（严格模式下）。ReferenceError同作用域判别失败相关，而TypeError则代表作用域判别成功了，但是对结果的操作是非法或不合理的。（比如对undefined值进行函数调用）

### 词法作用域

作用域有两种主要的工作模式：

- 词法作用域（常见）
- 动态作用域（不常见）

词法作用域意味着作用域是由书写代码时函数声明的位置来决定的。编译的词法分析阶段基本能够知道全部标识符在哪里以及是如何声明的，从而能够预测在执行过程中如何对它们进行查找。

### 函数作用域

区分函数声明和表达式的一个小技巧：看function关键字出现在声明中的位置（不仅仅是一行代码，而是整个声明中的位置）。如果function是声明中的第一个词，那么就是一个函数声明，否则就是一个函数表达式。

### 匿名和具名函数

匿名函数最常见的使用场景就是回调函数了

```js
        setTimeout(function() {
            console.log("I waited 1 second! ");
        }, 1000 );
```

当然匿名函数省去了我们去想一个独特名字，但它也有一些缺点：

1. 匿名函数在盏追踪中不会显示出有意义的函数名
   ![image-20230129144954523](/Users/zhangheng/Library/Application Support/typora-user-images/image-20230129144954523.png)
2. 函数引用自身进行调用的话只能使用过期的一个属性arguments.callee引用
3. 匿名函数也丢弃了代码的可读性，我们并不能通过名字来知道这个函数是干啥的了

当然我们针对上述问题也可以给函数加上名字，使得其作用更加清晰：

```js
          setTimeout(function timeoutHandler() { // <-- 快看，我有名字了！
              console.log("I waited 1 second! ");
          }, 1000 );
```

### 立即执行函数

立即执行函数IIFE（Immediately Invoked Function Expression）

```js
        var a = 2;
        (function foo() {
            var a = 3;
            console.log(a); // 3
        })();
        console.log(a); // 2
```

函数名对于IIFE并不是必须的，最常用的方法就是使用匿名函数，这个常用在当作函数调用并传递参数进去

```js
        var a = 2;

        (function IIFE(global) {

            var a = 3;
            console.log(a); // 3
            console.log(global.a); // 2

        })(window);

        console.log(a); // 2
```

对于括号的位置，可以写在里面，也可以写在外面，全凭个人喜好：

```js
  var a = 2;
        (function foo() {
            var a = 3;
            console.log(a); // 3
        })();
        console.log(a); // 2

// 里边
  var a = 2;
        (function foo() {
            var a = 3;
            console.log(a); // 3
        }());
        console.log(a); // 2
```

### 块作用域

我们 在for循环或者if语句等块作用域中使用var定义变量 却能在外部访问到：

```js
for(var i = 0; i < 5;i++){
  console.log(i)
}
console.log('forend',i) //forend 5

if(true) {
  var j = 'n';
} 
console.log(j)//n
```

你可能会认为JS的块作用域是不存在的

当然JS还是有实实在在的块作用域的比如：

- with关键字（现在不要使用它）
- try/catch语句中的catch也会创建一个块作用域

ES6引入的新的关键字let就可以将变量绑定到任意的作用域中（通常是{...} 内部），let为其声明的变量隐式地劫持了所在的块作用域。

使用let进行的声明不会在块作用域中进行提升。声明的代码被运行之前，声明并不“存在”。（作用域死区）



### 作用域提升

包括变量和函数在内的所有定义声明都会在任何代码被执行前首先被处理。

例如var a=2；可以看作两个声明 var a 和 a = 2 第一个 定义声明 是在编译阶段进行的。第二个赋值声明是在执行阶段进行的。

#### 函数优先

函数和变量的声明都会被提升，但如果有相同的名称的变量和函数声明，函数声明会首先被提升，然后才是变量。

```js
          foo(); // 1
          var foo;
          function foo() {
              console.log(1);
          }
          foo = function() {
              console.log(2);
          };
```

注意：

- 尽量不要在块内部声明函数。不然会导致一些意想不到的事情。
- 避免重复声明。

如果在块中声明函数会出现以下问题：

（es6谷歌浏览器测试）

```js
    var a = 0;
    console.log("1 a:" + a); //  0
    if (true) {
      a = 1;
      function a() { }
      a = 5;
      console.log("2 a:" + a) // 5
    }
    console.log("3 a:" + a) //  1
```

打印结果出乎意料吧，所以尽量避免在块中声明函数

### 作用域闭包

简单定义：当函数可以记住并访问所在的词法作用域时，就产生了闭包，即使函数是在当前词法作用域之外执行。

下面的代码就是典型的闭包：
```js
        function foo() {
            var a = 2;

            function bar() {
              console.log(a);
            }

            return bar;
        }
        var baz = foo();
        baz(); // 2
```

我们通过一些手段将内部函数传递到所在的词法作用域以外，内部的函数仍然持有对原始定义位置的作用域的引用，无论我们在何处执行这个函数都会使用到闭包。

比如回调函数实际上就是在使用闭包。

#### 模块

两个主要特征：

- 必须有外部的封闭函数，该函数必须至少被调用一次（每次调用都会创建一个新的模块实例）。
- 封闭函数必须返回至少一个内部函数，这样内部函数才能在私有作用域中形成闭包，并且可以访问或者修改私有的状态。

闭包的一个典型应用

## this

### this的确定

this是在运行时进行绑定的，并不是在编写时绑定，它的上下文取决于函数的调用位置（函数调用方法）。this的绑定和函数声明的位置没有任何关系，只取决于函数的调用方式。

### 调用位置

函数在代码中被调用的位置

### 调用栈

到达当前执行位置所调用的所有函数

```js
        function baz() {
            // 当前调用栈是：baz
            // 因此，当前调用位置是全局作用域

            console.log("baz");
            bar(); // <-- bar的调用位置
        }

        function bar() {
            // 当前调用栈是baz -> bar
            // 因此，当前调用位置在baz中

            console.log("bar");
            foo(); // <-- foo的调用位置
        }

        function foo() {
            // 当前调用栈是baz -> bar -> foo
            // 因此，当前调用位置在bar中

            console.log("foo");
        }

        baz(); // <-- baz的调用位置
```

### 绑定规则

**独立函数调用**
在严格模式下内部的this是会指向全局对象的，而在严格模式下this对象是指向undefined的

### 隐式绑定

当函数引用有上下文对象时，隐式绑定规则会把函数调用中的this绑定到这个上下文对象。对象属性引用链中只有上一层或者说最后一层在调用位置中起作用。

### 隐式丢失

我们对函数进行隐式传递或者赋值传递可能会导致this应用默认绑定规则

```js
        function foo() {
            console.log(this.a);
        }
        var obj = {
            a: 2,
            foo: foo
        };
        var a = "oops, global"; // a是全局对象的属性
        setTimeout(obj.foo, 100); // "oops, global"
```

```js
        function foo() {
            console.log(this.a);
        }
        function doFoo(fn) {
            // fn其实引用的是foo
            fn(); // <-- 调用位置！
        }
        var obj = {
            a: 2,
            foo: foo
        };
        var a = "oops, global"; // a是全局对象的属性
        doFoo(obj.foo); // "oops, global"
```

```js
        function foo() {
            console.log(this.a);
        }
        var obj = {
            a: 2,
            foo: foo
        };
        var bar = obj.foo; // 函数别名！
        var a = "oops, global"; // a是全局对象的属性
        bar(); // "oops, global"
```

#### 间接引用

我们会在赋值时候发生函数调用，这时候的函数会应用默认绑定规则

```js
        function foo() {
            console.log(this.a);
        }
        var a = 2;
        var o = { a: 3, foo: foo };
        var p = { a: 4 };

        o.foo(); // 3
        (p.foo = o.foo)(); // 2
```



### 显示绑定

1. 硬绑定
   call，apply，bind
2. API调用的上下文
   一些函数自带一个参数用于传递this 比如forEach的最后一个参数

### new绑定

回顾下new 操作符调用会发生什么：

1. 创建（或者说构造）一个全新的对象。
2. 这个新对象会被执行[[Prototype]]连接。
3. 这个新对象会绑定到函数调用的this。
4. 如果函数没有返回其他对象，那么new表达式中的函数调用会自动返回这个新对象。

第三步就是new对this造成影响的原因。

### 优先级

this绑定优先级：

1．函数是否在new中调用（new绑定）？如果是的话this绑定的是新创建的对象。

2．函数是否通过call、apply（显式绑定）或者硬绑定调用？如果是的话，this绑定的是指定的对象。

3．函数是否在某个上下文对象中调用（隐式绑定）？如果是的话，this绑定的是那个上下文对象。

4．如果都不是的话，使用默认绑定。如果在严格模式下，就绑定到undefined，否则绑定到全局对象。

### 硬绑定和软绑定

硬绑定就是我们直接为原函数设置一个上下文，不管原函数是否已经隐式绑定了一个有意义的this，而软绑定我们可以判断原函数里的this是否是undefined或者全局对象，如果是就绑定上我们设置的this，不是就不为其修改this。

### 忽略this绑定

有时我们并不需要this的绑定，我门可以创建一个更安全的特殊对象(DMZ)，作为this绑定的对象

```js
        function foo(a, b) {
            console.log("a:" + a + ", b:" + b);
        }

        // 我们的DMZ空对象
        var ø = Object.create(null);

        // 把数组展开成参数
        foo.apply(ø, [2, 3]); // a:2, b:3

        // 使用bind(..)进行柯里化
        var bar = foo.bind(ø, 2);
        bar(3); // a:2, b:3
```



## 对象

JS中目前有
七种基本类型 string,number,boolean,bigInt,symbol,undefined,null

引用类型
object，function 等

注意：对null执行typeof null时也会返回'object' 这个本身是语言的一个bug，因为不同的对象在底层都是以二进制表示，在JS中二进制的前三位都为0就会被判断为object类型，null的二进制全为0自然也会被判断为object了。

对象是键值对的集合，对象中属性名永远是字符串，属性的特征可以通过属性描述符来进行控制，属性也不一定包含值（它们可能是具备getter/setter的“访问描述符”。）

## 混合对象“类”

### 显式混入

```js
        // 非常简单的mixin(..)例子：
        function mixin(sourceObj, targetObj) {
            for (var key in sourceObj) {
              // 只会在不存在的情况下复制
              if (! (key in targetObj)) {
                  targetObj[key] = sourceObj[key];
              }
            }

            return targetObj;
        }

        var Vehicle = {
            engines: 1,
            ignition: function() {
              console.log("Turning on my engine.");
            },

            drive: function() {
              this.ignition();
              console.log("Steering and moving forward! ");
            }
        };

        var Car = mixin(Vehicle, {
            wheels: 4,
            drive: function() {
              Vehicle.drive.call(this);
              console.log(
                  "Rolling on all " + this.wheels + " wheels! "
              );
            }
        } );
```

混入模式（无论显式还是隐式）可以用来模拟类的复制行为，但是通常会产生丑陋并且脆弱的语法，比如显式伪多态（OtherObj.methodName.call(this, ...)），这会让代码更加难懂并且难以维护。显式混入实际上无法完全模拟类的复制行为，因为对象（和函数！别忘了函数也是对象）只能复制引用，无法复制被引用的对象或者函数本身。忽视这一点会导致许多问题。

## 原型

JS对象中都有个特殊的[[Prototype]]内置属性

### 属性设置和屏蔽

如果foo不直接存在于myObject中而是存在于原型链上层时myObject.foo ="bar"会出现的三种情况。

1. 如果在[[Prototype]]链上层存在名为foo的普通数据访问属性并且没有被标记为只读（writable:false），那就会直接在myObject中添加一个名为foo的新属性，它是屏蔽属性。
2. 如果在[[Prototype]]链上层存在foo，但是它被标记为只读（writable:false），那么无法修改已有属性或者在myObject上创建屏蔽属性。如果运行在严格模式下，代码会抛出一个错误。否则，这条赋值语句会被忽略。总之，不会发生屏蔽。
3. 如果在[[Prototype]]链上层存在foo并且它是一个setter，那就一定会调用这个setter。foo不会被添加到（或者说屏蔽于）myObject，也不会重新定义foo这个setter。

如果希望在第二种和第三种情况下也屏蔽foo，那就不能使用=操作符来赋值，而是使用Object.defineProperty(..)来向myObject添加foo。

```js
const a = Object.create({})
console.log(a.__proto__);// {}
Object.defineProperty(a.__proto__,'foo',{
  value:'666',
  writable:false
});
console.log(a.foo);// 666
a.foo='777'
console.log(a.foo);// 666
```

```js
const a = Object.create({})
console.log(a.__proto__);// {}
Object.defineProperty(a.__proto__,'foo',{
  value:'666',
  writable:false
});
console.log(a.foo);// 666
Object.defineProperty(a, 'foo', {
  value:'777'
})
console.log(a.foo);// 777
```

有些情况情况会产生隐式屏蔽

```js
        var anotherObject = {
            a:2
        };

        var myObject = Object.create(anotherObject);

        anotherObject.a; // 2
        myObject.a; // 2

        anotherObject.hasOwnProperty("a"); // true
        myObject.hasOwnProperty("a"); // false

        myObject.a++; // 隐式屏蔽！

        anotherObject.a; // 2
        myObject.a; // 3
        myObject.hasOwnProperty("a"); // true
```

## 

